package com.abs;
import java.util.*;
public class EmployeeDetails {

	public static void main(String[] args) {
	ArrayList a1=new ArrayList();
	 void Employee(String Username , String Password){
	String U=Username;
		a1.add(U);
		String P=Password;
		a1.add(P);
		System.out.println(a1);
	}
	}

}
