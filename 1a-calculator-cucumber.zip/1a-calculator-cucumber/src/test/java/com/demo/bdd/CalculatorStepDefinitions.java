package com.demo.bdd;

import static org.assertj.core.api.Assertions.assertThat;

import com.demo.bdd.calculator.Calculator;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CalculatorStepDefinitions {
	Calculator calculator;
	Integer result;
	@Given("The user has a calculator")
	public void the_user_has_a_calculator() {
	    calculator = new Calculator();
	}

	@When("User adds {int} and {int}")
	public void user_adds_and(Integer number1, Integer number2) {
	    result = calculator.add(number1, number2);
	}

	@Then("User should get {int}")
	public void user_should_get(Integer sum) {
	    assertThat(result).isEqualTo(sum);
	}
}
