package com.cg.services;

import java.util.List;



import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ProductsDao;
import com.cg.entities.Products;
import com.cg.exceptions.ApplicationException;

@Service
public class ProductServiceImpl 
	implements ProductService {

	@Autowired private ProductsDao dao;

	@Override
	public void save(Products emp) {
		// TODO Auto-generated method stub
		System.out.println("Saving Product: "+emp.getId());
		if(dao.existsById(emp.getId())) {
			throw new ApplicationException("Record already exists!");
		}
		dao.save(emp);
		
	}

	@Override
	public void update(Products emp) {
		// TODO Auto-generated method stub
		System.out.println("Updating Product: "+emp.getId());
		if(! dao.existsById(emp.getId())) {
			throw new ApplicationException("Record did not exists!"); 
		}
		dao.save(emp);
		
	}

	@Override
	public void delete(Integer id) {
		// TODO Auto-generated method stub
		System.out.println("Deleting Product: "+id);
		if(!dao.existsById(id)) {
			throw new ApplicationException("Unable to delete, record not found!");
		}
		dao.deleteById(id);
		
	}

	@Override
	public List<Products> findAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Products findById(Integer id) {
		// TODO Auto-generated method stub
		System.out.println("Finding Product: "+id);
		Optional<Products> temp = dao.findById(id);
		if(!temp.isPresent()) {
			throw new ApplicationException("Unable to find Product "+id);
		}
		return temp.get();
	}
	
	
}
