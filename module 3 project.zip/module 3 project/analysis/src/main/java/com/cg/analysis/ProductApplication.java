package com.cg.analysis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductApplication.class, args);
		System.err.println("WELCOME TO THE PAGE OF PRODUCTS DISPATCHED REPORT");
	}
}
