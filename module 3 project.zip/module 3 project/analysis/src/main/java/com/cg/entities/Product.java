package com.cg.entities;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "products")
@SequenceGenerator(name="my_seq",sequenceName="MY_SEQ",initialValue=1000, allocationSize=1)
public class Product implements Serializable {

	@Id
	@Column(name = "Id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator="my_seq")
	private int Id;

	@Column(name = "pname", length = 20)
	private String pname;

	
	@Column(name = "pcategory", length = 20)
	private String pcategory;

	@Column(name = "dedate")
	private String dedate;

	@Column(name = "detime", length = 20)
	private String detime;
	
	@Column(name = "exdate", length = 20)
	private String exdate;

	@Column(name = "extime", length = 20)
	private String extime;

	@Column(name = "out", length = 20)
	private String out;
	
	@Column(name = "shipped", length = 20)
	private String shipped;
	
	
	@Column(name = "merchant", length = 20)
	private String merchant;

	@Column(name = "cname", length = 20)
	private String cname;

	@Column(name = "cmob")
	private String cmob;

	@Column(name = "cadd", length = 20)
	private String cadd;
	

	public Product() {
	
	}


	public int getId() {
		return Id;
	}


	public void setId(int id) {
		Id = id;
	}


	public String getPname() {
		return pname;
	}


	public void setPname(String pname) {
		this.pname = pname;
	}


	public String getPcategory() {
		return pcategory;
	}


	public void setPcategory(String pcategory) {
		this.pcategory = pcategory;
	}


	public String getDedate() {
		return dedate;
	}


	public void setDedate(String dedate) {
		this.dedate = dedate;
	}


	public String getDetime() {
		return detime;
	}


	public void setDetime(String detime) {
		this.detime = detime;
	}


	public String getExdate() {
		return exdate;
	}


	public void setExdate(String exdate) {
		this.exdate = exdate;
	}


	public String getExtime() {
		return extime;
	}


	public void setExtime(String extime) {
		this.extime = extime;
	}


	public String getOut() {
		return out;
	}


	public void setOut(String out) {
		this.out = out;
	}


	public String getShipped() {
		return shipped;
	}


	public void setShipped(String shipped) {
		this.shipped = shipped;
	}


	public String getMerchant() {
		return merchant;
	}


	public void setMerchant(String merchant) {
		this.merchant = merchant;
	}


	public String getCname() {
		return cname;
	}


	public void setCname(String cname) {
		this.cname = cname;
	}


	public String getCmob() {
		return cmob;
	}


	public void setCmob(String cmob) {
		this.cmob = cmob;
	}


	public String getCadd() {
		return cadd;
	}


	public void setCadd(String cadd) {
		this.cadd = cadd;
	}


	public Product(int id, String pname, String pcategory, String dedate, String detime, String exdate, String extime,
			String out, String shipped, String merchant, String cname, String cmob, String cadd) {
		super();
		Id = id;
		this.pname = pname;
		this.pcategory = pcategory;
		this.dedate = dedate;
		this.detime = detime;
		this.exdate = exdate;
		this.extime = extime;
		this.out = out;
		this.shipped = shipped;
		this.merchant = merchant;
		this.cname = cname;
		this.cmob = cmob;
		this.cadd = cadd;
	}


	public Product(String pname, String pcategory, String dedate, String detime, String exdate, String extime,
			String out, String shipped, String merchant, String cname, String cmob, String cadd) {
		super();
		this.pname = pname;
		this.pcategory = pcategory;
		this.dedate = dedate;
		this.detime = detime;
		this.exdate = exdate;
		this.extime = extime;
		this.out = out;
		this.shipped = shipped;
		this.merchant = merchant;
		this.cname = cname;
		this.cmob = cmob;
		this.cadd = cadd;
	}


	
}
