package com.cg.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Product;
import com.cg.services.ProductService;

@RestController
@RequestMapping("")

public class ProductController {

	@Autowired private ProductService service;
	
	
	@GetMapping(value="/getbyid" , produces= {"application/json","application/xml" })
	public Product search(@RequestParam Integer id) { 
		return service.findById(id);
	}
	
	@PutMapping(value="/update",consumes={"application/json","application/xml"})
	public ResponseEntity<String> update(@RequestBody Product emp) {
		service.update(emp);
		return new ResponseEntity<String>("Record updated!",HttpStatus.OK);
	}
	
	
	@DeleteMapping(value="/delete")
	public ResponseEntity<String> delete(@RequestParam Integer id) {
		service.delete(id);
		return new ResponseEntity<String>("DISPATCHED REPORTS OF THE PRODUCTS IS SUCCESSFULLY DELETED",HttpStatus.OK);
	}
	

	@RequestMapping(value="/create",
			consumes= {"application/json","application/xml"})
	public ResponseEntity<String> create(@RequestBody Product emp){
//		System.out.println("Processing employee "+emp.getEmpid());
		service.save(emp);
		//Return Response body "Record Created" with response status=201
		return new ResponseEntity<String>("DISPATCHED REPORTS OF THE PRODUCTS IS SUCCESSFULLY CREATED",HttpStatus.OK);
	}
	@GetMapping("/allproducts")
	public List<Product> findAll() {
		List<Product> emp = service.findAll();
		return emp;
	}
}
