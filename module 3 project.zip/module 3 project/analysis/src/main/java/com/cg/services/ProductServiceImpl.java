package com.cg.services;

import java.util.List;



import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ProductDao;
import com.cg.entities.Product;
import com.cg.exceptions.ApplicationException;

@Service
public class ProductServiceImpl 
	implements ProductService {

	@Autowired private ProductDao dao;

	@Override
	public void save(Product emp) {
		// TODO Auto-generated method stub
		System.out.println("Saving Product: "+emp.getId());
		if(dao.existsById(emp.getId())) {
			throw new ApplicationException("Record already exists!");
		}
		dao.save(emp);
		
	}

	@Override
	public void update(Product emp) {
		// TODO Auto-generated method stub
		System.out.println("Updating Product: "+emp.getId());
		if(! dao.existsById(emp.getId())) {
			throw new ApplicationException("Record did not exists!"); 
		}
		dao.save(emp);
		
	}

	@Override
	public void delete(Integer id) {
		// TODO Auto-generated method stub
		System.out.println("Deleting Product: "+id);
		if(!dao.existsById(id)) {
			throw new ApplicationException("Unable to delete, record not found!");
		}
		dao.deleteById(id);
		
	}

	@Override
	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Product findById(Integer id) {
		// TODO Auto-generated method stub
		System.out.println("Finding Product: "+id);
		Optional<Product> temp = dao.findById(id);
		if(!temp.isPresent()) {
			throw new ApplicationException("Unable to find Product "+id);
		}
		return temp.get();
	}
	
	

}
