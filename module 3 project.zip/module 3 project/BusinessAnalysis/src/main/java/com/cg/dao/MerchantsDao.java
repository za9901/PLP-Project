package com.cg.dao;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cg.entities.Merchants;

@Repository
public interface MerchantsDao extends JpaRepository<Merchants,Integer> {



	

}
