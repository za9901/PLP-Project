package com.cg.entities;


import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "merchants")
@SequenceGenerator(name="my_seq",sequenceName="MY_SEQ",initialValue=100, allocationSize=1)
public class Merchants {


	public int getMid() {
		return Mid;
	}
	public void setMid(int mid) {
		Mid = mid;
	}

	@Id
	@Column(name = "Mid")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator="my_seq")
	private int Mid;
	
	@Column(name = "Mname", length = 20)
	private String Mname;

	@Column(name = "Pname", length = 20)
	private Integer Pname;
	
	@Column(name = "Ddate", length = 20)
	public String Ddate;

	@Column(name = "Dtime", length = 20)
	public String Dtime;
	
	@Column(name = "DEdate", length = 20)
	public String DEdate;

	@Column(name = "DEtime", length = 20)
	public String DEtime;
	
	@Column(name = "Cname", length = 20)
	public String Cname;

	@Column(name = "Cmob", length = 20)
	public String Cmob;
	

	public String getMname() {
		return Mname;
	}
	public void setMname(String mname) {
		Mname = mname;
	}
	public Integer getPname() {
		return Pname;
	}
	public void setPname(Integer pname) {
		Pname = pname;
	}
	public String getDdate() {
		return Ddate;
	}
	public void setDdate(String ddate) {
		Ddate = ddate;
	}
	public String getDtime() {
		return Dtime;
	}
	public void setDtime(String dtime) {
		Dtime = dtime;
	}
	public String getDEdate() {
		return DEdate;
	}
	public void setDEdate(String dEdate) {
		DEdate = dEdate;
	}
	public String getDEtime() {
		return DEtime;
	}
	public void setDEtime(String dEtime) {
		DEtime = dEtime;
	}
	public String getCname() {
		return Cname;
	}
	public void setCname(String cname) {
		Cname = cname;
	}
	public String getCmob() {
		return Cmob;
	}
	public void setCmob(String cmob) {
		Cmob = cmob;
	}

	
	@Override
	public String toString() {
		return "Merchants [Mid=" + Mid + ", Mname=" + Mname + ", Pname=" + Pname + ", Ddate=" + Ddate + ", Dtime="
				+ Dtime + ", DEdate=" + DEdate + ", DEtime=" + DEtime + ", Cname=" + Cname + ", Cmob=" + Cmob + "]";
	}
	public Merchants(int mid, String mname, Integer pname, String ddate, String dtime, String dEdate, String dEtime,
			String cname, String cmob) {
		super();
		Mid = mid;
		Mname = mname;
		Pname = pname;
		Ddate = ddate;
		Dtime = dtime;
		DEdate = dEdate;
		DEtime = dEtime;
		Cname = cname;
		Cmob = cmob;
	}
	public Merchants() {
		
                   }
}
