package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusinessAnalysisApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusinessAnalysisApplication.class, args);
		System.out.println("WELCOME TO THE PRODUCTS DISPATCHED REPORT GENERATION");
	}

}
