package com.cg.employee.client;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.service.EmployeeService;
import com.cg.employee.service.EmployeeServiceImpl;

public class MainClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		EmployeeService service = 
				new EmployeeServiceImpl();
		int choice = 0;
		
		do
		{
			System.out.println("1-Add Employee");
			System.out.println("2-Search Employee");
			System.out.println("3-Display all Employees");
			System.out.println("Enter your choice ::");
			choice = sc.nextInt();
			switch(choice)
			{
			case 1 : System.out.println("Enter name::");
			String name = sc.next();
			System.out.println("Enter salary::");
			int sal = sc.nextInt();
			Employee emp = service.addEmployee(name,sal);
			System.out.println("successfully added");
			System.out.println("id = "+emp.getEmpId());
			break;
			
			case 2 : System.out.println("Enter id to search::");
			int id = sc.nextInt();
				Employee emp1=null;
				try {
					emp1 = service.searchEmployee(id);
				} catch (EmployeeException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
			System.out.println(emp1);
			break;
			
			case 3 : System.out.println("Employees::");
			HashMap<Integer,Employee>map = null;
				try {
					map = service.getAllEmployees();
				} catch (EmployeeException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
			Set<Integer>keys = map.keySet();
			for(Integer key : keys)
			{
				System.out.println(map.get(key));
			}
			break;
			}
			System.out.println("Do you want to continue 1-yes 0-No");
			choice = sc.nextInt();
		}while(choice!=0);
	}

}
