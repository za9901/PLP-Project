package com.cg.employee.exception;

public class EmployeeException extends Exception{
	
	String message;
	
	public EmployeeException(String msg)
	{
		this.message = msg;
	}
	@Override
	public String getMessage()
	{
		return message;
	}

}
