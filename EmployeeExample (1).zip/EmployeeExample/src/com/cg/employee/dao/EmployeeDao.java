package com.cg.employee.dao;

import java.util.HashMap;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public interface EmployeeDao {

	Employee addEmployee(Employee emp);
	Employee searchEmployee(int empId)throws EmployeeException;
	HashMap<Integer,Employee> getAllEmployees();
	
}
