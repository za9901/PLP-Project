package com.cg.employee.service;

import java.util.HashMap;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public interface EmployeeService {

	Employee addEmployee(String name,int salary);
	Employee searchEmployee(int empId)throws EmployeeException;
	HashMap<Integer,Employee> getAllEmployees()throws EmployeeException;
}
