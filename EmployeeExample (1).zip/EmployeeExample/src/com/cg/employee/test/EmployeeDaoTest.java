package com.cg.employee.test;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.employee.dao.EmployeeDao;
import com.cg.employee.dao.EmployeeDaoImpl;
import com.cg.employee.service.EmployeeService;
import com.cg.employee.service.EmployeeServiceImpl;

public class EmployeeDaoTest {

	EmployeeServiceImpl ref;
	EmployeeDao dao = new EmployeeDaoImpl();
	
	@Before
	public void init()
	{
		ref = new EmployeeServiceImpl();
		ref.setDao(dao);
	}
	@Test
	public void testAddEmployee()
	{
		Assert.assertNotNull(ref.addEmployee("abc",20000));
	}
	@After
	public void destroy()
	{
		dao = null;
		ref = null;
	}
}
