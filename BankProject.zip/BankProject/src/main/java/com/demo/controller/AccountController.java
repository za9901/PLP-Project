package com.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.Account;
import com.demo.service.AccountService;

@RestController
@RequestMapping("/account")

public class AccountController {
	@Autowired
	AccountService accountservice;
	@RequestMapping(value="/all", method=RequestMethod.GET)
	public List<Account> getallaccounts(){
		return this.accountservice.getallaccounts();
	}
	
	@RequestMapping(value="/addaccount", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	public Account addAccount(@RequestBody Account account) {
		return this.accountservice.addAccount(account);
	}
	
	@RequestMapping(value="/updateaccount", method= RequestMethod.PUT, consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	public Account updateUser(@RequestBody Account account) {
		return this.accountservice.updateAccount(account);
		
	}
	 @RequestMapping(value= "/{id}", method= RequestMethod.GET)
	public Optional<Account> getAccount(@PathVariable int accountid){
		return this.accountservice.getAccountByAccountId(accountid);
	}
	 @RequestMapping(value="/all", method=RequestMethod.DELETE)
	 public  void deleteAccounts() {
		 this.accountservice.deleteAllAccounts();
	 }
	 @RequestMapping(value="/{id}", method=RequestMethod.DELETE)
	 public void deleteAccountById(@PathVariable int accountid) {
		 this.accountservice.deleteAccountById(accountid);
		 
	 }
}
