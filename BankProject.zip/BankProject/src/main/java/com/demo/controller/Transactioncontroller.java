package com.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.Account;
import com.demo.entity.Transaction;
import com.demo.service.TransactionService;

@RestController
@RequestMapping("/transaction")

public class Transactioncontroller {

	@Autowired
	TransactionService transactionservice;
	@RequestMapping(value="/all", method=RequestMethod.GET)
	public List<Transaction> getallTransactions(){
		return this.transactionservice.getAllTransactions();
	}
	
	@RequestMapping(value="/addtransaction", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	public Transaction addTransaction(@RequestBody Transaction transaction) {
		return this.transactionservice.addTransaction(transaction);
	}
	
	@RequestMapping(value="/updatetransaction", method= RequestMethod.PUT, consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	public Transaction updateTransaction(@RequestBody Transaction transaction) {
		return this.transactionservice.updateTransaction(transaction);
		
	}
	 @RequestMapping(value= "/{id}", method= RequestMethod.GET)
	public Optional<Transaction> getTraansactionBYId(@PathVariable int transactionid){
		return this.transactionservice.getTransactionById(transactionid);
	}
	 @RequestMapping(value="/all", method=RequestMethod.DELETE)
	 public  void deleteTransactions() {
		 this.transactionservice.deleteAllTransactions();
	 }
	 @RequestMapping(value="/{id}", method=RequestMethod.DELETE)
	 public void deleteTransactionById(@PathVariable int transactionid) {
		 this.transactionservice.deleteTransactionById(transactionid);
		 
	 }

}
