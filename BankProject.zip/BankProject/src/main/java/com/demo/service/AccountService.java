package com.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.AccountDao;
import com.demo.entity.Account;

@Service

public class AccountService {
	@Autowired
	AccountDao accountdao;
	
	public List<Account> getallaccounts(){
		return this.accountdao.findAll();
	}
	public Account addAccount(Account account) {
		return this.accountdao.save(account);
	}
	

	public Optional<Account> getAccountByAccountId(int accountid){
		return this.accountdao.findById(accountid);
	}
	
	public Account updateAccount(Account account) {
		return this.accountdao.save(account);
	}
	public void deleteAccountById(int accountid) {
		this.accountdao.deleteById(accountid);
	}
	
	public void deleteAllAccounts() {
		this.accountdao.deleteAll();
	}
	
	public Optional<Account> showBalance(int accountid){
		return this.accountdao.findById(accountid);
	}
	
	public Account deposit(Account account) {
		return this.accountdao.save(account);
	}
	
	public Account withdraw(Account account) {
		return this.accountdao.save(account);
	}
	public Account fundTransfer(Account account) {
		return this.accountdao.save(account);
}
}