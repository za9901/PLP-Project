package com.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.entity.Transaction;

public interface TransactionDao extends JpaRepository<Transaction, Integer>{

}
