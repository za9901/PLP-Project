package com.cg.entities;

import javax.persistence.*;
import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement //Mark this class for XML conversion
@Entity
@Table(name="employees")
public class Employee implements Serializable{

	@Id @Column(name="empid")
	private Integer empid;
	
	@Column(name="name",length=20)
	private String name;
	
	@Column(name="designation",length=20)
	private String designation;
	
	@Column(name="salary")
	private Double salary;
	
	@Column(name="deptname",length=20)
	private String deptname;
public Employee() {
	// TODO Auto-generated constructor stub
}
public Employee(Integer empid, String name, String designation, Double salary, String deptname) {
	super();
	this.empid = empid;
	this.name = name;
	this.designation = designation;
	this.salary = salary;
	this.deptname = deptname;
}
public Integer getEmpid() {
	return empid;
}
public void setEmpid(Integer empid) {
	this.empid = empid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public Double getSalary() {
	return salary;
}
public void setSalary(Double salary) {
	this.salary = salary;
}
public String getDeptname() {
	return deptname;
}
public void setDeptname(String deptname) {
	this.deptname = deptname;
}
	
}