package com.cg.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Employee;
import com.cg.services.EmployeeService;

@RestController
@RequestMapping("")

public class EmployeeController {

	@Autowired private EmployeeService service;
	
	
	@GetMapping(value="/getbyid" , produces= {"application/json","application/xml" })
	public Employee search(@RequestParam Integer id) { 
		return service.findById(id);
	}
	
	@PutMapping(value="/update",consumes={"application/json","application/xml"})
	public ResponseEntity<String> update(@RequestBody Employee emp) {
		service.update(emp);
		return new ResponseEntity<String>("Record updated!",HttpStatus.OK);
	}
	
	
	@DeleteMapping(value="/delete")
	public ResponseEntity<String> delete(@RequestParam Integer id) {
		service.delete(id);
		return new ResponseEntity<String>("Record deleted!",HttpStatus.OK);
	}
	

	@PostMapping(value="/create",
			consumes= {"application/json","application/xml"})
	public ResponseEntity<String> create(@RequestBody Employee emp){
		System.out.println("Processing employee "+emp.getEmpid());
		service.save(emp);
		//Return Response body "Record Created" with response status=201
		return new ResponseEntity<String>("Record Created",HttpStatus.OK);
	}
	@GetMapping("/employees")
	public List<Employee> findAll() {
		List<Employee> emp = service.findAll();
		return emp;
	}
}