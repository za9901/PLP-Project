package com.cg.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.EmployeeDao;
import com.cg.entities.Employee;
import com.cg.exceptions.ApplicationException;

@Service
public class EmployeeServiceImpl 
	implements EmployeeService {

	@Autowired private EmployeeDao dao;

	@Override
	public void save(Employee emp) {
		// TODO Auto-generated method stub
		System.out.println("Saving employee: "+emp.getEmpid());
		if(dao.existsById(emp.getEmpid())) {
			throw new ApplicationException("Record already exists!");
		}
		dao.save(emp);
		
	}

	@Override
	public void update(Employee emp) {
		// TODO Auto-generated method stub
		System.out.println("Updating employee: "+emp.getEmpid());
		if(! dao.existsById(emp.getEmpid())) {
			throw new ApplicationException("Record did not exists!"); 
		}
		dao.save(emp);
		
	}

	@Override
	public void delete(Integer id) {
		// TODO Auto-generated method stub
		System.out.println("Deleting employee: "+id);
		if(!dao.existsById(id)) {
			throw new ApplicationException("Unable to delete, record not found!");
		}
		dao.deleteById(id);
		
	}

	@Override
	public List<Employee> findAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Employee findById(Integer id) {
		// TODO Auto-generated method stub
		System.out.println("Finding employee: "+id);
		Optional<Employee> temp = dao.findById(id);
		if(!temp.isPresent()) {
			throw new ApplicationException("Unable to find employee "+id);
		}
		return temp.get();
	}
	
	
}
