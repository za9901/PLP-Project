package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Product;
import com.cg.service.ProductService;

@RestController
public class ProductRestController {

	@Autowired
	ProductService productService;

	@Autowired
	Product product;

	// post
	// http://localhost:8083/add/126/radha/toshiba/50000
	@PostMapping("/add/{id}/{name}/{model}/{price}")
	public Product addProduct(@PathVariable String id, @PathVariable String name, @PathVariable String model,
			@PathVariable double price) {
		product.setId(id);
		product.setName(name);
		product.setModel(model);
		product.setPrice(price);

		Product savedpro = productService.addProduct(product);
		return savedpro;

	}
	// get
	// http://localhost:8083/viewall
	@GetMapping("/viewall")
	public List<Product> viewAll() {
		return productService.getProducts();

	}
	
	//post
	//http://localhost:8083/updateobject
	@PostMapping(value = "/updateobject", consumes = {MediaType.APPLICATION_JSON_VALUE})
	public Product updateEmpObject(@RequestBody Product product) {
		Product updatedpro=productService.updateProduct(product);
		return updatedpro;
		
	}
	
	// delete
		// http://localhost:8083/deletebyid/123
		@DeleteMapping("/deletebyid/{id}")
		public String deleteById(@PathVariable String id) {
			productService.deleteById(id);
			return id + " is deleted";
		}
		
		//get
		// http://localhost:8083/findbyid/125
		@GetMapping("/findbyid/{id}")
		public Product findById(@PathVariable String id) {
			return productService.findById(id);
			
		}
		
		//get
		//http://localhost:8083/pricerange/30000/70000
		@GetMapping("pricerange/{price1}/{price2}")
		public List<Product> priceRange(@PathVariable Double price1, @PathVariable Double price2) {
			return productService.priceRange(price1, price2);
		}

}