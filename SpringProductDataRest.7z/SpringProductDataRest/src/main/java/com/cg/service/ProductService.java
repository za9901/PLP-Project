package com.cg.service;

import java.util.List;

import com.cg.beans.Product;

public interface ProductService {

	public Product addProduct(Product p);

	public List<Product> getProducts();

	public void deleteById(String id);

	public Product findById(String id);

	public Product updateProduct(Product p);

	public List<Product> priceRange(Double price1, Double price2);

}
