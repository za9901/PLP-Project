import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Test2 {
	private WebDriver driver;
	private Map<String, Object> vars;

	@Before
	public void setUp() {
		driver = new FirefoxDriver();
		System.out.println("run before the Test method");
		
	}

	@After
	public void tearDown() {
		driver.quit();
		System.out.println("If you allocate external resources in a Before method you need to release them after the test runs");
	}

	@Test
	public void test1() {
//		Mechanism used to locate elements within a document. In order to create your own locating mechanisms, 
		driver.get(
				"https://www.w3schools.com/html/");
		driver.manage().window().setSize(
				new Dimension(1050, 660));
		driver.findElement(
				By.linkText("â�® Home")).click();
		driver.findElement(
				By.linkText("Try it Yourself Â»"))
				.click();
		vars.put("root",
				driver.getWindowHandle());
		// driver.switchTo().window("vars.get("win7217").toString()");
		driver.findElement(
				By.cssSelector(".w3-hover-white"))
				.click();
		driver.close();
	}
}
