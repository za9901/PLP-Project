import java.sql.Driver;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestExplicitWaits
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		  System.setProperty("webdriver.gecko.driver", "C:\\Users\\Subbu\\Desktop\\work\\eclipse-ws\\SeleniumWebDriver\\libs\\geckodriver.exe");
   	   
		// objects and variables instantiation
		              WebDriver myTestDriver = new FirefoxDriver();
		              
		//WebDriver myTestDriver = new FirefoxDriver();
		myTestDriver.get("http://jsfiddle.net/tKQFN/");
		
		//WebDriverWait wait = new WebDriverWait(myTestDriver,10);
		myTestDriver.manage().window().maximize();

		try{
			WebElement myDynamicElement = (new WebDriverWait(myTestDriver, 30))
					  .until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='login']")));
			System.out.println("Going to click!");
			myDynamicElement.click();
			}
		catch (TimeoutException e) 
		{
			System.out.println(e);
		}
		System.out.println("link is clickable!");
		myTestDriver.quit();
	}
}

