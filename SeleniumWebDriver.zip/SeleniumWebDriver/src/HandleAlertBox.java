import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

public class HandleAlertBox
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
//		File firefoxPath = new File("C:/Program Files/Mozilla Firefox/firefox.exe");
//		FirefoxProfile firefoxProfile = new FirefoxProfile();
//		FirefoxBinary binary = new FirefoxBinary(firefoxPath);		
//		WebDriver driver = new FirefoxDriver(binary,firefoxProfile);
	
		  System.setProperty("webdriver.gecko.driver", "C:\\Users\\Subbu\\Desktop\\work\\eclipse-ws\\SeleniumWebDriver\\libs\\geckodriver.exe");
   	   
		// objects and variables instantiation
		              WebDriver driver = new FirefoxDriver();
		String alertMessage; 
		driver.get("file:///C:/Users/Subbu/Desktop/work/eclipse-ws/html-pages/AlertExample.html");
		
		driver.findElement(By.name("btnAlert")).click();
		alertMessage = driver.switchTo().alert().getText();
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        driver.switchTo().alert().accept();
        System.out.println(alertMessage);
        driver.close();
	}

}
