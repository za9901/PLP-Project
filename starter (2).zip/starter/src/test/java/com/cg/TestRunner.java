package com.cg;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
//@CucumberOptions(plugin = {"pretty", "html:Folder_name"},
//                           features="path",
//                           glue="StepDefinitionPath")
public class TestRunner {

}
