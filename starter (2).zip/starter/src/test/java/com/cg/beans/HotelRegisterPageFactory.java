package com.cg.beans;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class HotelRegisterPageFactory {

	WebDriver driver;
	@FindBy(name="txtUserName")
	@CacheLookup
	WebElement txtUserName;
	
	@FindBy(xpath="//*[@id=\"errMsg\"]")
	WebElement Error;
	
	//using How 
		@FindBy(how=How.NAME, using="txtPwd")
		@CacheLookup
		WebElement password;

		@FindBy(className="btn")
		@CacheLookup
		WebElement registerButton;
}
