package com.rechargebean;

public class Recharge {
	public int newbalance;
   	public int getNewbalance() {
		return newbalance;
	}
	public void setNewbalance(int newbalance) {
		this.newbalance = newbalance;
	}
	public int transactionId;
	public String name;
	public String mob;
	public String descp;
	public String type;
	public int rechargeId;
	public int amount;
	public int getRechargeId() {
		return rechargeId;
	}
	public void setRechargeId(int rechargeId) {
		this.rechargeId = rechargeId;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMob() {
		return mob;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	public String getDescp() {
		return descp;
	}
	public void setDescp(String descp) {
		this.descp = descp;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public Recharge(){
		
	}
	public Recharge(int newbalance,String name, String mob, String descp, String type) {
		super();
		this.newbalance=newbalance;
		this.name = name;
		this.mob = mob;
		this.descp = descp;
		this.type = type;
	}
	public Recharge(int rechargeId, String type, int amount) {
		super();
		this.rechargeId=rechargeId;
		this.type=type;
		this.amount=amount;
		
	}
	@Override
	public String toString() {
		return "Recharge [type=" + type + ", rechargeId=" + rechargeId
				+ ", amount=" + amount + "]";
	}
	
	
}

