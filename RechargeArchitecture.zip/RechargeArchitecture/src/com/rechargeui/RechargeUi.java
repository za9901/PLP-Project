package com.rechargeui;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

import com.rechargebean.Recharge;
import com.rechargeexception.RechargeException;
import com.rechargeservice.IRechargeService;
import com.rechargeservice.RechargeService;

public class RechargeUi {
	
	static Scanner scan = new Scanner(System.in);
	static IRechargeService irs=null;
	static String name=null;
	static String mob=null;
	static String descp=null;
	static String type=null;
	static String planName=null;
	static int amount=0;
	static String date=null;
	static int balance=3000;
	static int newbalance=0;
	static int p=0;
	static int rechargeId=0;
	public static void main(String[] args)throws RechargeException{
		
//    System.out.println("enter any option b/1 to 5");
//	System.out.println("1.viewR\n 2.AddRechargeDetails \n 3. DeleteById\n 4.  ViewAllRecharges");
//	System.out.println("5. ViewById \n 6. Update\n 7.updateRecharge\n  ");
//	int a=scan.nextInt();
	String h=null;
do{
	 System.out.println("enter any option b/1 to 5");
		System.out.println("1.viewR\n 2.AddRechargeDetails \n 3. DeleteById\n 4.  ViewAllRecharges");
		System.out.println("5. ViewById \n 6. Update\n 7.updateRecharge\n  ");
		int a=scan.nextInt();
	switch(a){    
	case 2:int finalTransactionId=AddRechargeDetails();
	       System.out.println("Recharge Details are  Added");
	       System.out.println("Recharged Transaction Id is: "+finalTransactionId);
	       break;
	    	
    case 3:System.out.println("Enter The ID to be Deleted");
	       int id=scan.nextInt();
	       DeleteById(id);
	       break;
	    	
	case 4:ViewAllRecharges();
	       break;
	    	
	case 5:System.out.println(" enter the Id Of employee who's name u need");
           int e=scan.nextInt();
           Recharge e1=ViewById(e);
           if(e1!=null){
 	       System.out.println(e1.getName());
 	       System.out.println(e1.getTransactionId());
           }
           else{
 	       System.out.println(" Enter the proper Id");
           }
		   break;
		       
	case 6:System.out.println("Enter opt 1 to update name");
           int opt3;
           do{
  	       opt3=scan.nextInt();
	       if(opt3 == 1){
		   if(updName())
		   System.out.println("Employee name has been changed successfully");
	       else
		   System.out.println("Invalid ID"); 
		   break;
	       }
           }while(opt3>1); 
	       break;
	       
	case 1:viewR();
	       break;
	       
	case 7:     System.out.println("Enter The RechargeId which needs needs to be updated........\n");
	           int rid=new Scanner(System.in).nextInt();
	           Recharge on=irs.updateRecharge(rid);
	           System.out.println("Recharge Information Is Updated:"+on);
	           break;
	           
	default:
	break;
	       }
	       System.out.println("enter y/n to continue");
	       h=scan.next();
	       if(h.equalsIgnoreCase("n")){
	    	  System.out.println("Program Terminated");   
	       }
	       
}while(h.equalsIgnoreCase("y"));}
	
	       private static void viewR() {
	    System.out.println();
	    irs=new RechargeService();
	    HashMap<Integer,Recharge> tlist=irs.viewR();
	    Set r=tlist.entrySet();
	    r.stream().forEach(System.out::println);	
	}

		private static boolean updName() {
		   System.out.println("Enter id of emp whose Name needs  to be changed : ");
		   int id = scan.nextInt();
		   System.out.println("Enter the new Name");
		   String name = scan.next();
		   return irs.updateName(id, name);	
	       }
	
	       private static  Recharge ViewById(int e) {
		   irs=new RechargeService();
		   return irs.ViewById(e);
	       }
	       
           private static void DeleteById(int id) {
		   irs=new RechargeService();
		   irs.DeleteById(id);	
	       }
	
	       private static void ViewAllRecharges() {
		   irs =new RechargeService();
		   irs.ViewAllRecharges();
	       }
	
           private static  int AddRechargeDetails() throws RechargeException {
		   irs=new RechargeService();
do{
		   try{
		   System.out.println("Enter  Customer Name who needs The reacharged ");
		   name=scan.next();
	       boolean	validate=irs.validatename(name);}
		   catch(Exception e){
	       System.out.println("Name Exception");
		   }
}while(irs.validatename(name)==false);
		
do{
			try{
			System.out.println("Enter  mob ");
			mob=scan.next();
	        boolean	validate=irs.validatemob(mob);}
			catch(Exception e){
		    System.out.println("Number Exception");
			}
}while(irs.validatemob(mob)==false);
				
            System.out.println("Enter  TYPE Of PLAN U NEED: ");
			System.out.println("1. PREPAID\n 2.POSTPAID\n ");
			switch(scan.nextInt()){
			case 1:
			type="PREPAID";
			System.out.println("THE TYPE Of PLAN CHOOSEN IS PREPAID:");
			break;
			case 2:
			type="POSTPAID";
			System.out.println("THE TYPE Of PLAN CHOOSEN IS POSTPAID:");
			}
			System.out.println("Enter the options IN THE CHOOSEN PLAN: \n 1.99 \n 2.199 \n 3.299 \n 4.399 \n 5.499");
			switch(scan.nextInt()){ 
			case 1:
			System.out.println("RC 99 has been selected");
			System.out.println("The Amount You Have With You Is:"+balance);
			p=99;
			newbalance=balance-p;
			System.out.println("avilable balance after recharge"+newbalance);
			System.out.println("THANK YOU FOR USING OUR SERVICE");
		    System.out.println("The Date of Recharged is:"+LocalDate.now());                                                                                                                                                                                
			break; 
					
		    case 2:
			System.out.println("RC 199 has been selected");
			System.out.println("The Amount You Have With You Is:"+balance);
			p=199;
			newbalance=balance-p;
			System.out.println("avilable balance after recharge"+newbalance);
			System.out.println("THANK YOU FOR USING OUR SERVICE");
			System.out.println("The Date of Recharged is:"+LocalDate.now());
			break; 
					
		    case 3:
			System.out.println("RC 299 has been selected");
			System.out.println("The Amount You Have With You Is:"+balance);
			p=299;
			newbalance=balance-p;
			System.out.println("avilable balance after recharge"+newbalance);
			System.out.println("THANK YOU FOR USING OUR SERVICE");
			System.out.println("The Date of Recharged is:"+LocalDate.now());
			break; 
					
		    case 4:
			System.out.println("RC 399 has been selected");
			System.out.println("The Amount You Have With You Is:"+balance);
			p=399;
			newbalance=balance-p;
			System.out.println("avilable balance after recharge"+newbalance);
			System.out.println("THANK YOU FOR USING OUR SERVICE");
			System.out.println("The Date of Recharged is:"+LocalDate.now());
		    break; 
					
			case 5:
			System.out.println("RC 499 has been selected");
			System.out.println("The Amount You Have With You Is:"+balance);
			p=499;
			newbalance=balance-p;
			System.out.println("avilable balance after recharge"+newbalance);
			System.out.println("THANK YOU FOR USING OUR SERVICE");
			System.out.println("The Date of Recharged is:"+LocalDate.now());
			break; 
            }
		
do{
			try{
			System.out.println("Enter  description ");
			descp=scan.next();
		    boolean	validate=irs.validatedescp(descp);}
		    catch(Exception e){
			System.out.println("String Exception");
		    }
}while(irs.validatedescp(descp)==false);

    		Recharge rc=new Recharge( newbalance, name,  mob,  descp,type);
   		Recharge rb=new Recharge(rechargeId,type,amount);
	    	int aid=irs.AddRechargeDetails(rc);
		    return aid;
	        }}
