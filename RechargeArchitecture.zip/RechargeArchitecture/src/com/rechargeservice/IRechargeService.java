package com.rechargeservice;
import java.util.HashMap;

import com.rechargebean.Recharge;
import com.rechargeexception.RechargeException;

public interface IRechargeService {
	
	public int AddRechargeDetails(Recharge r);
	public void ViewAllRecharges();
	void DeleteById(int id);
	public boolean validatename(String name) throws RechargeException;
	public boolean validatemob(String mob) throws RechargeException;
	public boolean validatedescp(String descp) throws RechargeException;
	public Recharge ViewById(int e);
	boolean updateName(int id, String name);
	public HashMap<Integer,Recharge> viewR();
	Recharge updateRecharge(int id) throws RechargeException;
}
