package com.rechargeservice;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.rechargebean.Recharge;
import com.rechargedao.IRechargeDao;
import com.rechargedao.RechargeDao;
import com.rechargeexception.RechargeException;

public class RechargeService implements IRechargeService{
	
	IRechargeDao irao=null;
	private int generateTransactionId(){
	int id=0;
	id=(int) (Math.random()*10000);
	return id;
	}

	@Override
	public int AddRechargeDetails(Recharge r) {
	r.setTransactionId(generateTransactionId());
	irao=new RechargeDao();
	return irao.AddRechargeDetails(r);			
	}

	@Override
	public void DeleteById(int id) {
	irao=new RechargeDao();
	irao.DeleteById(id);	
	}

	@Override
	public void ViewAllRecharges() {
	irao=new RechargeDao();
	irao.ViewAllRecharges();
	}

	@Override
	public boolean updateName(int id,String name) {
	return irao.updateName(id,name);
	}

	@Override
	public Recharge ViewById(int e) {
	irao=new RechargeDao();
	return irao.ViewById(e);
	}

	@Override
	public boolean validatename(String name) throws RechargeException{
	Pattern p=Pattern.compile("^[A-Z][a-z]{3,}");
	Matcher m=p.matcher(name);
	if(m.find()){
	return true;
	}
    else {
	throw new RechargeException(" name error");}}
	
	@Override
	public boolean validatemob(String mob) throws RechargeException{
	Pattern p=Pattern.compile("^[7-9][0-9]{9,}");
	Matcher m=p.matcher(mob);
	if(m.find()){		
	return true;
	}
	else {
	throw new RechargeException(" mob error");}}
		

	@Override
	public boolean validatedescp(String descp) throws RechargeException{
	Pattern p=Pattern.compile("^[A-Z][a-z]{6,}");
	Matcher m=p.matcher(descp);
	if(m.find()){		
	return true;
	}
	else {
	throw new RechargeException(" Description error");}}

	@Override
	public HashMap<Integer, Recharge> viewR() {
		irao=new RechargeDao();
		return irao.viewR();
		
	}

	@Override
	public Recharge updateRecharge(int id) throws RechargeException {
		irao=new RechargeDao();
		return irao.updateRecharge(id);
	}
    }
