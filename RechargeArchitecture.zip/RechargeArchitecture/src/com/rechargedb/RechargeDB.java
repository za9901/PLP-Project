package com.rechargedb;
import java.util.HashMap;
import com.rechargebean.Recharge;

public class RechargeDB {

	static HashMap<Integer,Recharge> tlist=new HashMap<Integer,Recharge>();
	static Recharge t1=new Recharge(10001,"PREPAID",3000);
	static Recharge t2=new Recharge(10002,"POSTPAID",3000);
	static Recharge t3=new Recharge(10003,"PREPAID",3000);
	static Recharge t4=new Recharge(10004,"LOCAL",3000);
	static Recharge t5=new Recharge(10005,"POSTPAID",3000);
	
	
	public static HashMap<Integer,Recharge> getRecharges(){
		tlist.put(t1.getRechargeId(), t1);
		tlist.put(t2.getRechargeId(), t2);
		tlist.put(t3.getRechargeId(), t3);
		tlist.put(t4.getRechargeId(), t4);
		tlist.put(t5.getRechargeId(), t5);
		return tlist;
	}
	
}
