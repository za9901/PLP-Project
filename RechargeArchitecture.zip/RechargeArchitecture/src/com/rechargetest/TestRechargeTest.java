package com.rechargetest;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import com.rechargebean.Recharge;
import com.rechargedao.IRechargeDao;
import com.rechargedao.RechargeDao;

public class TestRechargeTest {
	
	IRechargeDao irao=null;
	@Before
	public void init() {
		irao= new  RechargeDao();
		
	}
	@After
	public void destroy() {
		irao=null;
	}

@Test
public void TestRechargeDetails() {
	Recharge e=new Recharge(3000,"zabi","9620544145","Recharged","PREPAID");
	e.setTransactionId(3001);
	Assert.assertNotNull(e);
}
}

	
