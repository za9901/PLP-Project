package com.rechargedao;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.rechargebean.Recharge;
import com.rechargedb.RechargeDB;
import com.rechargeexception.RechargeException;

public class RechargeDao implements IRechargeDao{
	
	static  Map<Integer,Recharge> tlist=new HashMap<Integer,Recharge>();
     
	@Override
	public int AddRechargeDetails(Recharge r) {
	tlist.put(r.getTransactionId(),r);
	System.out.println(tlist);
	return r.getTransactionId();	
	}

	@Override
	public void DeleteById(int id) {
	Collection<Recharge> e1= tlist.values();
	tlist.remove(id);}
	
	
	@Override
	public void ViewAllRecharges() {
	Collection<Recharge> e1= tlist.values();
	System.out.println(e1);
	for(Recharge rv:e1){
	System.out.println(rv.getTransactionId());}
//	System.out.println(rv.getName());}	
	}
	
	@Override
	public Recharge ViewById(int e) {
	Recharge e2= tlist.get(e);
	if(e2!=null)
	return e2;
	else 
	return null;}

	@Override
	public boolean updateName(int id, String name) {
	Recharge emp = tlist.get(id);
	if(emp!=null) {
	emp.setName(name);
	return true;
	}
	return false;	
	}

	@Override
	public HashMap<Integer, Recharge> viewR() {
		
		return RechargeDB.getRecharges();
	}

	@Override
	public Recharge updateRecharge(int id) throws RechargeException{
		Recharge ob=null;
		if(RechargeDB.getRecharges()==null||RechargeDB.getRecharges().isEmpty()){
			throw new RechargeException("NULL Exception");
		}
		else if(RechargeDB.getRecharges().containsKey(id)){
			ob=RechargeDB.getRecharges().get(id);
		     ob.setRechargeId(10008);
			System.out.println(ob);
		}
		else{
			throw new RechargeException("RECHARGE ID Exception");
		}
		return ob;
	}
	}

