package com.rechargedao;
import java.util.HashMap;

import com.rechargebean.Recharge;
import com.rechargeexception.RechargeException;

public interface IRechargeDao {
	
	public int AddRechargeDetails(Recharge r);
	public void ViewAllRecharges();
	public void DeleteById(int id);
	Recharge ViewById(int e);
	public boolean updateName(int id, String name);
	public HashMap<Integer,Recharge> viewR();
	Recharge updateRecharge(int id) throws  RechargeException;
	

}
