package com.rechargeexception;

public class RechargeException extends Exception {

	public RechargeException(String ce) {
	   super(ce);
	}
	

}
