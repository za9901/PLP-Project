package stepdefinition;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowserFactory;
import com.cg.page.EducationalPage;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationalStepDef {

	static WebDriver driver;
	EducationalPage educationalPage;
	
	
	@Before
	public void start() {
		driver = BrowserFactory.startBrowser("chrome",
				"D:\\Users\\banuprr\\Selenium\\177370_Banupriya\\src\\test\\java\\html\\EducationalDetails.html");
	}

	@After
	public void tearDown() {
		driver.close();
	}
	
	@Given("^user is in the educational details page$")
	public void user_is_in_the_educational_details_page() throws Throwable {
	   educationalPage=PageFactory.initElements(driver, EducationalPage.class);
	}

	@Then("^verify the Title of the page$")
	public void verify_the_Title_of_the_page() throws Throwable {
		assertEquals("Educational Details", educationalPage.titlename());
		if (educationalPage.titlename().equals("Educational Details")) {
			System.out.println("Title matched");
		} else {
			System.out.println("Title not matched");
		}
	}

	@Then("^verify the Heading of the page$")
	public void verify_the_Heading_of_the_page() throws Throwable {
		assertEquals("Step 2: Educational Details", educationalPage.headingname());
		if (educationalPage.headingname().equals("Step 2: Educational Details")) {
			System.out.println("Heading matched");
		} else {
			System.out.println("Heading not matched");
		}
	}

	@When("^user doesn't select the graduation$")
	public void user_doesn_t_select_the_graduation() throws Throwable {
	    educationalPage.setGraduation("");
	    educationalPage.setPercentage("88");
	    educationalPage.setPassingYear("2018");
	    educationalPage.setProjectName("Java");
	    educationalPage.setTechnologyUsed("java");
	    educationalPage.setOtherTechnology("selenium");
	    educationalPage.registerbtnclick();
	}

	@Then("^alert message please select the graduation$")
	public void alert_message_please_select_the_graduation() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
		String msg = alt.getText();
		assertEquals("Please Select Graduation", msg);
		if (msg.equals("Please Select Graduation")) {
			System.out.println("The text msg on alert box is " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user leaves percentage empty$")
	public void user_leaves_percentage_empty() throws Throwable {
	    educationalPage.setPercentage("");
	    educationalPage.registerbtnclick();
	}

	@Then("^display percentage alert message$")
	public void display_percentage_alert_message() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("Please fill Percentage detail", msg);
			if (msg.equals("Please fill Percentage detail")) {
				System.out.println("The text msg on alert box is " + msg);
			} else {
				System.out.println("The text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@When("^user leaves passingYear empty$")
	public void user_leaves_passingYear_empty() throws Throwable {
	   educationalPage.setPassingYear("");
	   educationalPage.registerbtnclick();
	}

	@Then("^display passingYear alert message$")
	public void display_passingYear_alert_message() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("Please fill Passing Year", msg);
			if (msg.equals("Please fill Passing Year")) {
				System.out.println("The text msg on alert box is " + msg);
			} else {
				System.out.println("The text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@When("^user leaves projectName empty$")
	public void user_leaves_projectName_empty() throws Throwable {
	    educationalPage.setProjectName("");
	    educationalPage.registerbtnclick();
	}

	@Then("^display projectName alert message$")
	public void display_projectName_alert_message() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("Please fill Project Name", msg);
			if (msg.equals("Please fill Project Name")) {
				System.out.println("The text msg on alert box is " + msg);
			} else {
				System.out.println("The text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@When("^user doesn't select the technology$")
	public void user_doesn_t_select_the_technology() throws Throwable {
		educationalPage.setGraduation("BE");
		educationalPage.setPercentage("88");
		educationalPage.setPassingYear("2018");
		educationalPage.setProjectName("Java");
		educationalPage.setTechnologyUsed("");
		educationalPage.setOtherTechnology("selenium");
		educationalPage.registerbtnclick();
	}

	@Then("^alert message please select the technology$")
	public void alert_message_please_select_the_technology() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("Please Select Technologies Used", msg);
			if (msg.equals("Please Select Technologies Used")) {
				System.out.println("The text msg on alert box is " + msg);
			} else {
				System.out.println("The text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@When("^user leaves otherTechnology empty$")
	public void user_leaves_otherTechnology_empty() throws Throwable {
	    educationalPage.setOtherTechnology("");
	    educationalPage.registerbtnclick();
	}

	@Then("^display otherTechnology alert message$")
	public void display_otherTechnology_alert_message() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("Please fill other Technologies Used", msg);
			if (msg.equals("Please fill other Technologies Used")) {
				System.out.println("The text msg on alert box is " + msg);
			} else {
				System.out.println("The text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@When("^user enters valid credentials and clicks MakePayment$")
	public void user_enters_valid_credentials_and_clicks_MakePayment() throws Throwable {
		educationalPage.setGraduation("BE");
	    educationalPage.setPercentage("88");
	    educationalPage.setPassingYear("2018");
	    educationalPage.setProjectName("Java");
	    educationalPage.setTechnologyUsed("Java");
	    educationalPage.setOtherTechnology("selenium");
	    educationalPage.registerbtnclick();
	}

	@Then("^registered successfully$")
	public void registered_successfully() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			Thread.sleep(1000);
			String msg = alt.getText();
			assertEquals("Your Registration Has succesfully done Plz check you registerd email for account activation link !!!", msg);
			if (msg.equals("Your Registration Has succesfully done Plz check you registerd email for account activation link !!!")) {
				System.out.println("The text msg on alert box is " + msg);
			} else {
				System.out.println("The text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	}


