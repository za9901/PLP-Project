package ReturnGoods;

import cucumber.api.java.en.Given;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {


	@Given("^Open My Orders page$")
	public void open_My_Orders_page() throws Throwable {


	}

	@When("^The purchase date is less than (\\d+) days ago from Current Date$")
	public void the_purchase_date_is_less_than_days_ago_from_Current_Date(int arg1) throws Throwable {


	}

	@Then("^Initiate Return Goods$")
	public void initiate_Return_Goods() throws Throwable {


	}

	@When("^The purchase date is more than (\\d+) days ago from Current Date$")
	public void the_purchase_date_is_more_than_days_ago_from_Current_Date(int arg1) throws Throwable {


	}

	@Then("^Cant Return Goods$")
	public void cant_Return_Goods() throws Throwable {


	}


}
