package wishlist;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {



	@Given("^Open list of Product Page$")
	public void open_list_of_Product_Page() throws Throwable {


	}

	@When("^Clicked on add to wishlist for a particular product$")
	public void clicked_on_add_to_wishlist_for_a_particular_product() throws Throwable {


	}

	@Then("^Add to Wishlist$")
	public void add_to_Wishlist() throws Throwable {


	}

	@Given("^Open Wishlist Page$")
	public void open_Wishlist_Page() throws Throwable {


	}

	@When("^Clicked on Add to cart for a particular product$")
	public void clicked_on_Add_to_cart_for_a_particular_product() throws Throwable {


	}

	@Then("^Add to Cart$")
	public void add_to_Cart() throws Throwable {


	}

	@When("^Clicked on Remove from wishlist for a particular product$")
	public void clicked_on_Remove_from_wishlist_for_a_particular_product() throws Throwable {


	}

	@Then("^Remove from Wishlist$")
	public void remove_from_Wishlist() throws Throwable {


	}

}
