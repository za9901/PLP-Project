package com.cg.entities;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "employees")
@SequenceGenerator(name="my_seq",sequenceName="MY_SEQ",initialValue=1000, allocationSize=1)
public class Employee implements Serializable {

	@Id
	@Column(name = "Id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator="my_seq")
	private int Id;

	@Column(name = "name", length = 20)
	private String name;

	@Column(name = "designation", length = 20)
	private String designation;

	@Column(name = "salary")
	private Double salary;

	@Column(name = "deptname", length = 20)
	private String deptname;

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(int id, String name, String designation, Double salary, String deptname) {
		super();
		Id = id;
		this.name = name;
		this.designation = designation;
		this.salary = salary;
		this.deptname = deptname;
	}

	public Employee(String name, String designation, Double salary, String deptname) {
		super();

		this.name = name;
		this.designation = designation;
		this.salary = salary;
		this.deptname = deptname;
	}

	public int getEmpid() {
		return Id;
	}

	public void setEmpid(int Id) {
		this.Id = Id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

}