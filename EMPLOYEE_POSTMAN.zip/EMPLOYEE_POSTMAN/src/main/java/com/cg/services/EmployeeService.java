package com.cg.services;
import java.util.List;

import com.cg.entities.Employee;

public interface EmployeeService {
	
	void save(Employee emp);
	void update(Employee emp);
	void delete(Integer id);
	List<Employee> findAll();
	Employee findById(Integer id);

}