package com.ezbuy.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ezbuy.model.Product;

@Configuration
public class JavaConfig {

	@Bean(name = "product")
	public Product getProduct() {
		Product product = new Product(100, "Red",
				"Sun");
		return product;
	}
	
	@Bean(name = "defaultProduct")
	public Product getDefaultProduct() {
		Product product = new Product();
		return product;
	}
}
