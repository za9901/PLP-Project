package com.cg.BankApp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.BankApp.dao.AccountDao;
import com.cg.BankApp.entity.Account;

@Service
public class AccountService {

	@Autowired
	AccountDao accountdao;
	
	public List<Account> getAllAccounts(){
		return accountdao.findAll();
	}

	public Account addAccount(Account account) {
		return accountdao.save(account);
	}
	
	public Account updateAccount(Account account) {
		return accountdao.save(account);
	}
	
	public Optional<Account> getAccountById(int id) {
		return accountdao.findById(id);
	}
	
	public void deleteAccount(Account account) {
		accountdao.delete(account);
	}
	
	public void deleteAllAccount() {
		accountdao.deleteAll();
	}
}
