package com.cg.BankApp.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.BankApp.dao.TransactionDao;
import com.cg.BankApp.entity.Transaction;

@Service
public class TransactionService {
	
	@Autowired
	TransactionDao transactionDao;
	
	public List<Transaction> getAllTransactions(){
		return transactionDao.findAll();
	}

	public Transaction addTransaction(Transaction transaction) {
		return transactionDao.save(transaction);
	}
	
	public Transaction updateTransaction(Transaction transaction) {
		return transactionDao.save(transaction);
	}
	
	public Optional<Transaction> getTransactionById(int id) {
		return transactionDao.findById(id);
	}
	
	public void deleteTransaction(Transaction transaction) {
		transactionDao.delete(transaction);
	}
	
	public void deleteAllTransaction() {
		transactionDao.deleteAll();
	}

}
