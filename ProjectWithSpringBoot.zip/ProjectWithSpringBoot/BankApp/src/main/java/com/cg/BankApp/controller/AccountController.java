package com.cg.BankApp.controller;

import java.awt.PageAttributes.MediaType;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
import com.cg.BankApp.entity.Account;
import com.cg.BankApp.entity.Transaction;
import com.cg.BankApp.service.AccountService;
import com.cg.BankApp.service.TransactionService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/account")
public class AccountController {
	
	@Autowired
	AccountService accountService;
	
	@Autowired
	TransactionService transactionService;
	
	@RequestMapping(value="/all", method=RequestMethod.GET)
	public List<Account> getAllAccounts(){
		return accountService.getAllAccounts();
	}
	
	@RequestMapping(value="/{id}", method=RequestMethod.GET)
	public Optional<Account> getAccountById(@PathVariable int id){
		return accountService.getAccountById(id);
	}
	
	@RequestMapping(value="/add", method=RequestMethod.POST, consumes=org.springframework.http.MediaType.APPLICATION_JSON_VALUE, produces=org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public Account addAccount(@RequestBody Account account){
		return accountService.addAccount(account);
	}
	
	@RequestMapping(value="/update", method=RequestMethod.PUT)
	public Account updateAccount(@RequestBody Account account){
		return accountService.updateAccount(account);
	}
	
	@RequestMapping(value="/delete", method=RequestMethod.DELETE)
	public void deleteAccount(@RequestBody Account account){
		accountService.deleteAccount(account);
	}
	
	@RequestMapping(value="/all", method=RequestMethod.DELETE)
	public void deleteAllAccount(){
		accountService.deleteAllAccount();
	}
	
	@RequestMapping(value="/fund/{id}/{id1}/{amount}", method=RequestMethod.POST)
	public void fundTransfer(@PathVariable int id, @PathVariable int id1,@PathVariable int amount){
		Account account = accountService.getAccountById(id).get();
		Account account1 = accountService.getAccountById(id1).get();
		account.setOpeningBalance(account.getBalance() - amount);
		account1.setOpeningBalance(account1.getBalance() + amount);
		accountService.updateAccount(account);
		accountService.updateAccount(account1);
		Transaction transaction = new Transaction(account.getAccountId(), "Withdraw", amount, account.getBalance());
		Transaction transaction1 = new Transaction(account1.getAccountId(), "deposit", amount, account1.getBalance());
		transactionService.addTransaction(transaction);
		transactionService.addTransaction(transaction1);
	}
	
	@RequestMapping(value="/deposit/{id}/{amount}", method=RequestMethod.POST)
	public void depositAmount(@PathVariable int id,@PathVariable int amount){
		Account account = accountService.getAccountById(id).get();
		account.setOpeningBalance(account.getBalance() + amount);
		accountService.updateAccount(account);
		Transaction transaction = new Transaction(account.getAccountId(), "Deposit", amount, account.getBalance());
		transactionService.addTransaction(transaction);
	}
	
	@RequestMapping(value="/withdraw/{id}/{amount}", method=RequestMethod.POST)
	public void withdrawAmount(@PathVariable int id,@PathVariable int amount){
		Account account = accountService.getAccountById(id).get();
		account.setOpeningBalance(account.getBalance() - amount);
		accountService.updateAccount(account);
		Transaction transaction = new Transaction(account.getAccountId(), "Withdraw", amount, account.getBalance());
		transactionService.addTransaction(transaction);
	}
	

}
