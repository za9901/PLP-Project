package com.cg.BankApp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.BankApp.entity.Account;
import com.cg.BankApp.entity.Transaction;
import com.cg.BankApp.service.AccountService;
import com.cg.BankApp.service.TransactionService;

@RestController
@RequestMapping("/transaction")
public class TransactionController {
	
	@Autowired
	TransactionService transactionService;
	
	@RequestMapping(value="/all", method=RequestMethod.GET)
	public List<Transaction> getAllTransactions(){
		return transactionService.getAllTransactions();
	}
	
	@RequestMapping(value="/{id}", method=RequestMethod.GET)
	public Optional<Transaction> getTransactionById(@PathVariable int id){
		return transactionService.getTransactionById(id);
	}
	
	@RequestMapping(value="/add", method=RequestMethod.POST, consumes=org.springframework.http.MediaType.APPLICATION_JSON_VALUE, produces=org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public Transaction addTransaction(@RequestBody Transaction transaction){
		return transactionService.addTransaction(transaction);
	}
	
	@RequestMapping(value="/update", method=RequestMethod.PUT)
	public Transaction updateTransaction(@RequestBody Transaction transaction){
		return transactionService.updateTransaction(transaction);
	}
	
	@RequestMapping(value="/delete", method=RequestMethod.DELETE)
	public void deleteTransaction(@RequestBody Transaction transaction){
		transactionService.deleteTransaction(transaction);
	}
	
	@RequestMapping(value="/all", method=RequestMethod.DELETE)
	public void deleteAllTransaction(){
		transactionService.deleteAllTransaction();
	}
	
}
