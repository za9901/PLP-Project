package com.cg.exception;

public class ErrorInformation {
	String message;
	String url;
	public ErrorInformation(String message, String url) {
		super();
		this.message = message;
		this.url = url;
	}
	public ErrorInformation() {
		super();
		// TODO Auto-generated constructor stub
	}
}
