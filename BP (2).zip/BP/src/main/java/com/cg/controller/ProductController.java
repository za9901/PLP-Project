package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Product;
import com.cg.service.IProductService;

@RestController
public class ProductController {
	@Autowired
	IProductService iProductService;
	@Autowired
	Product product;
	    //POST
		//http://localhost:8083/createproduct
		@PostMapping(value="/create", produces="application/json", consumes= MediaType.APPLICATION_JSON_VALUE)
		public Product createProduct(@RequestBody Product product) {
			return iProductService.createProduct(product);
		}
		//POST 
		//http://localhost:8083/updateproductobject 
		@PostMapping(value="/updateproductobject",consumes= {MediaType.APPLICATION_JSON_VALUE})
		public Product updateProductObject(@RequestBody Product product) {
			Product updateproduct=iProductService.UpdateProduct(product);
			return updateproduct;
		}
		//DELETE
		//http://localhost:8083/deleteproductbyid
		@DeleteMapping("/deleteproductbyid/{id}")
			public void deleteProductById(@PathVariable String id) {
				iProductService.deleteById(id);
			}
		//GET
		//http://localhost:8083/viewproducts
		@GetMapping("/viewproducts")
		public List<Product> viewProducts(){
			return iProductService.getProducts();
		}
		//GET
		//http://localhost:8083/findbyid
		@GetMapping("/findbyid/{id}")
		public Product findById(@PathVariable String id) {
			return iProductService.findById(id);
		}

}
