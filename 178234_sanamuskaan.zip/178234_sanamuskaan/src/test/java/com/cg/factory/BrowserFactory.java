package com.cg.factory;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class BrowserFactory {
	static WebDriver driver;
	public static WebDriver startBrowser(String name,String url) {
		if(name.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver","C:\\Users\\sasheik\\Desktop\\module 4 workspace\\178234_sanamuskaan\\src\\test\\java\\Browser\\chromedriver.exe");
			driver=new ChromeDriver();
		}
		else if(name.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.firefox.driver","C:\\Users\\sasheik\\Desktop\\module 4 workspace\\178234_sanamuskaan\\src\\test\\java\\Browser\\geckodriver.exe");
		    driver=new FirefoxDriver();
		}
	    else  {
		System.setProperty("webdriver.ie.driver","C:\\Users\\sasheik\\Desktop\\module 4 workspace\\178234_sanamuskaan\\src\\test\\java\\Browser\\IEDriverServer.exe");
		driver=new InternetExplorerDriver();
	}
	    driver.get(url);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		return driver;
	}

}
