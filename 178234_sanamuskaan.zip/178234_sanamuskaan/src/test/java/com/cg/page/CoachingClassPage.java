package com.cg.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CoachingClassPage {
	/*
	 * below i have taken variables with private inorder to make it secured 
	 */
	private WebDriver driver;
	
	@FindBy(how=How.ID,using = "fname")
	@CacheLookup
	private WebElement firstname;
	
	@FindBy(how=How.ID,using = "lname")
	@CacheLookup
	private WebElement lastname;
	
	@FindBy(how=How.ID,using = "emails")
	@CacheLookup
	private WebElement email;
	
	@FindBy(how=How.NAME,using = "mobile")
	@CacheLookup
	private WebElement mobile;
	
	@FindBy(how=How.XPATH,using = "/html/body/form/table/tbody/tr[6]/td[2]/select")
	@CacheLookup
	private WebElement typeoftuition;
	
	@FindBy(how=How.XPATH,using = "/html/body/form/table/tbody/tr[7]/td[2]/select")
	@CacheLookup
	private WebElement citypreference;
	
	@FindBy(how=How.XPATH,using = "/html/body/form/table/tbody/tr[8]/td[2]/select")
	@CacheLookup
	private WebElement modeoflearning;
	
	@FindBy(how=How.ID,using = "enqdetails")
	@CacheLookup
	private WebElement yourenquiry;
	
	@FindBy(how=How.ID,using = "Submit1")
	@CacheLookup
	private WebElement submityourrequest;
	
	@FindBy(how=How.XPATH,using = "/html/body/form/table/tbody/tr[1]/td/h3[2]/i/span/span")
	@CacheLookup
	private WebElement heading;
	
	@FindBy(how=How.ID,using = "Thank you for submitting the online coaching Class Enquiry")
	@CacheLookup
	private WebElement userpromptMsg;
	
	@FindBy(how=How.XPATH,using = "/html/body/h3")
	@CacheLookup
	private WebElement nextpage;
	
	
	public CoachingClassPage() {
		super();
	}

	public CoachingClassPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
 /*
  * to access private variables i have taken getter and setter methods
  */
	public WebElement getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname.sendKeys(firstname);
	}

	public WebElement getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname.sendKeys(lastname);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public WebElement getTypeoftuition() {
		return typeoftuition;
	}

	public void setTypeoftuition(String typeoftuition) {
		this.typeoftuition.sendKeys(typeoftuition);
	}

	public WebElement getCitypreference() {
		return citypreference;
	}

	public void setCitypreference(String citypreference) {
		this.citypreference.sendKeys(citypreference);
	}

	public WebElement getModeoflearning() {
		return modeoflearning;
	}

	public void setModeoflearning(String modeoflearning) {
		this.modeoflearning.sendKeys(modeoflearning);
	}

	public WebElement getYourenquiry() {
		return yourenquiry;
	}

	public void setYourenquiry(String yourenquiry) {
		this.yourenquiry.sendKeys(yourenquiry);
	}
	/*
	 * created a method for a text message
	 */
	public String getHead() {
		return this.heading.getText();
	}
	public String getpromptMsg() {
		return this.userpromptMsg.getText();
	}
  	public String getNextPage() {
  		return this.nextpage.getText();
  	}
  	/*
  	 * created a method for submit button 
  	 */
	public void submitBtnClick() {
		submityourrequest.click();
	}

}
