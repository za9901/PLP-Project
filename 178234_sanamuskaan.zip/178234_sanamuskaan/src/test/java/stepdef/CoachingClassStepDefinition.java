package stepdef;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowserFactory;
import com.cg.page.CoachingClassPage;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CoachingClassStepDefinition {
	static WebDriver driver;
	CoachingClassPage coachPage;

	@Before
	public void setUp() {
		driver = BrowserFactory.startBrowser("chrome",
				"C:\\Users\\sasheik\\Desktop\\module 4 workspace\\178234_sanamuskaan\\src\\test\\java\\html\\Coaching_Class_Enquiry.html");
	}

	@After
	public void tearDown() {
		driver.close();
	}

	/*
	 * below method user will be in coaching class page
	 */
	@Given("^User is in Coaching Class Application Form page$")
	public void user_is_in_Coaching_Class_Application_Form_page() throws Throwable {
		coachPage = PageFactory.initElements(driver, CoachingClassPage.class);
	}

	/*
	 * below method is written to verify the title
	 */
	@Then("^verify the title of the Coaching Class Application Form$")
	public void verify_the_title_of_the_Coaching_Class_Application_Form() throws Throwable {

		try {
			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
			assertEquals("Online Coaching Class Enquiry Form", driver.getTitle());
			if (driver.getTitle().equals("Online Coaching Class Enquiry Form")) {
				System.out.println("Title is matched");
			} else {
				System.out.println("Title not matched");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	/*
	 * below method is written to verify the text of the page
	 */

	@Then("^verify the text on the web page \"([^\"]*)\"$")
	public void verify_the_text_on_the_web_page(String arg1) throws Throwable {

		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		assertEquals("Tuition Enquiry Details Form", coachPage.getHead());
		if (coachPage.getHead().equals("Tuition Enquiry Details Form")) {
			System.out.println("heading matched");
		} else {
			System.out.println("heading not matched");
		}
	}

	/*
	 * below method to give alert message if left without entering firstname
	 */

	@When("^User leaves without entering firstname$")
	public void user_leaves_without_entering_firstname() throws Throwable {

		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		coachPage.setFirstname("");
		coachPage.submitBtnClick();

	}

	@Then("^alert message get displayed fill the firstname$")
	public void alert_message_get_displayed_fill_the_firstname() throws Throwable {

		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("First Name must be filled out", msg);
			if (msg.equals("First Name must be filled out")) {
				System.out.println("The text msg on alert box is:" + msg);
			} else {
				System.out.println("the text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	/*
	 * below method to give alert message if left without entering lastname
	 */

	@When("^User leaves without entering lastname$")
	public void user_leaves_without_entering_lastname() throws Throwable {

		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		coachPage.setLastname("");
		coachPage.submitBtnClick();

	}

	@Then("^alert message get displayed fill the lastname$")
	public void alert_message_get_displayed_fill_the_lastname() throws Throwable {

		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("Last Name must be filled out", msg);
			if (msg.equals("Last Name must be filled out")) {
				System.out.println("The text msg on alert box is:" + msg);
			} else {
				System.out.println("the text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*
	 * below method to give alert message if left without entering email
	 */
	@When("^User leaves without entering email$")
	public void user_leaves_without_entering_email() throws Throwable {

		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		coachPage.setEmail("");
		coachPage.submitBtnClick();

	}

	@Then("^alert message get displayed fill the email$")
	public void alert_message_get_displayed_fill_the_email() throws Throwable {

		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("Email must be filled out", msg);
			if (msg.equals("Email must be filled out")) {
				System.out.println("The text msg on alert box is:" + msg);
			} else {
				System.out.println("the text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*
	 * below method to give alert message if left without entering mobile
	 */
	@When("^User leaves without entering mobile$")
	public void user_leaves_without_entering_mobile() throws Throwable {

		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		coachPage.setMobile("");
		coachPage.submitBtnClick();

	}

	@Then("^alert message get displayed fill the mobile$")
	public void alert_message_get_displayed_fill_the_mobile() throws Throwable {

		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("Mobile must be filled out", msg);
			if (msg.equals("Mobile must be filled out")) {
				System.out.println("The text msg on alert box is:" + msg);
			} else {
				System.out.println("the text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*
	 * below method to give alert message if entered wrong mobile format
	 */
	@When("^User enters incorrect mobileno format and clicks the submit button$")
	public void user_enters_incorrect_mobileno_format_and_clicks_the_submit_button(DataTable arg1) throws Throwable {

		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		coachPage.setMobile("");
		coachPage.submitBtnClick();
		List<String> objlist = arg1.asList(String.class);
		try {
			for (int i = 0; i < objlist.size(); i++) {
				coachPage.setMobile((objlist.get(i)));
				coachPage.submitBtnClick();
				Thread.sleep(1000);
				if (Pattern.matches("^[7-9]{1}[0-9]{9}$", objlist.get(i))) {
					System.out.println("****valid phone no -Matched");
				} else {
					System.out.println("Pattern not matching ,Invalid Mobile");
				}
			}
		} catch (Exception e) {
			System.out.println("invalid");
		}

	}

	@Then("^alert message please fill the correct contact number$")
	public void alert_message_please_fill_the_correct_contact_number() throws Throwable {

		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("Mobile must be filled out", msg);
			if (msg.equals("Mobile must be filled out")) {
				System.out.println("The text msg on alert box is:" + msg);
			} else {
				System.out.println("the text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * below method to verify whether entering type of tuition
	 */
	@When("^User enters type of tuition$")
	public void user_enters_type_of_tuition() throws Throwable {

		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		coachPage.setTypeoftuition("Spoken English");

	}

	@Then("^successfull message get displayed for type of tuition$")
	public void successfull_message_get_displayed_for_type_of_tuition() throws Throwable {
		System.out.println("type of tuition selected");
	}

	/*
	 * below method to verify whether entering city
	 */
	@When("^User enters the city$")
	public void user_enters_the_city() throws Throwable {

		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		coachPage.setCitypreference("Mumbai");

	}

	@Then("^successfull message get displayed for city$")
	public void successfull_message_get_displayed_for_city() throws Throwable {
		System.out.println("city selected");
	}

	/*
	 * below method to verify whether entering mode of training
	 */
	@When("^User enters mode of learning$")
	public void user_enters_mode_of_learning() throws Throwable {

		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		coachPage.setModeoflearning("Virtual Training");

	}

	@Then("^successfull message get displayed for mode of learning$")
	public void successfull_message_get_displayed_for_mode_of_learning() throws Throwable {
		System.out.println("mode of learning selected");
	}

	/*
	 * below method to verify whether entering enquiry details
	 */
	@When("^User leaves without entering enquiry details$")
	public void user_leaves_without_entering_enquiry_details() throws Throwable {

		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		coachPage.setYourenquiry("");
		coachPage.submitBtnClick();

	}

	@Then("^alert message get displayed fill the enquiry details$")
	public void alert_message_get_displayed_fill_the_enquiry_details() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
			String msg = alt.getText();
			assertEquals("Enquiry details must be filled out", msg);
			if (msg.equals("Enquiry details must be filled out")) {
				System.out.println("The text msg on alert box is:" + msg);
			} else {
				System.out.println("the text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*
	 * below method to verify whether on entering all the details,is it redirecting
	 * to the next page
	 */
	@When("^User clicks on sumit button$")
	public void user_clicks_on_sumit_button() throws Throwable {

		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
			coachPage.submitBtnClick();

	}

	@Then("^the message gets displayed \"([^\"]*)\"$")
	public void the_message_gets_displayed(String arg1) throws Throwable {
		coachPage.getpromptMsg();
	}

	@Then("^the text gets displayed \"([^\"]*)\"$")
	public void the_text_gets_displayed(String arg1) throws Throwable {

		Thread.sleep(1000);
		driver.navigate().to(arg1);

	}

}
