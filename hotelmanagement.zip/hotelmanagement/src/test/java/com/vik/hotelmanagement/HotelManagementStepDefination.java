package com.vik.hotelmanagement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import beans.LoginPageFactory;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class HotelManagementStepDefination {

	private WebDriver driver;
	private LoginPageFactory factory;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\vikas\\\\Downloads\\\\CG-module4\\\\m2ang-master\\\\starter\\\\lib\\\\chromedriver.exe");	
		driver = new ChromeDriver();
	}
	
	@After
	public void tearDown() throws InterruptedException {
		Thread.sleep(5000);
		driver.close();
	}
	
	
	@Given("user enters {string} page")
	public void user_enters_page(String string) {
	    driver.get("file:///D:/BDD-Workspace/hotelmanagement/src/main/java/com/vik/hotelmanagement/"+string+".html");
	    factory = new LoginPageFactory(driver);
	}

	@When("user enters wrong user name")
	public void user_enters_wrong_user_name() {
	    factory.setUserName("");
	}

	@When("user clicks on the login button and print {string}")
	public void user_clicks_on_the_login_button_and_print(String string) throws InterruptedException {
	   if(factory.getUserName().equals("")) {
		   factory.setErrMsg(string);
	   }else {
		   Thread.sleep(5000);
		   factory.setBtn();
	   }
	}

	@When("user enters valid {string}")
	public void user_enters_valid(String string) {
	    factory.setUserName(string);
	}

	@When("user click the login button and display {string} page")
	public void user_click_the_login_button_and_display_page(String string) throws InterruptedException {
	   if(factory.getUserName().equals("")) {
		   factory.setErrMsg("Pls enter proper name");
	   }else {
		   Thread.sleep(3000);
		   factory.setBtn();
		   Thread.sleep(3000);
		   driver.get("file:///D:/BDD-Workspace/hotelmanagement/src/main/java/com/vik/hotelmanagement/"+string+".html");
	   }
	}
}
