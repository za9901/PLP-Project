package beans;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPageFactory {

	WebDriver driver;
	
	@FindBy(name="userName")
	@CacheLookup
	WebElement userName;
	
	@FindBy(name="errMsg")
	@CacheLookup
	WebElement errMsg;
	
	@FindBy(name="btn")
	@CacheLookup
	WebElement btn;
	
	
	public LoginPageFactory(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}


	public WebDriver getDriver() {
		return driver;
	}


	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}


	public String getUserName() {
		return this.userName.getAttribute("value");
	}


	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}


	public String getErrMsg() {
		return errMsg.getAttribute("value");
	}


	public void setErrMsg(String errMsg) {
		this.errMsg.sendKeys(errMsg);
	}


	public WebElement getBtn() {
		return btn;
	}


	public void setBtn() {
		this.btn.click();
	}
	
	
}
