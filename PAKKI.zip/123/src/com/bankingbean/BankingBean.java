package com.bankingbean;
//ZABI
public class BankingBean {

	   public int accountNo;
	   public String customerName;
	   public String mobileNo;
	   public String emailAdd;
	   public String dateOfBirth;
	   public String panNo;
	   public String aadharNo;
	   public int openingBalance;
	   public String branch;
	   public String accountType;
	   public String typeOfBank;
	   public int Pin;
	   public 	String username;
	   public String password;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getPin() {
		return Pin;
	}
	public void setPin(int pin) {
		Pin = pin;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailAdd() {
		return emailAdd;
	}
	public void setEmailAdd(String emailAdd) {
		this.emailAdd = emailAdd;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public int getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(int openingBalance) {
		this.openingBalance = openingBalance;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getTypeOfBank() {
		return typeOfBank;
	}
	public void setTypeOfBank(String typeOfBank) {
		this.typeOfBank = typeOfBank;
	}
	
	public BankingBean(){
		
	}
	public BankingBean(String customerName, String mobileNo, String emailAdd,
			String dateOfBirth, String panNo, String aadharNo, int openingBalance,
			String branch, String accountType, String typeOfBank,String username,String password) {
		super();
		this.customerName = customerName;
		this.mobileNo = mobileNo;
		this.emailAdd = emailAdd;
		this.dateOfBirth = dateOfBirth;
		this.panNo = panNo;
		this.aadharNo = aadharNo;
		this.openingBalance = openingBalance;
		this.branch = branch;
		this.accountType = accountType;
		this.typeOfBank = typeOfBank;
		this.username=username;
		this.password=password;
	}
	public int getOpeningBalance(int amt1) {
		
		return 0;
	}
	   
	   
}
