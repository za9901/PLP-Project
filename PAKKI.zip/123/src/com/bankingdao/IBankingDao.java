package com.bankingdao;

import java.util.HashMap;

import com.bankingbean.BankingBean;
import com.bankingbean.TransactionsBean;


public interface IBankingDao {

	int CreateAccount(BankingBean ad,TransactionsBean transaction);
	int CreateAccount1(BankingBean ad,TransactionsBean transaction);
	public void ShowBalance(int AccountNo1);
	void Deposit(int amt, int d,TransactionsBean transaction);
	void Withdraw(int amt1, int d11,TransactionsBean transaction);
	int FundTransfer(int a1, int a2, int a11,TransactionsBean transaction);
	public HashMap<Integer, TransactionsBean> printTransactions();

}
