package com.capstorereturngoods.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capstorereturngoods.dao.MerchantgoodsDao;
import com.capstorereturngoods.dao.ReturngoodsDao;
import com.capstorereturngoods.entity.MerchantReturnGoods;
import com.capstorereturngoods.entity.Returngoods;

@Service
public class MercantgoodsService {
	@Autowired
	MerchantgoodsDao merchantreturngoodsdao;
	ReturngoodsDao returngoodsdao;
	
	
public List<MerchantReturnGoods> getAllProducts() {
		
		return this.merchantreturngoodsdao.findAll();
		
	}

public MerchantReturnGoods createProduct(MerchantReturnGoods goods) {
	
	return this.merchantreturngoodsdao.save(goods);
	
	}

public Optional<MerchantReturnGoods> viewproductById(int productid) {
	
	return this.merchantreturngoodsdao.findById(productid);
}


public Object newProduct(Returngoods goods) {
	// TODO Auto-generated method stub
	return this.merchantreturngoodsdao.save(goods);
	
}



}
