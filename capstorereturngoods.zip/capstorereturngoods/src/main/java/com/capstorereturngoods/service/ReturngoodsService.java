package com.capstorereturngoods.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstorereturngoods.dao.ReturngoodsDao;
import com.capstorereturngoods.entity.Returngoods;

// Customer Products

@Service
public class ReturngoodsService {
	@Autowired
	ReturngoodsDao returngoodsdao;
	
public List<Returngoods>  getProducts() {
		
		return this.returngoodsdao.findAll();
		
	}
public Returngoods createProduct(Returngoods goods) {
	
	return this.returngoodsdao.save(goods);
	
	}

public void deleteById(int productid) {
	
	 this.returngoodsdao.deleteById(productid);
}
public Optional<Returngoods> viewproductById(int productid) {
	
	return this.returngoodsdao.findById(productid);
}

}
