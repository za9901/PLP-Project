package com.capstorereturngoods.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
@Primary
@Entity
@Table(name="MerchantProducts")
//@SequenceGenerator(name="merchantid", initialValue=1000, allocationSize=1000)
public class MerchantReturnGoods {
	@Column(name="productid")
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO )
	private int productid;
	
//	@Column(name="customerid",nullable=true,length=255)
//	private int customerid;
	
	@Column(name="productname",nullable=true,length=255)
	private String productname;
	
	@Column(name="producttype",nullable=true,length=255)
	private String producttype;
	
	@Column(name="productcategory",nullable=true,length=255)
	private String productcategory;
	
	@Column(name="productrating",nullable=true,length=255)
	private int productrating;

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

//	public int getCustomerid() {
//		return customerid;
//	}
//
//	public void setCustomerid(int customerid) {
//		this.customerid = customerid;
//	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public String getProducttype() {
		return producttype;
	}

	public void setProducttype(String producttype) {
		this.producttype = producttype;
	}

	public String getProductcategory() {
		return productcategory;
	}

	public void setProductcategory(String productcategory) {
		this.productcategory = productcategory;
	}

	public int getProductrating() {
		return productrating;
	}

	public void setProductrating(int productrating) {
		this.productrating = productrating;
	}

	public MerchantReturnGoods(int productid, int customerid, String productname, String producttype,
			String productcategory, int productrating) {
		super();
		this.productid = productid;
		//this.customerid = customerid;
		this.productname = productname;
		this.producttype = producttype;
		this.productcategory = productcategory;
		this.productrating = productrating;
	}

	public MerchantReturnGoods() {
		super();
	}

	@Override
	public String toString() {
		return "MerchantReturnGoods [productid=" + productid + ", + productname="
				+ productname + ", producttype=" + producttype + ", productcategory=" + productcategory
				+ ", productrating=" + productrating + "]";
	}
	
	

}
