package com.employeemanagement.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.employeemanagement.entity.EmployeeManagementEntity;
import com.employeemanagement.service.EmployeeManagementService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/employee")
public class EmployeeManagementController {

	@Autowired
	EmployeeManagementService empservice;
	
	@RequestMapping(value="/all", method=RequestMethod.GET)
	public List<EmployeeManagementEntity> getAllEmployees(){
		return empservice.getAllEmployees();
		
		
	}
	
	@RequestMapping(value="/{id}", method=RequestMethod.GET)
	public Optional<EmployeeManagementEntity> getEmployeeById(@PathVariable int id){
		return empservice.getEmployeeById(id);
	}
	
	@RequestMapping(value="/add", method=RequestMethod.POST, consumes=org.springframework.http.MediaType.APPLICATION_JSON_VALUE, produces=org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public EmployeeManagementEntity addEmployee(@RequestBody EmployeeManagementEntity emp){
		return empservice.addEmployee(emp);
	}
	
	@RequestMapping(value="/update", method=RequestMethod.PUT)
	public EmployeeManagementEntity updateEmployee(@RequestBody EmployeeManagementEntity emp){
		return empservice.updateEmployee(emp);
	}
	
	@RequestMapping(value="/delete", method=RequestMethod.DELETE)
	public void deleteEmployee(@RequestBody EmployeeManagementEntity emp){
		empservice.deleteEmployee(emp);
	}
	
	@RequestMapping(value="/all", method=RequestMethod.DELETE)
	public void deleteAllEmployee(){
		empservice.deleteAllEmployee();
	}
}
