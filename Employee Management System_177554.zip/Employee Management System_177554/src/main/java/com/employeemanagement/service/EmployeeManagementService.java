package com.employeemanagement.service;


import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.employeemanagement.dao.EmployeeManagementDao;
import com.employeemanagement.entity.EmployeeManagementEntity;

@Service
public class EmployeeManagementService {
	@Autowired
	EmployeeManagementDao empdao;
	
	public List <EmployeeManagementEntity> getAllEmployees(){
		return empdao.findAll();
	}
	
	public EmployeeManagementEntity addEmployee(EmployeeManagementEntity emp) {
		return empdao.save(emp);
	}
	
	public EmployeeManagementEntity updateEmployee(EmployeeManagementEntity emp) {
		return empdao.save(emp);
	}
	
	public Optional<EmployeeManagementEntity> getEmployeeById(int id) {
		return empdao.findById(id);
	}
	
	public void deleteEmployee(EmployeeManagementEntity emp) {
		empdao.delete(emp);
	}
	
	public void deleteAllEmployee() {
		empdao.deleteAll();
	}
}
