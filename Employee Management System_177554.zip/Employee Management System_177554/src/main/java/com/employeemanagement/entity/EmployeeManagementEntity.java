package com.employeemanagement.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="employee")
public class EmployeeManagementEntity {
	
	@Id
	@Column(name="EMP_ID")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int empid;
	
	@Column(name="NAME")
	private String name;
	
	@Column(name="DESIGNATION")
	private String designation;

	
	@Column(name="DEPT_NAME")
	private String deptname ;

	@Column(name="SALARY-($)")
	private Integer salary;
	
	public EmployeeManagementEntity() {
		
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}

	public EmployeeManagementEntity(String name, String designation, String deptname, Integer salary) {
		super();
		this.name = name;
		this.designation = designation;
		this.deptname = deptname;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "EmployeeManagementEntity [empid=" + empid + ", name=" + name + ", designation=" + designation
				+ ", deptname=" + deptname + ", salary=" + salary + "]";
	}


}
