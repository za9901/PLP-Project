package com.cg.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class UserException {
	@ResponseBody
	@ResponseStatus(value=HttpStatus.METHOD_NOT_ALLOWED)
	@ExceptionHandler(value= {Exception.class})
	
	public ErrorInformation handlerException(Exception exception, HttpServletRequest httpservlet){
	String message=exception.getMessage();
	String url=httpservlet.getRequestURL().toString();
	return new ErrorInformation(url,message);
}
}
