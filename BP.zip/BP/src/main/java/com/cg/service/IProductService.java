package com.cg.service;



import java.util.List;

import com.cg.beans.Product;

public interface IProductService {
	public Product createProduct(Product p);
	public Product UpdateProduct(Product p);
	public void deleteById(String id);
	public List<Product> getProducts();
	public Product findById(String id);
	

}
