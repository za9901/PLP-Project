package com.demo;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.demo.pages.LoginPage;

public class MyLoginTest {

	@Test
	public void verifyValidLogin()
			throws InterruptedException {

		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\zshariff\\Desktop\\SeleniumWebDriver\\libs\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.get(
				"file:///C:/Users/zshariff/Desktop/Lesson%205-HTML%20Pages/login.html");

		LoginPage login = new LoginPage(driver);

		login.enterCredentials("blue", "berry");
		login.clickOnLoginButton();
		driver.quit();

	}
 
}
