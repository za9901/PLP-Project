package com.demo.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

	WebDriver driver;

	By username = By.id("user_login");
	By password = By
			.xpath(".//*[@id='user_pass']");
	By loginButton = By.name("login-submit");

	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	public void enterCredentials(String userid,
			String pass) throws InterruptedException {

		driver.findElement(username)
				.sendKeys(userid);
		Thread.sleep(3000);
		driver.findElement(password)
				.sendKeys(pass);
		//driver.findElement(loginButton).click();
		Thread.sleep(3000);
	}

	/*
	 * public void typeUserName(String uname) throws InterruptedException {
	 * 
	 * driver.findElement(username) .sendKeys(uname); Thread.sleep(2000); }
	 * 
	 * public void typePassword(String pass) throws InterruptedException {
	 * 
	 * driver.findElement(password) .sendKeys(pass); Thread.sleep(2000); }
	 */

	public void clickOnLoginButton() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(loginButton).click();
	}
}