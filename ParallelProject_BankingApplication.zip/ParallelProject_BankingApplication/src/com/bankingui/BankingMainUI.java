package com.bankingui;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Scanner;
import com.bankingbean.BankingBean;
import com.bankingexception.BankingException;
import com.bankingservice.BankingServiceImpl;
import com.bankingservice.IBankingService;


public class BankingMainUI {
	static Scanner scan = new Scanner(System.in);
	static IBankingService ibs=null;
	 static String customerName=null;
	   static String mobileNo=null;
	   static String emailAdd=null;
	   static String dateOfBirth=null;
	   static String panNo=null;
	   static String aadharNo=null;
	   static int openingBalance=0;
	   static String branch=null;
	   static String accountType=null;
	   static String typeOfBank=null;
	   static String username=null;
	   static String password=null;
	   static int i;
	   static BankingBean ad=new BankingBean();
	public static void main(String[] args) throws BankingException {
		
		
		String h=null;
do{
	System.out.println("enter any option between   1 to 5");
	System.out.println(" 1.  CreateAccount......\n 2. ShowBalance.......\n 3.  Deposit......\n 4.Withdraw.....\n 5.FundTransfer......\n  6.PrintTransactions......\n");
	int a=scan.nextInt();
	    switch(a){
	    case 1:int AccountNo= CreateAccount();
	           System.out.println("Account Is Created........");
	           System.out.println(" The Respective AccountNo is "+AccountNo);
	           System.out.println("The Account Is Created  On :"   +LocalDateTime.now()); 
	           int PinNo=CreateAccount1(ad);
	           System.out.println(" AccountNo is Created");
		       System.out.println(" The Respective PinNo for The Given AccountNo is "+PinNo);
		       System.out.println("Thank You..........\n");
	    	   break;
	    	
	    case 2: System.out.println("Enter The Respective  Account Number  to Retrive The Balance..........");
	            int AccountNo1=scan.nextInt();
	    	    ShowBalance(AccountNo1);
	    	
	    	
	    	break; 
	    	
	    case 3: System.out.println("Enter The Respective Account Number To Deposit The Money......");
	            int amt=scan.nextInt();
	            System.out.println("Enter the Amount u need to Deposit....");
	            int d=scan.nextInt();
	            Deposit(amt,d);
	    	
	    	
	    	break;
	    	
	    	
	    case 4:System.out.println("Enter The Respective Account Number To Withdraw The Money......");
               int amt1=scan.nextInt();
               	Withdraw(amt1);
	    	
	    	
	    	break;
	    	
	    	
	    case 5:System.out.println("Enter FROM Account Number");
		int a1=scan.nextInt();
		System.out.println("Enter TO Account Number");
		int a2=scan.nextInt();
		System.out.println("Enter The Amount To Bee Transfered");
		int a11=scan.nextInt();
		FundTransfer(a1,a2,a11);
	    	
	    	
	    	break;
	    	
	    	
	    case 6:PrintTransactions();
	    	
	    	
	    	break;
	    	
	    default:
	    	break;
	    }
	    
	    System.out.println("enter y/n to continue");
	       h=scan.next();
	       if(h.equalsIgnoreCase("n")){
	    	  System.out.println("Program Terminated");}
}while(h.equalsIgnoreCase("y"));}
	
	
	private static void PrintTransactions() {
	      ibs=new BankingServiceImpl();
	      ibs.PrintTransactions();
		
	}


	private static void FundTransfer(int a1,int a2,int a11) {
		ibs=new BankingServiceImpl();
		ibs.FundTransfer(a1,a2,a11);
		
	}


	private static void Withdraw(int amt1) {
		ibs=new BankingServiceImpl();
		
		System.out.println("Enter From Where u want To withdraw the money:   1.Savings\n   2.Current\n");
		int dd=scan.nextInt();
		do{
		switch(dd){
		
		case 1:System.out.println("U Have Choosen Savings");
		break;
		
		
	    case 2:System.out.println("U Have Choosen Current");
		break;
	}}while(dd>2);
		System.out.println("Enter amount How much You Want");
		int d1=scan.nextInt();
		ibs.Withdraw(amt1, d1);}
		

	private static void Deposit(int amt,int d) {
		ibs=new BankingServiceImpl();
		ibs.Deposit(amt, d);
		
		
		
	}


	private static void ShowBalance(int AccountNo1) throws BankingException {
		ibs=new BankingServiceImpl();
		
//		do{
//			try{
//				System.out.println("Enter the Username");
//				username=scan.next();
//				boolean validate=ibs.validateusername(username);}
//			catch(Exception e){
//				System.out.println(" UserName Exception");
//			}
//		}while(ibs.validateusername(username)==false);
//		
//		do{
//			try{
//				System.out.println("Enter the Password");
//				password=scan.next();
//				boolean validate=ibs.validatepassword(password);}
//			catch(Exception e){
//				System.out.println(" PassWord Exception");
//			}
//		}while(ibs.validatepassword(password)==false);
		System.out.println("The Available Balance In Your Account is:");
		ibs.ShowBalance(AccountNo1);
	}

	private static int CreateAccount1(BankingBean ad) {
		ibs=new BankingServiceImpl();
		return ibs.CreateAccount1(ad);
	}
	private static int CreateAccount() throws BankingException {
		 ibs=new BankingServiceImpl();
		 int up=scan.nextInt();
		 do{
			
		 System.out.println("ENTER THE LOGIN DETAILS FIRST TO CREATE YOUR ACCOUNT   1.USERNAME\n   2.PASSWORD\n");
	     switch(up){
	     
	     case 1:
	    	 try{
	    		 System.out.println("Enter the Username");
	            username=scan.next();
	            boolean validate=ibs.validateusername(username);}
	    	 catch(Exception e){
	    		 System.out.println("Name Exception");
	    	 }
//	     }while(ibs.validateusername(username)==false);
	     
		 case 2:
		    	 try{
		    		 System.out.println("Enter the Password");
		            password=scan.next();
		            boolean validate=ibs.validatepassword(password);}
		    	 catch(Exception e){
		    		 System.out.println("Password Exception");
		    	 }
		     }while(ibs.validatepassword(password)==false && ibs.validateusername(username)==false);
	
	 
	}while(up>2);
	
	
		do{
			try{
				System.out.println("Enter the Customer Name");
				customerName=scan.next();
				boolean validate=ibs.validatecustomerName(customerName);}
			catch(Exception e){
				System.out.println(" Name Exception");
			}
		}while(ibs.validatecustomerName(customerName)==false);
		
		do{
			try{
				System.out.println("Enter the Customer Mobile Number");
				mobileNo=scan.next();
				boolean validate=ibs.validatemobileNo(mobileNo);}
			catch(Exception e){
				System.out.println(" Number Exception");
			}
		}while(ibs.validatemobileNo(mobileNo)==false);
		
		do{
			try{
				System.out.println("Enter the Customer Email Address");
				emailAdd=scan.next();
				boolean validate=ibs.validateemailAdd(emailAdd);}
			catch(Exception e){
				System.out.println(" String Exception");
			}
		}while(ibs.validateemailAdd(emailAdd)==false);
		
		do{
			try{
				System.out.println("Enter the Customer Date Of Birth");
				dateOfBirth=scan.next();
				boolean validate=ibs.validatedateOfBirth(dateOfBirth);}
			catch(Exception e){
				System.out.println(" Date Exception");
			}
		}while(ibs.validatedateOfBirth(dateOfBirth)==false);
		
		do{
			try{
				System.out.println("Enter the Customer Permanent Account Number");
				panNo=scan.next();
				boolean validate=ibs.validatepanNo(panNo);}
			catch(Exception e){
				System.out.println(" String/Date Exception");
			}
		}while(ibs.validatepanNo(panNo)==false);
		
		do{
			try{
				System.out.println("Enter the Customer Aadhar Number");
				aadharNo=scan.next();
				boolean validate=ibs.validateaadharNo(aadharNo);}
			catch(Exception e){
				System.out.println(" Number Exception");
			}
		}while(ibs.validateaadharNo(aadharNo)==false);
		
		do{
		   System.out.println("Enter In Which Bank U Want To Open The Account: ");
			System.out.println("1. AXIS Bank\n   2.HDFC Bank\n   3.SBI Bank\n   4.CITY Bank\n   5.ICICI Bank ");
			 i=scan.nextInt();
			switch(i){
			case 1:
			typeOfBank="AXIS Bank";
			System.out.println("THE TYPE Of BANK CHOOSEN IS AXIS:");
			break;
			case 2:
			typeOfBank="HDFC Bank";
			System.out.println("THE TYPE Of BANK CHOOSEN IS HDFC:");
			break;
			
			case 3:
				typeOfBank="SBI Bank";
				System.out.println("THE TYPE Of BANK CHOOSEN IS SBI:");
				break;
				
			case 4:
				typeOfBank="CITY Bank";
				System.out.println("THE TYPE Of BANK CHOOSEN IS CITY:");
				break;
			case 5:
				typeOfBank="ICICI Bank";
				System.out.println("THE TYPE Of BANK CHOOSEN IS ICICI:");
				break;
				
				default:System.out.println(" You Have Entered The Invalid Option");
				break;}
			}while(i>5);
	do{
			System.out.println("Enter In Which Branch U Want Create UR Account:       1.CHENNAI Branch\n  2.BANGALORE Branch\n  3.PUNE Branch\n");
	i=scan.nextInt();
	switch(i){ 
			case 1: 
			System.out.println("U Have Selected Chennai Branch ");	
			break;
			
			case 2: 
				System.out.println("U Have Selected Bangalore Branch");	
				break;
				
			case 3: 
				System.out.println("U Have Selected Pune Branch");	
				break;
				
			default: System.out.println(" Invalid Option");
			break;
		
			}
	}while(i>3);
	do{
			System.out.println("Enter Which Type Of Account U Want To Create:\n  1.SAVINGS ACCOUNT\n   2.CURRENT ACCOUNT\n");
			i=scan.nextInt();
			switch(i){ 
			case 1:
			System.out.println(" U Have Selected Savings Account");
			System.out.println("THANK YOU FOR USING OUR SERVICE");
			break; 
					
		    case 2:
			System.out.println("U Have Selected Current Account");
			System.out.println("THANK YOU FOR USING OUR SERVICE");
			break; 
			
			default:System.out.println("Invalid Option");
			break;
				
			
          }
	}while(i>2);
	
		
		
		do{
			try{
				System.out.println("Enter the Minimum Opening Balance");
				openingBalance=scan.nextInt();
				boolean validate=ibs.validateopeningBalance(openingBalance);}
			catch(Exception e){
				System.out.println(" Number Exception");
			}
		}while(ibs.validateopeningBalance(openingBalance)==false);

		BankingBean bb=new BankingBean(customerName,mobileNo, emailAdd,dateOfBirth,panNo,aadharNo,openingBalance,branch,accountType,typeOfBank,username,password);
		ibs=new BankingServiceImpl();
		int aid=ibs.CreateAccount(bb);
		return aid;
		
	

		}}
