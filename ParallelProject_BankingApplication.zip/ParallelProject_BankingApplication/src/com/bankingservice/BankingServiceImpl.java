package com.bankingservice;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.bankingbean.BankingBean;
import com.bankingdao.BankingDaoImpl;
import com.bankingdao.IBankingDao;
import com.bankingexception.BankingException;


public class BankingServiceImpl implements IBankingService{
	
	IBankingDao ibd=null;
	private int generateAccountNo(){
		int id=0;
		id=(int) (Math.random()*1000000000);
		return id;
	}
	
	private int generatePin(){
		int ip=0;
		ip=(int) (Math.random()*100000);
		return ip;
	}
	
	public void ShowBalance(int AccountNo1){
		ibd=new BankingDaoImpl ();
		ibd.ShowBalance(AccountNo1);
	}
	
	public void Deposit(int amt,int d){
		ibd=new BankingDaoImpl();
		ibd.Deposit(amt,d);
	}
	@Override
	public int CreateAccount(BankingBean ad) {
		ad.setAccountNo(generateAccountNo());
		ibd=new BankingDaoImpl ();
		return ibd.CreateAccount(ad);
	}
	
	@Override
	public int CreateAccount1(BankingBean ad) {
		ad.setPin(generatePin());
		ibd=new BankingDaoImpl ();
		return ibd.CreateAccount1(ad);
	}

	@Override
	public boolean validatecustomerName(String customerName)throws BankingException {
		Pattern p=Pattern.compile("^[A-Z][a-z]{3,}");
		Matcher m=p.matcher(customerName);
		if(m.find()){
		return true;
		}
	    else {
		throw new BankingException(" name error");}}
		
	

	@Override
	public boolean validatemobileNo(String mobileNo) throws BankingException {
		Pattern p=Pattern.compile("^[7-9][0-9]{9,}");
		Matcher m=p.matcher(mobileNo);
		if(m.find()){
		return true;
		}
	    else {
		throw new BankingException(" number error");}
		
	}

	@Override
	public boolean validateemailAdd(String emailAdd) throws BankingException{
		Pattern p=Pattern.compile("^(.+)@(.+)$");
		Matcher m=p.matcher(emailAdd);
		if(m.find()){
		return true;
		}
	    else {
		throw new BankingException(" email error");}
	
	}

	@Override
	public boolean validatedateOfBirth(String dateOfBirth) throws BankingException {
		Pattern p=Pattern.compile("^\\d{2}-\\d{2}-\\d{4}$");
		Matcher m=p.matcher(dateOfBirth);
		if(m.find()){
		return true;
		}
	    else {
		throw new BankingException(" date error");}
		
	}

	@Override
	public boolean validatepanNo(String panNo) throws BankingException {
		Pattern p=Pattern.compile("\\w{5}\\d{4}\\w{1}");
		Matcher m=p.matcher(panNo);
		if(m.find()){
		return true;
		}
	    else {
		throw new BankingException(" number error");}
		
	}

	@Override
	public boolean validateaadharNo(String aadharNo) throws BankingException{
		Pattern p=Pattern.compile("^[7-9][0-9]{7,}");
		Matcher m=p.matcher(aadharNo);
		if(m.find()){
		return true;
		}
	    else {
		throw new BankingException(" aadhar error");}
		
	}

	@Override
	public boolean validateopeningBalance(int openingBalance) throws BankingException{
		if(openingBalance>1000){
		return true;
		}
	    else {
		throw new BankingException(" number error");}
		
	}

	@Override
	public boolean validatepassword(String password) throws BankingException {
		Pattern p=Pattern.compile("\\w{4}(.+)@(.+)\\d{2}");
		Matcher m=p.matcher(password);
		if(m.find()){
		return true;
		}
	    else {
		throw new BankingException(" password error");}
	}

	@Override
	public boolean validateusername(String username) throws BankingException {
		Pattern p=Pattern.compile("\\w{4}\\d{3}");
		Matcher m=p.matcher(username);
		if(m.find()){
		return true;
		}
	    else {
		throw new BankingException(" username error");
	}

	

	
	}

	@Override
	public void Withdraw(int amt1, int d1) {
		ibd=new BankingDaoImpl();
		ibd.Withdraw(amt1,d1);
		
	}

	@Override
	public void FundTransfer(int a1, int a2, int a11) {
		ibd=new BankingDaoImpl();
		ibd.FundTransfer(a1,a2,a11);
		
	}

	@Override
	public void PrintTransactions() {
		
		
	}}
