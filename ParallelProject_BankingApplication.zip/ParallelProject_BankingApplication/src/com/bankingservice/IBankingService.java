package com.bankingservice;

import com.bankingbean.BankingBean;
import com.bankingexception.BankingException;

public interface IBankingService {

	boolean validatecustomerName(String customerName) throws BankingException;
	boolean validatemobileNo(String mobileNo) throws BankingException;
	boolean validateemailAdd(String emailAdd) throws BankingException;
	boolean validatedateOfBirth(String dateOfBirth) throws BankingException;
	boolean validatepanNo(String panNo) throws BankingException;
	boolean validateopeningBalance(int openingBalance) throws BankingException;
	int CreateAccount(BankingBean ad);
	int CreateAccount1(BankingBean ad);
	boolean validateaadharNo(String aadharNo) throws BankingException;
	public void ShowBalance(int AccountNo1);
	public void Deposit(int amt,int d);
	boolean validatepassword(String password)throws BankingException;
	boolean validateusername(String username)throws BankingException;
	void Withdraw(int amt1, int d1);
	void FundTransfer(int a1, int a2, int a11);
	void PrintTransactions();
	


}
