package com.jdbc.ui;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.util.Scanner;
import com.jdbc.bean.BankingBean;
import com.jdbc.exception.BankingException;
import com.jdbc.service.IBankingService;
import com.jdbc.service.BankingServiceImpl;
import com.jdbc.bean.TransactionsBean;

public class BankingMainUi {
	static Scanner scan = new Scanner(System.in);
	static boolean b=true;
	static IBankingService ibs=null;
	 static String customerName=null;
	   static String mobileNo=null;
	   static String emailAdd=null;
	   static String dateOfBirth=null;
	   static String panNo=null;
	   static String aadharNo=null;
	   static int openingBalance=0;
	   static String branch=null;
	   static String accountType=null;
	   static String typeOfBank=null;
	   static String username=null;
	   static String password=null;
	   static int i;
	   static BankingBean ad=new BankingBean();
	public static void main(String[] args) throws BankingException {
		
		
		String h=null;
do{
	System.out.println("-----------------WELCOME TO BANKING APPLICATION---------------");
	System.out.println("enter any option between   1 to 5");
	System.out.println(" 1.  CreateAccount......\n 2. ShowBalance.......\n 3.  Deposit......\n 4.Withdraw.....\n 5.FundTransfer......\n  6.PrintTransactions......\n");
	int a=scan.nextInt();
	    switch(a){
	    case 1:int AccountNo= CreateAccount();
	           System.out.println("Account Is Created........");
	           System.out.println(" The Respective AccountNo is "+AccountNo);
	           System.out.println("The Account Is Created  On :"   +LocalDateTime.now()); 
	           System.out.println(" AccountNo is Created");
		       System.out.println("Thank You..........\n");
	    	   break;
	    	
	    case 2: System.out.println("Enter The Respective  Account Number  to Retrive The Balance..........");
	            int AccountNo1=scan.nextInt();
	    	    ShowBalance(AccountNo1);
	    	
	    	
	    	break; 
	    	
	    case 3: System.out.println("Enter The Respective Account Number To Deposit The Money......");
	            int amt=scan.nextInt();
	            System.out.println("Enter the Amount u need to Deposit....");
	            int d=scan.nextInt();
	            Deposit(amt,d);
	    	
	    	
	    	break;
	    	
	    	
	    case 4:System.out.println("Enter The Respective Account Number To Withdraw The Money......");
               int amt1=scan.nextInt();
               System.out.println("Enter the amount u want to withdraw");
               int d11=scan.nextInt();
               	Withdraw(amt1,d11);
	    	
	    	
	    	break;
	    	
	    	
	    case 5:System.out.println("Enter FROM Account Number");
		int a1=scan.nextInt();
		System.out.println("Enter TO Account Number");
		int a2=scan.nextInt();
		System.out.println("Enter The Amount To Bee Transfered");
		int a11=scan.nextInt();
		FundTransfer(a1,a2,a11);
	    	
	    	
	    	break;
	    	
	    	
	    case 6:PrintTransactions();
	    	
	    	
	    	break;
	    	
	    default:
	    	break;
	    }
	    
	    System.out.println("enter y/n to continue");
	       h=scan.next();
	       if(h.equalsIgnoreCase("n")){
	    	  System.out.println("Program Terminated");}
}while(h.equalsIgnoreCase("y"));}
	
	
	
	
	private static void PrintTransactions() throws BankingException {
		ibs=new BankingServiceImpl();
		int accountNumber;
		System.out.println("----------------enter account number to view transaction details-------------");
		accountNumber=scan.nextInt();
		ibs.PrintTransactions(accountNumber);	
	}
	
	private static int FundTransfer(int a1, int a2, int a11) throws BankingException {
		ibs=new BankingServiceImpl();
		TransactionsBean transaction=new TransactionsBean();
		transaction.setTransactionAmount(a11);
		transaction.setTypeOfTransaction("Fund Transefered");
		int aid=ibs.FundTransfer(a1,a2,a11,transaction);
		return aid;

		
	}
	private static int Withdraw(int amt1, int d11) throws BankingException {
		ibs=new BankingServiceImpl();
		TransactionsBean transaction=new TransactionsBean();
		transaction.setTypeOfTransaction("Withdraw");
		transaction.setTransactionAmount(d11);
		System.out.println("Enter From Where u want To withdraw the money:   1.Savings\n   2.Current\n");
		int dd=scan.nextInt();
		do{
		switch(dd){
		
		case 1:System.out.println("U Have Choosen Savings");
		break;
		
		
	    case 2:System.out.println("U Have Choosen Current");
		break;
	}}while(dd>2);
	  int aid=ibs.Withdraw(amt1, d11,transaction);
	  System.out.println("Your account is credited with:"+aid);
		return aid;
	}
	
	private static int Deposit(int amt, int d) throws BankingException {
		ibs=new BankingServiceImpl();
		TransactionsBean transaction=new TransactionsBean();
		transaction.setTransactionAmount(d);
		transaction.setTypeOfTransaction("Deposit");
		int aid=ibs.Deposit(amt, d,transaction);
		System.out.println("Your account is debited with:"+aid);
		return aid;
	}
	private static int ShowBalance(int accountNo1) throws BankingException {
		ibs=new BankingServiceImpl();
		int aid=ibs.ShowBalance(accountNo1);
		System.out.println("The Available Balance In Your Account is:"+aid);
		return aid;
	}

	private static int CreateAccount() throws BankingException {
		 ibs=new BankingServiceImpl();
		 
		 do{
				try{
					System.out.println("--------------CREATE USERNAME & PASSWORD---------");
					System.out.println("Enter the Username");
					username=scan.next();
					boolean validate=ibs.validateusername(username);}
				catch(Exception e){
					System.out.println(" UserName Exception");
				}
			}while(ibs.validateusername(username)==false);
		 
			
			do{
				try{
					System.out.println("Create the Password");
				String	password1=scan.next();
		 System.out.println("-----Enter Password Again For Confirmation---");
		 do
		  {
		  String password2=scan.next();
		  if(password1.equals(password2))
		  {
		   System.out.println("Password is matched");
		   password=password1;
		   break;
		  }
		  else
		  {
		   System.out.println("------Password  is not matching------- ");
		   System.out.println("----Enter again-----");
		    b=false;
		  }
		  }while(b==false);
					boolean validate=ibs.validatepassword(password);}
				catch(Exception e){
					System.out.println(" PassWord Exception");
				}
			}while(ibs.validatepassword(password)==false);
			
		do{
			try{
				System.out.println("Enter the Customer Name");
				customerName=scan.next();
				boolean validate=ibs.validatecustomerName(customerName);}
			catch(Exception e){
				System.out.println(" Name Exception");
			}
		}while(ibs.validatecustomerName(customerName)==false);
		
		do{
			try{
				System.out.println("Enter the Customer Mobile Number");
				mobileNo=scan.next();
				boolean validate=ibs.validatemobileNo(mobileNo);}
			catch(Exception e){
				System.out.println(" Number Exception");
			}
		}while(ibs.validatemobileNo(mobileNo)==false);
		
		do{
			try{
				System.out.println("Enter the Customer Email Address");
				emailAdd=scan.next();
				boolean validate=ibs.validateemailAdd(emailAdd);}
			catch(Exception e){
				System.out.println(" String Exception");
			}
		}while(ibs.validateemailAdd(emailAdd)==false);
		
		do{
			try{
				System.out.println("Enter the Customer Date Of Birth");
				dateOfBirth=scan.next();
				boolean validate=ibs.validatedateOfBirth(dateOfBirth);}
			catch(Exception e){
				System.out.println(" Date Exception");
			}
		}while(ibs.validatedateOfBirth(dateOfBirth)==false);
		
		do{
			try{
				System.out.println("Enter the Customer Permanent Account Number");
				panNo=scan.next();
				boolean validate=ibs.validatepanNo(panNo);}
			catch(Exception e){
				System.out.println(" String/Date Exception");
			}
		}while(ibs.validatepanNo(panNo)==false);
		
		do{
			try{
				System.out.println("Enter the Customer Aadhar Number");
				aadharNo=scan.next();
				boolean validate=ibs.validateaadharNo(aadharNo);}
			catch(Exception e){
				System.out.println(" Number Exception");
			}
		}while(ibs.validateaadharNo(aadharNo)==false);
		
		do{
		   System.out.println("Enter In Which Bank U Want To Open The Account: ");
			System.out.println("1. AXIS Bank\n   2.HDFC Bank\n   3.SBI Bank\n   4.CITY Bank\n   5.ICICI Bank ");
			 i=scan.nextInt();
			switch(i){
			case 1:
			typeOfBank="AXIS Bank";
			System.out.println("THE TYPE Of BANK CHOOSEN IS AXIS:");
			break;
			case 2:
			typeOfBank="HDFC Bank";
			System.out.println("THE TYPE Of BANK CHOOSEN IS HDFC:");
			break;
			
			case 3:
				typeOfBank="SBI Bank";
				System.out.println("THE TYPE Of BANK CHOOSEN IS SBI:");
				break;
				
			case 4:
				typeOfBank="CITY Bank";
				System.out.println("THE TYPE Of BANK CHOOSEN IS CITY:");
				break;
			case 5:
				typeOfBank="ICICI Bank";
				System.out.println("THE TYPE Of BANK CHOOSEN IS ICICI:");
				break;
				
				default:System.out.println(" You Have Entered The Invalid Option");
				break;}
			}while(i>5);
	do{
			System.out.println("Enter In Which Branch U Want Create UR Account:       1.CHENNAI Branch\n  2.BANGALORE Branch\n  3.PUNE Branch\n");
	i=scan.nextInt();
	switch(i){ 
			case 1: 
				branch="chennai";
			System.out.println("U Have Selected Chennai Branch ");	
			break;
			
			case 2: branch="bangalore";
				System.out.println("U Have Selected Bangalore Branch");	
				break;
				
			case 3: branch="pune";
				System.out.println("U Have Selected Pune Branch");	
				break;
				
			default: System.out.println(" Invalid Option");
			break;
		
			}
	}while(i>3);
	
	do{
			System.out.println("Enter Which Type Of Account U Want To Create:\n  1.SAVINGS ACCOUNT\n   2.CURRENT ACCOUNT\n");
			i=scan.nextInt();
			switch(i){ 
			case 1:accountType="savings";
			System.out.println(" U Have Selected Savings Account");
			System.out.println("THANK YOU FOR USING OUR SERVICE");
			break; 
					
		    case 2:accountType="current";
			System.out.println("U Have Selected Current Account");
			System.out.println("THANK YOU FOR USING OUR SERVICE");
			break; 
			
			default:System.out.println("Invalid Option");
			break;
				
			
         }
	}while(i>2);
	
		
		
		do{
			try{
				System.out.println("Enter the Minimum Opening Balance");
				openingBalance=scan.nextInt();
				boolean validate=ibs.validateopeningBalance(openingBalance);}
			catch(Exception e){
				System.out.println(" Number Exception");
			}
		}while(ibs.validateopeningBalance(openingBalance)==false);

		BankingBean bb=new BankingBean(customerName,mobileNo, emailAdd,dateOfBirth,panNo,aadharNo,openingBalance,branch,accountType,typeOfBank,username,password);
		ibs=new BankingServiceImpl();
		TransactionsBean transaction=new TransactionsBean();
		transaction.setTransactionAmount(openingBalance);
		transaction.setAccountBalance(openingBalance);
		transaction.setTypeOfTransaction("create Account");
		int aid=ibs.CreateAccount(bb,transaction);
		if (aid != 0) {
			System.out.println("account info is stored");
		} else {
			System.out.println("error occured");
		}
		return aid;

		
	

		}

	}

