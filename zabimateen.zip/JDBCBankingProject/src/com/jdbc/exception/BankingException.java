package com.jdbc.exception;

public class BankingException extends Exception{

	public BankingException(String be) {
		super(be);
	}
}

