package com.jdbc.service;

import com.jdbc.bean.BankingBean;
import com.jdbc.bean.TransactionsBean;
import com.jdbc.exception.BankingException;

public interface IBankingService {

	boolean validatecustomerName(String customerName) throws BankingException;
	boolean validatemobileNo(String mobileNo) throws BankingException;
	boolean validateemailAdd(String emailAdd) throws BankingException;
	boolean validatedateOfBirth(String dateOfBirth) throws BankingException;
	boolean validatepanNo(String panNo) throws BankingException;
	boolean validateopeningBalance(int openingBalance) throws BankingException;
	int CreateAccount(BankingBean ad, TransactionsBean transaction) throws BankingException;

	boolean validateaadharNo(String aadharNo) throws BankingException;
	public int ShowBalance(int AccountNo1) throws BankingException;
	public int Deposit(int amt,int d, TransactionsBean transaction) throws BankingException;
	boolean validatepassword(String password)throws BankingException;
	boolean validateusername(String username)throws BankingException;
	int Withdraw(int amt1, int d11, TransactionsBean transaction) throws BankingException;
	int FundTransfer(int a1, int a2, int a11, TransactionsBean transaction) throws BankingException;
	void PrintTransactions(int accountNumber) throws BankingException;
}