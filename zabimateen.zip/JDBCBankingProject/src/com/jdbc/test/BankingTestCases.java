package com.jdbc.test;

public class BankingTestCases {

}
