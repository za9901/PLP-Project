package com.demo.client;


import com.demo.entity.Student;
import com.demo.service.StudentService;
import com.demo.service.StudentServiceImpl;


public class Client {
	public static void main(String[] args) {


	StudentService service = new StudentServiceImpl();
	
Student student=new Student();
//student.setId(100);
student.setName("Sachin3");
service.addStudent(student);

student = service.findStudentById(105);
//System.out.print("studentId:"+student.getId());
//System.out.println(" name:"+student.getName());

student.setName("Sachin Ten");
service.updateStudent(student);

//student = service.findStudentById(103);
//System.out.print("studentId:"+student.getId());
//System.out.println(" name:"+student.getName());
	
//	service.removeStudent(student);
//System.out.println("End of program...");

}
}