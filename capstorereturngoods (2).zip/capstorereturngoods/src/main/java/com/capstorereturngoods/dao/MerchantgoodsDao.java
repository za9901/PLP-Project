package com.capstorereturngoods.dao;

import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.JpaRepository;

import com.capstorereturngoods.entity.MerchantReturnGoods;
import com.capstorereturngoods.entity.Returngoods;

@Primary
public interface MerchantgoodsDao extends JpaRepository<MerchantReturnGoods,Integer> {

	Object save(Returngoods goods);

	

}
