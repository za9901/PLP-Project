package com.capstorereturngoods.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capstorereturngoods.entity.MerchantReturnGoods;
import com.capstorereturngoods.entity.Returngoods;
import com.capstorereturngoods.service.MercantgoodsService;
import com.capstorereturngoods.service.ReturngoodsService;

@RestController
@RequestMapping("/Customer")

public class ReturngoodsController extends  MercantgoodsService{
static 	Map<Integer,Returngoods> customergoods = new HashMap<Integer,Returngoods>();
static 	Map<Integer,MerchantReturnGoods> merchantgoods = new HashMap<Integer,MerchantReturnGoods>();

	@Autowired
	ReturngoodsService returngoodsservice; 
	MercantgoodsService merchantgoodsservice;
	
	
	@RequestMapping(value = "/createproduct", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE , produces = MediaType.APPLICATION_JSON_VALUE)
	public Returngoods createAccount(@RequestBody Returngoods goods) {
		customergoods.put(goods.getProductid(), goods);
		System.out.println(goods);
		return this.returngoodsservice.createProduct(goods);
		
	}
	@ResponseBody
	@RequestMapping(value = "/merechantproduct", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE , produces = MediaType.APPLICATION_JSON_VALUE)
	public MerchantReturnGoods createProduct(@RequestBody MerchantReturnGoods goods) {
	
		return this.merchantgoodsservice.createProduct(goods);	
	}
	
	@RequestMapping(value = "/allproducts",  method = RequestMethod.GET)
	public List<Returngoods> getProducts() {
		
		return this.returngoodsservice.getProducts();
	
	}
	
	@RequestMapping(value = "/delete/{id}" , method = RequestMethod.DELETE)
	public  void  deleteProductById(@PathVariable int id) {
		Returngoods goods = customergoods.get(id);
		System.out.println(goods);
		
		this.returngoodsservice.deleteById(id);
//		MerchantReturnGoods merchantgoods = new MerchantReturnGoods();
//		merchantgoods.setProductid(goods.getProductid());
//		merchantgoods.setProductcategory(goods.getProductcategory());
//		merchantgoods.setProductname(goods.getProductname());
//		merchantgoods.setProducttype(goods.getProducttype());
//		merchantgoods.setProductrating(goods.getProductrating());
//		merchantgoodsservice.createProduct(merchantgoods);
//		this.merchantgoodsservice.newProduct(goods);
		//merchantgoods.putAll((Map<? extends Integer, ? extends MerchantReturnGoods>) goods);
//		Returngoods goods = customergoods.get(id);
//		System.out.println(goods);
	
	//	System.out.println(goods);
	
	}
	
	
	@RequestMapping(value = "/getproductbyid/{id}" , method = RequestMethod.GET)
	public Optional<Returngoods> viewEmployeeById( @PathVariable int id) {
//		Returngoods goods = new Returngoods();
//		System.out.println(goods);
		Returngoods goods = customergoods.get(id);
		System.out.println(goods);
		return  this.returngoodsservice.viewproductById(id);
		
	}
	

}


