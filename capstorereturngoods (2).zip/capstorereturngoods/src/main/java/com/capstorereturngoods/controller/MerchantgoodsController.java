package com.capstorereturngoods.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capstorereturngoods.entity.MerchantReturnGoods;
import com.capstorereturngoods.entity.Returngoods;
import com.capstorereturngoods.service.MercantgoodsService;
import com.capstorereturngoods.service.ReturngoodsService;

@RestController
@RequestMapping("/Merchant")
public class MerchantgoodsController {
	static 	Map<Integer,MerchantReturnGoods> merchantgoods = new HashMap<Integer,MerchantReturnGoods>();
	static 	Map<Integer,Returngoods> customergoods = new HashMap<Integer,Returngoods>();
	
	@Autowired

	MercantgoodsService merchantgoodsservice;
	ReturngoodsService returngoodsservice;
	
	@ResponseBody
	@RequestMapping(value = "/createproduct", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE , produces = MediaType.APPLICATION_JSON_VALUE)
	public MerchantReturnGoods createProduct(@RequestBody MerchantReturnGoods goods) {
	
		return this.merchantgoodsservice.createProduct(goods);	
	}
	
	@RequestMapping(value = "/allproducts",  method = RequestMethod.GET)
	public List<MerchantReturnGoods> getAllProducts() {
		
		return this.merchantgoodsservice.getAllProducts();
		
	}
	
	@RequestMapping(value = "/getproductbyid/{id}" , method = RequestMethod.GET)
	public Optional<MerchantReturnGoods> viewproductById( @PathVariable int id) {
		
		
		 return this.merchantgoodsservice.viewproductById(id);
		
	}
	

}
