import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup,Validators} from '@angular/forms';
import { MoviesService } from '../service/movies.service';
import{Router} from '@angular/router';


@Component({
  selector: 'app-add-movies',
  templateUrl: './add-movies.component.html',
  styleUrls: ['./add-movies.component.css']
})
export class AddMoviesComponent implements OnInit {

  // movformlabel: string ='Add Movies';

  constructor(private formBuilder: FormBuilder, private movService: MoviesService,private router:Router) { }

  addForm: FormGroup;

  ngOnInit() {

    this.addForm=this.formBuilder.group({

      id:[],
      movie_name:['',Validators.required],
      movie_category:['',Validators.required],
      movie_rating:['',[Validators.required,Validators.maxLength(4)]]
      
   });
  }

  onSubmit() {

    console.log('Movie details sent to server!');
    this.movService.createUser(this.addForm.value)
     .subscribe(data => {
      alert("Data Saved!");
      this.router.navigate(['list-movies']);  
     },
      error => {
       console.log("Error occured " + error);
       alert(error);
  
     });

     
  
   }

   onSubmitss(){
    this.router.navigate(['list-movies']);
  }
}
