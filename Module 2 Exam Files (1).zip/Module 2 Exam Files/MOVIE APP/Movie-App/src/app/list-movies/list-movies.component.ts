import { Component, OnInit } from '@angular/core';
import {Movie} from '../model/movies.model';
import { HttpClient } from '@angular/common/http';
import { MoviesService } from '../service/movies.service';
import{Router} from '@angular/router';

@Component({
  selector: 'app-list-movies',
  templateUrl: './list-movies.component.html',
  styleUrls: ['./list-movies.component.css']
})
export class ListMoviesComponent implements OnInit {

  movies :Movie[];
  filteredMovies: Movie[];

    _listFilter: string = '';
    get listFilter(): string {
      return this._listFilter;
    }
    set listFilter(value: string) {
      console.log('set listFilter' + this._listFilter);
      this._listFilter = value;
      this.filteredMovies = this.listFilter ? this.performFilter(this.listFilter) : this.movies;
    }

    performFilter(filterBy: string): Movie[] {
      filterBy = filterBy.toLocaleLowerCase();
      return this.movies.filter((movie: Movie) =>
        movie.movie_category.toLocaleLowerCase().indexOf(filterBy) !== -1);
    }
  
   constructor(private movService: MoviesService,private router:Router){}

   ngOnInit() {
    this.movService.getMovies()
    .subscribe((data: Movie[]) =>{
      this.movies=data;
      this.filteredMovies = this.movies;
    });}

    deleteMov(movie: Movie): void{
      this.movService.deleteMovies(movie.id)
      .subscribe(data => {
         this.filteredMovies = this.movies.filter(mov => mov !== movie);
      })
    }
      editMov(movie: Movie): void {  
        localStorage.removeItem('editMovId');  
        localStorage.setItem('editMovId', movie.id.toString());  
        this.router.navigate(['edit-movies']);  
      } 
      
      getMov(mov:Movie){
        this.movService.getMovieById(mov.id).subscribe((data: Movie[]) => { this.filteredMovies=this.movies.filter(movie=>movie==mov) },
        (error) => { console.log("Error occured" + error); alert(error); }); 
         
        
      }

      onSubmit(){
        this.router.navigate(['add-movies']);
      }

      onSubmits(){
        this.router.navigate(['login']);
      }

      onSubmitss(){
        this.router.navigate(['login']);
      }
}





  
    
     
    
    
    
  



