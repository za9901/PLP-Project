import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup,Validators} from '@angular/forms';
import { MoviesService } from '../service/movies.service';
import{Router} from '@angular/router';


@Component({
  selector: 'app-edit-movies',
  templateUrl: './edit-movies.component.html',
  styleUrls: ['./edit-movies.component.css']
})
export class EditMoviesComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, private movService: MoviesService,private router:Router ) { }
  editForm: FormGroup;
  btnvisibility: boolean = true;  
  movformlabel: string = 'Edit Movie';  
  movformbtn: string = 'Update';
  ngOnInit() {
    this.editForm = this.formBuilder.group({  
      id: [],  
      movie_name: ['', Validators.required],  
      movie_category: ['', Validators.required],  
      movie_rating: ['', [Validators.required, Validators.maxLength(4)]]  
    });  
    let movid = localStorage.getItem('editMovId');  
    if (+movid > 0) {  
      this.movService.getMovieById(+movid).subscribe(data => {  
        this.editForm.patchValue(data);  
      })  
      this.btnvisibility = false;  
      this.movformlabel = 'Edit Movie';  
      this.movformbtn = 'Update';  
    }  
  }  
  onUpdate() {  
    console.log('Update fire');  
    this.movService.updateMovie(this.editForm.value).subscribe(data => {  
      alert("Record Updated");
      this.router.navigate(['list-movies']);  
    },  
      error => {  
        alert(error);  
      });  

      
}
onSubmitss(){
  this.router.navigate(['list-movies']);
}
}






  

