// The let statement declares a block scope local variable, 
// optionally initializing it to a value.
// let allows you to declare variables that are limited in scope to the block, statement, or expression on which it is used. This is unlike the var keyword, which defines a variable globally, or locally to an entire function regardless of block scope.
function varTest() {
    var x = 1;
    if (true) {
        var x = 2; // same variable!
        console.log(x); // 2
    }
    console.log(x); // 2
}
function letTest() {
    var x = 1;
    if (true) {
        var x_1 = 2; // different variable
        console.log(x_1); // 2
    }
    console.log(x); // 1
}
varTest();
console.log();
letTest();
console.log();
var number = 42;
//const number;
//let number = 42;
try {
    number = 99;
}
catch (err) {
    console.log(err);
    // expected output: TypeError: invalid assignment to const `number'
    // Note - error messages will vary depending on browser
}
console.log(number);
