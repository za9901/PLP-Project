// Rest syntax looks exactly like spread syntax but is used for destructuring arrays and objects. In a way, rest syntax is the opposite of spread syntax: spread 'expands' an array into its elements, while rest collects multiple elements and 'condenses' them into a single element.
//The rest parameter syntax allows us to represent an indefinite number of arguments as an array.
function sum() {
    var theArgs = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        theArgs[_i] = arguments[_i];
    }
    return theArgs.reduce(function (previous, current) {
        return previous + current;
    });
}
console.log(sum(1, 2, 3));
// expected output: 6
console.log(sum(1, 2, 3, 4));
// expected output: 10
//   A function's last parameter can be prefixed with ... which will cause all remaining (user supplied) arguments to be placed within a "standard" javascript array. Only the last parameter can be a "rest parameter".
function myFun(a, b) {
    var manyMoreArgs = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        manyMoreArgs[_i - 2] = arguments[_i];
    }
    console.log("a", a);
    console.log("b", b);
    console.log("manyMoreArgs", manyMoreArgs);
}
myFun("one", "two", "three", "four", "five", "six");
// Console Output:
// a, one
// b, two
// manyMoreArgs, [three, four, five, six]
