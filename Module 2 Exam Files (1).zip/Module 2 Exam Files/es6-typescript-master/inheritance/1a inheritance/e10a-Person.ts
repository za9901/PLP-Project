export class Person {
    //properties
    firstName: string;
    lastName: string;
    constructor(fName: string, lName: string) {
      //assign the properties
      this.firstName = fName;
      this.lastName = lName;
    }
    getFullName() {
      return `Full name is : ${this.firstName} ${this.lastName}`;
    }
  }