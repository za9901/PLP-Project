var message = "hello";
console.log(message);
