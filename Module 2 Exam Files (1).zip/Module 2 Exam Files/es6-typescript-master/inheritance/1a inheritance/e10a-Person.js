"use strict";
exports.__esModule = true;
var Person = /** @class */ (function () {
    function Person(fName, lName) {
        //assign the properties
        this.firstName = fName;
        this.lastName = lName;
    }
    Person.prototype.getFullName = function () {
        return "Full name is : " + this.firstName + " " + this.lastName;
    };
    return Person;
}());
exports.Person = Person;
