import { EmpRoutingModule } from '../app/emp-routing/emp-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ReactiveFormsModule } from '../../node_modules/@angular/forms';
import { ListEmpComponent } from "./list-emp/list-emp.component";
import { AddEmpComponent } from './add-emp/add-emp.component';
import { EditEmpComponent } from './edit-emp/edit-emp.component';

@NgModule({
  declarations: [
    AppComponent,
    ListEmpComponent,
    AddEmpComponent,
    EditEmpComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    EmpRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
