import { EmpRoutingModule } from './emp-routing.module';

describe('EmpRoutingModule', () => {
  let empRoutingModule: EmpRoutingModule;

  beforeEach(() => {
    empRoutingModule = new EmpRoutingModule();
  });

  it('should create an instance', () => {
    expect(empRoutingModule).toBeTruthy();
  });
});
