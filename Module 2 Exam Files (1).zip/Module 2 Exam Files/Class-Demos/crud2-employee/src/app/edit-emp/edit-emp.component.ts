import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup,Validators} from '@angular/forms';
import { EmployeeService } from '../service/employee.service';
import{Router} from '@angular/router';


@Component({
  selector: 'app-edit-emp',
  templateUrl: './edit-emp.component.html',
  styleUrls: ['./edit-emp.component.css']
})
export class EditEmpComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, private empService: EmployeeService,private router:Router ) { }
  editForm: FormGroup;
  btnvisibility: boolean = true;  
  empformlabel: string = 'Edit Employee';  
  empformbtn: string = 'Update';
  ngOnInit() {
    this.editForm = this.formBuilder.group({  
      id: [],  
      employee_name: ['', Validators.required],  
      employee_salary: ['', [Validators.required, Validators.maxLength(9)]],  
      employee_age: ['', [Validators.required, Validators.maxLength(3)]]  
    });  
    let empid = localStorage.getItem('editEmpId');  
    if (+empid > 0) {  
      this.empService.getEmployeeById(+empid).subscribe(data => {  
        this.editForm.patchValue(data);  
      })  
      this.btnvisibility = false;  
      this.empformlabel = 'Edit Employee';  
      this.empformbtn = 'Update';  
    }  
  }  
  onUpdate() {  
    console.log('Update fire');  
    this.empService.updateEmployee(this.editForm.value).subscribe(data => {  
      alert("Record Updated");
      this.router.navigate(['list-emp']);  
    },  
      error => {  
        alert(error);  
      });  

      
}
onSubmitss(){
  this.router.navigate(['list-emp']);
}
}
