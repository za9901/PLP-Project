import { EmployeeService } from '../service/employee.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators } from '../../../node_modules/@angular/forms';
import {Router} from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
LoginForm: FormGroup;
submitted:boolean=false;
invalidLogin:boolean=false;
    
  constructor(private formBuilder:FormBuilder,private empService: EmployeeService,private router:Router) { }
 

  ngOnInit() {
    this.LoginForm=this.formBuilder.group({
      email:['',Validators.required],
      password:['',[Validators.required,Validators.maxLength(10)]]
    });
  }

  onSubmit(){
    this.submitted=true;
    if(this.LoginForm.invalid){
  alert(" Invalid Login Details:")
    }
  if(this.LoginForm.controls.email.value=='azabi.s777@gmail.com' && this.LoginForm.controls.password.value=='zabi121@Z')
  {
    this.router.navigate(['list-emp']);
  }
  else{
    this.invalidLogin=true;
    alert(" Enter Correct Username and Password");
  }
 }
}






// import { Component, OnInit } from '@angular/core';
// import { Login } from './../model/login.model';
// import { Router } from '@angular/router';

// @Component({
//   selector: 'app-login',
//   templateUrl: './login.component.html',
//   styleUrls: ['./login.component.css']
// })
// export class LoginComponent implements OnInit {
//   loginModel = new Login('', '');
//   constructor(private router: Router) {}

//   ngOnInit() {}

//   onSubmit() {
//     console.log("Submitted");
//     console.log(this.loginModel.loginName);
//     console.log(this.loginModel.password);
//     if (
//       this.loginModel.loginName == 'test' &&
//       this.loginModel.password == 'pass'
//     ) {
//       this.router.navigate(['list-emp']);
//     }
//     else {
//       alert("invalid login, try again!");
//     }
//   }
// }
