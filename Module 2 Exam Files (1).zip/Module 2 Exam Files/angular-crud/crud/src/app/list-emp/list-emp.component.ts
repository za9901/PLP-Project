import { Component, OnInit } from '@angular/core';
import {Employee} from '../model/employee.model';
import {HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-list-emp',
  templateUrl: './list-emp.component.html',
  styleUrls: ['./list-emp.component.css']
})
export class ListEmpComponent implements OnInit {

  employees :Employee[];

  baseUrl:  string ='http://localhost:3000/employees';

  constructor(private http: HttpClient) { }

  getEmployees(){
    return this.http.get<Employee[]>(this.baseUrl);
  }

  ngOnInit() {
    this.getEmployees()
    .subscribe((data: Employee[]) =>{
      this.employees=data;
    });

    console.log(this.employees);
    
  }

}
