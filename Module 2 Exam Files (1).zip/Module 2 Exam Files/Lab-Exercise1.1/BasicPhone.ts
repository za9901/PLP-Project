import  {Mobile } from './Mobile'
export class BasicPhone extends Mobile{
    MobileType: string;

    constructor(MId: string,MName: string,MCost: string, MType: string){
         super(MId,MName,MCost);

         this.MobileType=MType;
    }


    toString()
    {
        return `${this.MobileId} - ${this.MobileName} ${this.MobileCost} => ${ this.MobileType}`;
    }
}
