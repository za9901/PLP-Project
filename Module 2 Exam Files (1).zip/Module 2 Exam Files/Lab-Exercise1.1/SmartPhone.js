"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
var Mobile_1 = require("./Mobile");
var SmartPhone = /** @class */ (function (_super) {
    __extends(SmartPhone, _super);
    function SmartPhone(MId, MName, MCost, MType) {
        var _this = _super.call(this, MId, MName, MCost) || this;
        _this.MobileType = MType;
        return _this;
    }
    SmartPhone.prototype.toString = function () {
        return this.MobileId + " - " + this.MobileName + " " + this.MobileCost + " => " + this.MobileType;
    };
    return SmartPhone;
}(Mobile_1.Mobile));
exports.SmartPhone = SmartPhone;
