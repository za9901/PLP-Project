package com.practiceprograms;
import java.math.*;
public class Scientific extends General{
void sin(double h)
{
	double t= Math.toRadians(h);
	double result= Math.sin(t);
	System.out.println(" sin(h) is :"+result);
}
void cos(double h)
{
	double t= Math.toRadians(h);
	double result= Math.cos(t);
	System.out.println(" cos(h) is :"+result);
}
void tan(double h)
{
	double t= Math.toRadians(h);
	double result= Math.tan(t);
	System.out.println(" tan(h) is :"+result);
}


}
