package com.practiceprograms;

public class Tv extends Electronic_Machines{
	
	
	private String display;
	public Tv(String aud, String mod, String elec)
	{
		System.out.println("I am fine ,Thank you");
	}
	
	void sound()
	{
		super.sound();
		System.out.println("is perfect now");
		
	}
	
	void display()
	{
		System.out.println(" display HD channels");
	}
	
}
