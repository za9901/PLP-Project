package com.practiceprograms;

public class Prymid extends Object
{
	

	private  String walk;
	private String breathe;
	private String heart;
	public String getWalk() {
		return walk;
	}
	public void setWalk(String walk) {
		this.walk = walk;
	}
	public String getReathe() {
		return breathe;
	}
	public void setReathe(String breathe) {
		this.breathe = breathe;
	}
	public String getHeart() {
		return heart;
	}
	public void setHeart(String heart) {
		this.heart = heart;
	}
	

    Prymid()
    {
    	System.out.println("");
    
    } 
    
   
    
	public Prymid(String walk, String breathe, String heart) {
		super();
		this.walk = walk;
		this.breathe = breathe;
		this.heart = heart;
	
	}
	
	void run()
	{
		System.out.println(" run");
	}
	
	void eyes()
	{
		System.out.println(" eyes");
		
	}
	
	void colour()
	{
		System.out.println(" only single colour");
		
	}
	}

