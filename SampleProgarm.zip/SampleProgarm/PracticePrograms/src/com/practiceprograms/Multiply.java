package com.practiceprograms;

public class Multiply {

	public static void main(String[] args){
					int a=30,b=30,mul=0;
					if(a<b) {
						mul=a;
						a=b;
						b=mul;
						mul=0;}
					for(int i=0;i<b;i++){
						mul+=a;}
					System.out.println("The answer is " + mul);}}
				

			


	


