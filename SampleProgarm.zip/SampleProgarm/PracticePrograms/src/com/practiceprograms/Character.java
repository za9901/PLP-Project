package com.practiceprograms;
import java.util.Arrays;
public class Character {

	public static void main(String[] args) {
			    char[] array = new char[5];
			    for (int i = 0; i < array.length; i++) { 
			      System.out.println(array[i]);}}}
			
			

	


