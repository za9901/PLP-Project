package com.practiceprograms;

public class Test {
	
	
	public static void main(String[] args) {
		Electronic_Machines  p1= new Tv("95","sony","60");
		Electronic_Machines  p2= new Radio("100","philips","29");
		Electronic_Machines  p3= new Dvd("10","Xperia","98"); 
		
				
	p2.gm();

		
		
		//p1.sound();
		//p2.cost();
		//p3.sound();
		
	}

}
