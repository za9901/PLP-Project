package com.practiceprograms;

public class Dvd extends Electronic_Machines {
	 
	
	private String insert;
	public Dvd(String aud, String mod, String elec)
	{
		System.out.println("hi");
	}
	void place()
	{
		System.out.println(" insert the DVD");
	}
	
	void sound()
	{
		super.sound();
		System.out.println(" increase the sound please");
	}
}
