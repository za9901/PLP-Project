package com.practiceprograms;
import java.math.*;
import java.util.Scanner;
public class General {
int c;
void add(int a ,int b)
{
	c=a+b;
	System.out.println(" add of two numbers is " +c);
}

void sub(int a ,int b)
{
	c=a-b;
	System.out.println(" sub of two numbers is " +c);
}

void div(int a ,int b)
{
	c=a/b;
	System.out.println(" div of two numbers is " +c);
}

void mul(int a ,int b)
{
	c=a*b;
	System.out.println(" mul of two numbers is " +c);
}
}