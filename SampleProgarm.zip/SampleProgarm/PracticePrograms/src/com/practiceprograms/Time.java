package com.practiceprograms;
import java.util.Date;
public class Time {

	public static void main(String[] args) {
	

	}

}
