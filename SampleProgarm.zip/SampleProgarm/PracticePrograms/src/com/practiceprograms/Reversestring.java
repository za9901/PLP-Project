package com.practiceprograms;

public class Reversestring {

	public static void main(String[] args) {
	     String s = "Zabiulla Shariff";  
	        String Str = "";    
	        for(int i = s.length()-1; i >= 0; i--){    
	            Str = Str + s.charAt(i);}          
	        System.out.println("Original string: " + s);    
	        System.out.println("Reverse of given string: " + Str);    
            System.out.println(s.length());}}
	




