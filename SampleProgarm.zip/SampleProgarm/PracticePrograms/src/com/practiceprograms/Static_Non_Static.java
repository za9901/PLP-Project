package com.practiceprograms;
public class Static_Non_Static {
	int n=10;
	static int g=7;
	public static void main(String[] args) {
		Static_Non_Static obj1 = new Static_Non_Static();
		Static_Non_Static obj2 = new Static_Non_Static();
		System.out.println("obj1.n");
	System.out.println("obj2.g");}}