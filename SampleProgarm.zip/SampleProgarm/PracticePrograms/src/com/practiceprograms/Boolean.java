package com.practiceprograms;



public class Boolean {

    public static void main(String[] args) {
	    boolean[] array = new boolean[5];
	    for (int i = 0; i < array.length; i++) { 
	      System.out.println(array[i]);}}}
	
	

		
	

	


