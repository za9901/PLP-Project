package com.practiceprograms;

public class Switchwords {

	public static void main(String[] args) {
            int a=506899226, i=0,n=a, temp=0,div=1;
            while(n>0){
            	n/=10;
            	i++;
            	}
            System.out.println(i);
            for(n=i;n>1;n--)
            div*=10;
           
             for(;i>0;i--){
            	 temp=a/div;
                 a%=div;
                 div/=10;
    
             switch(temp){
             
             case 0: System.out.println("zero");
             break;
             
             case 1: System.out.println("one");
             break;
             
             case 2: System.out.println("Two");
             break;
             
             case 3: System.out.println("three");
             break;
             
             case 4: System.out.println("four");
             break;
             
             case 5: System.out.println("Five");
             break;
             
             case 6: System.out.println("six");
             break;
             
             case 7: System.out.println("seven");
             break;
             
             case 8: System.out.println("eight");
             break;
             
             case 9: System.out.println("nine");
             break;
             
             }
	}
}
}
                 
                 
            
            
            	
            	
            
            

	


