package com.practiceprograms;
import java.util.Scanner;
public class User {

	public static void main(String[] args){		
		 String username, password;
		 int i=0;
		 do{
	        Scanner s = new Scanner(System.in);
	        System.out.print("Enter username:");
	        username = s.nextLine();
	        System.out.print("Enter password:");
	        password = s.nextLine();
	       
	        if(username.equals("user") && password.equals("user"))
	        {
	            System.out.println("Authentication Successful");
	             i=5;
	        }   
	        
	        else {
	        	System.out.println(" Authentication Unsuccessful");
	        	
	        } 
	        i++;
	        
	        while(i==3)
	        {
	    
	            System.out.println("Login denied becuase u entered three times");
	            i++;
	        } 
		 }while(i<3);
	}
}
	        
	    















