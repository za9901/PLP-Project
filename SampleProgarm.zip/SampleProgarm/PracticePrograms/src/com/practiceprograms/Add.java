package com.practiceprograms;

public class Add {
	public static void main(String[] args) {
					int a=444,i=0,no=a,temp=0;
					while(no>0) {
						no/=10;
						i++;}
					if(i==3) {
						while(a/10!=0) {
							while(a!=0) {
								temp+=a%10;
								a/=10;}
								a=temp;
							temp=0;}
						System.out.println(a);}
					 else {
	System.out.println("The entered number is not a 3-digit number");}}}
					
				

			 

	


