package com.practiceprograms;

public class Monkey {

}
