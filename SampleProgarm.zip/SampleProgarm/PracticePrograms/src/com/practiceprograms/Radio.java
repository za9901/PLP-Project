package com.practiceprograms;

public class Radio extends Electronic_Machines {
	
	private String signal;
	private String noise;
	
	public Radio(String aud, String mod, String elec)
	{
		System.out.println("hello! how are you");
	}
	
	void fm()
	{
		System.out.println(" too much disturbance");
		
	}
	
	void cost()
	{
		super.cost();
		System.out.println(" radio is the cheapest one among the three");
		
	}
}
