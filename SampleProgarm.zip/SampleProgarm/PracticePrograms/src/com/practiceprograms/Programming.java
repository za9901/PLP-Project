package com.practiceprograms;
import java.math.*;
public class Programming extends General {
	
 void prog(int n)
 {
	 switch(n){
	 case 1:System.out.println(" the binary conversion is 0010");break;
	 case 2:System.out.println(" the binary conversion is 0010");break;
	 case 3:System.out.println(" the binary conversion is 0011");break;
	 case 4:System.out.println(" the binary conversion is 0100");break;
	 case 5:System.out.println(" the binary conversion is 0101");break;
	 case 6:System.out.println(" the binary conversion is 0110");break;
	 case 7:System.out.println(" the binary conversion is 0111");break;
	 case 8:System.out.println(" the binary conversion is 1000");break;
	 case 9:System.out.println(" the binary conversion is 1001");break;
	 case 10:System.out.println(" the binary conversion is 1010");break;
	 case 11:System.out.println(" the binary conversion is 1011");break;
	 case 12:System.out.println(" the binary conversion is 1100");break;
	 case 13:System.out.println(" the binary conversion is 1101");break;
	 case 14:System.out.println(" the binary conversion is 1110");break;
	 default: System.out.println("values are out of range");break;
 }
}
}
