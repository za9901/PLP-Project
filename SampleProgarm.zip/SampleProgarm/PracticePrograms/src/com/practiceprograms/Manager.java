package com.practiceprograms;

public class Manager {

}
