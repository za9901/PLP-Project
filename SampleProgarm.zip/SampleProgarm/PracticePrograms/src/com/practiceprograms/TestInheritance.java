package com.practiceprograms;

public class TestInheritance {

	public static void main(String[] args) {
		
		
		Human h= new Human();
		h.run();
		h.eyes();
		Apes a = new Apes();
		a.colour();
		
	}

}
