package com.practiceprograms;

public class Student {

	
	int sid=41;
	String name ="default";
	int batchCode= 1234;
	int pwd= 1234;
	
	Student()
	{
		System.out.println(" ");
	}

	public Student(int sid, String name, int batchCode, int pwd) {
		
		this.sid = sid;
		this.name = name;
		this.batchCode = batchCode;
		this.pwd = pwd;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getBatchCode() {
		return batchCode;
	}

	public void setBatchCode(int batchCode) {
		this.batchCode = batchCode;
	}

	public int getPwd() {
		return pwd;
	}

	public void setPwd(int pwd) {
		this.pwd = pwd;
	}
	
	
}
