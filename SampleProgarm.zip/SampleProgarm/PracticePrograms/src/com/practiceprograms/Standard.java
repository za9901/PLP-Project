package com.practiceprograms;

public class Standard {

}
