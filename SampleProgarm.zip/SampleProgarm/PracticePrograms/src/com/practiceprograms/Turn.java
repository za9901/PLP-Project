package com.practiceprograms;

public class Turn {

	public static void main(String[] args) {
		String grades= "123.135.243.167";
		
		String th[]= grades.split("\\.");
		for(String  y : th)
		{
			System.out.println(" grade is :" +y);
			
		}

	}



	}

