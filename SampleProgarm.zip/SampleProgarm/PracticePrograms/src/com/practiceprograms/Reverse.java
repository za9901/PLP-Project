package com.practiceprograms;
public class Reverse{
	
	public static String reverse(String str){
		if(str==null || str.equals(""))
			return str;
		
		char c[]=str.toCharArray();
		for(int i=0,h=str.length()-1;i<h;i++,h--)
		{
		
			char chartemp=c[i];
			c[i]=c[h];	
			c[h]=chartemp;
		}
		return String.copyValueOf(c);
	}
	public static void main(String[] args)
	{
		String str ="Zabiulla Shariff";
		str=reverse(str);
		System.out.println("Reversed String is:" +str);
		
	}

	}


