package com.practiceprograms;

public class Electronic_Machines extends Object {
	static int count; 
	private String audio;
	private String model;
	private String electricity;
	public String getAudio() {
		return audio;
	}
	public void setAudio(String audio) {
		this.audio = audio;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getElectricity() {
		return electricity;
	}
	public void setElectricity(String electricity) {
		this.electricity = electricity;
	}
	
	public  Electronic_Machines()
	{
		
		count++;
	}
	
	
	public Electronic_Machines(String audio, String model, String electricity) {
		super(); 
		this.audio = audio;
		this.model = model;
		this.electricity = electricity;
	
		
	}
	
	
	
	void sound()
	{
		System.out.println(" sound is a bit low");
		
	}
	
	void cost()
	{
		System.out.println(" cost is too high");
	}
	
		public void gm()
		{
			System.out.println(" the number of objects are"+count);
		}
		
	}

