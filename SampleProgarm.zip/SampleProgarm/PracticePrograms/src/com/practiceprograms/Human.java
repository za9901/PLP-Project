package com.practiceprograms;

public class Human extends Prymid
{
	@Override// optional
	void run()
	{
		super.run();
		System.out.println(" run faster and faster ");
	}
	
	
	
	

}
