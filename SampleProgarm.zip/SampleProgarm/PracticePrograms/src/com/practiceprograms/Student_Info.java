package com.practiceprograms;

public class  Student_Info {
		 
	 
	public static void main(String[] args)
	{
	
		Student s = new Student(41," default", 1234,1234);
       System.out.println( s.getSid()+"  "+s.getName());

	 System.out.println(" values after changing");
	 System.out.println(" hi zabi");
	
	 s.setSid(23);
	 s.setName(" zabi");
	 s.setBatchCode(1960489);
	 s.setPwd(123456789);
	 
	 System.out.println( s.getSid()+"  "+ s.getName());
	 System.out.println( s.getBatchCode()+"  "+ s.getPwd());
	}
}
	
	
	
