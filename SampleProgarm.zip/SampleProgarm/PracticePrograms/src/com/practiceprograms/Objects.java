package com.practiceprograms;

public class Objects {
		 static int noOfObjects = 0; 
		    public Objects(){ 
		        noOfObjects += 1;} 
		    public static void main(String args[]){ 
		       Objects t1 = new Objects (); 
		       Objects t2 = new Objects(); 
		       Objects  t3 = new Objects (); 
		       Objects  t4 = new Objects (); 
		       System.out.println(Objects.noOfObjects);}
			
			
			}
		    
	
		

	


