package com.practiceprograms;

public class Apes extends Prymid {
   @Override// Optional
	void colour()
	{
		super.colour();
		System.out.println(" Black and brown");
	}
}
