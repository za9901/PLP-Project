package com.practiceprograms;

import java.util.Scanner;
import java.math.*;
public class Calculator {
public static void main(String args[])
{
	int a,b,n;
	double h;
	Scanner I=new Scanner(System.in);
	General s=new General();
	Scientific sc=new Scientific();
	Programming p=new Programming();
	System.out.println("enter a value");
	a=I.nextInt();
	System.out.println("enter the value for general calculator");
	b=I.nextInt();
	s.add(a,b);
	s.sub(a,b);
	s.div(a,b);
	s.mul(a,b);
	System.out.println(" enter the value for scientific calculator");
	h=I.nextDouble();
	sc.sin(h);
	sc.cos(h);
	sc.tan(h);
	System.out.println("enter the value for programming calculator");
    n=I.nextInt();
	p.prog(n);
	
	
}

	

}
