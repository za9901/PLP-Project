package com.prac;

public class PersonMain extends Person1 {
	enum gender{
		 Male, Female}
	public static void main(String[] args) {
		Person1 p1=new Person1("Zabiulla","Shariff","9620544890");
		p1.displayPerson1Details();
        gender g1=gender.Male;
        System.out.println("Gender:"+g1);
	}}


