package com.prac;

public class Add {

	public static void main(String[] args) {

//   String s1="Zabiulla";    //It can be done with the "+" operator like 
		                         // for eg:   String s= "zabi"  +  " shariff";
//   String s2="  Shariff";
//   String s3=s1.concat(s2);
//   System.out.println(s3);
 
//		String r= "Zabiulla Shariff";
//		for(int i=0;i<r.length();i++)
//		{
//			if(i % 2!=0)
//			{
//				r=r.substring(0,i-1) + "#" + r.substring(i,r.length());
//				}}
//		System.out.println(r);
//

		
		
		
			}
		
	}


