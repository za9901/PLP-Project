package com.prac;

public class Person1 extends Object{
	
	private String fName;
    private String lName;
    private  String number;
  
	public String getfName() {
	return fName;
}
    public void setfName(String fName) {
	this.fName = fName;
}
    public String getlName() {
	return lName;
}
    public void setlName(String lName) {
	this.lName = lName;
}
    public String getNumber() {
	return number;
}
    public void setNumber(String number) {
	this.number = number;
}
	public Person1()
	{
		System.out.println("hello");
	}
	public Person1(String fName, String lName, String number) {
		super();
		this.fName = fName;
		this.lName = lName;	
		this.number = number;
	}
public void displayPerson1Details(){
	 System.out.println("fName:" + fName );
	 System.out.println("LName:" + lName );
	 System.out.println("Number:" + number);
 }  
	}


