package com.prac;
import java.util.Scanner;
public  class PersonDetails {

	public static void main(String[] args) {
		System.out.println("First_Name:   Zabiulla");
		System.out.println("Last_Name:    Shariff");
		System.out.println("Gender:       Male");
		System.out.println("Age:          23");
		System.out.println("Weight:       68kg");
	}

}
