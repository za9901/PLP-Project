package com.zabi;
import java.util.*;
public class TreeSetCustomObject {

	    public static void main(String a[]) {
	        TreeSet<Employee> ts = new TreeSet<Employee>();
	        ts.add(new Employee(104, "Arjun", 10000));
	        ts.add(new Employee(105, "Dinesh", 50000));
	        ts.add(new Employee(101, "John", 40000));
	        ts.add(new Employee(102, "Krish", 44500));
	        ts.add(new Employee(103, "Arun", 20000));
	        // adding duplicate entry
	        ts.add(new Employee(103, "Arun", 20000));
	        // check if duplicate entry is there or not
	        for (Employee e : ts) {
	            System.out.println(e);
	        }
	    }
	}
	 

