package com.zabi;

import java.io.*;


public class Main {
	
	    static String STRING_A = "Hi";
	    static String STRING_B = "Hai";
	    public static void main(String[] args) throws IOException {
	        String originalFilePath = "C://Users//zshariff//Desktop//Sample.txt";
	        String s = "";
	        BufferedReader reader = null;
	        BufferedWriter writer = null;
	        try {
	            reader = new BufferedReader(new FileReader(originalFilePath));
	            String currentReadingLine = reader.readLine();
	            while (currentReadingLine != null) {
	                s += currentReadingLine + System.lineSeparator();
	                currentReadingLine = reader.readLine();}
	            String modifiedFileContent = s.replaceAll(STRING_A, STRING_B);
	            writer = new BufferedWriter(new FileWriter(originalFilePath));
	            writer.write(modifiedFileContent);
	        } catch (IOException e) {
	        } finally {
	            try {
	                if (reader != null) {
	                    reader.close();}
	                if (writer != null) {
	                    writer.close();}
	            } catch (IOException e) {  }}}}

