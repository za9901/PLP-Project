package com.regularexpressions;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regular {

	public static void main(String[] args) {
		int c;
		Scanner s=new Scanner(System.in);
		String msg="Ajay";
		Pattern p1=Pattern.compile("^[A-Z][a-z]{3,3}");
         Matcher m=p1.matcher(msg);
		if(m.find()){
			System.out.println(" Match Found:"   +m.group());
		}
		else  
		{
			System.out.println(" Match Not Found");
		}
//	
//		System.out.println(" Do u want to continue :");
//		c=s.nextInt();
//		
//		
//		System.out.println("Yes/no:"+c);
	}
}
