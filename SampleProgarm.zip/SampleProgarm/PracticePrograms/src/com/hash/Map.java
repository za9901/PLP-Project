package com.hash;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class Map {
public static void  main(String[]  args){
	
	LinkedHashMap<String,String> codes=new LinkedHashMap<String,String>();
	codes.put("26", null);
	codes.put("cat", "23");
	codes.put(null, null);
	codes.put("True", "45");
	
	for(String key:codes.keySet()){
		System.out.println(key);
		System.out.println(codes.get(key));
		
	}
	
	
}
}
