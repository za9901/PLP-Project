package com.hash;
import java.util.TreeMap;
public class Maps {

	public static void main(String[] args) {
	
  TreeMap t=new TreeMap();
  t.put("A2", "two");
  t.put("B4", "four");
  t.put("C3", null);
  t.put("D5", "five");
  t.put("E6", "six");
  t.put("F7", "seven");
  
  System.out.println("Value Before Modification:"+t);
  System.out.println(" Value Removed:"+t.put("C3","tp"));
  System.out.println(" Value After Modification:"+t);
  
	}

}
