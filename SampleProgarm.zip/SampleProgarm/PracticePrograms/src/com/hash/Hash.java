package com.hash;
import java.util.*;
public class Hash {

	public static void main(String[] args) {
	
		Hashtable<String,String> codes=new Hashtable<String,String>();
		codes.put("1", "hi");
		codes.put("cat", "23");
		codes.put("53","hi");
		codes.put("True", "45");
		System.out.println("The HashTable is as follows:"+codes);
	}

}
