package com.collections;
import java.util.ArrayList;
public class Arr {

	public static void main(String[] args) {
	ArrayList<String>a1=new ArrayList<String>();
	ArrayList<String>a2=new ArrayList<String>();
	a1.add("A");
	a1.add("B");
	a1.add("C");
	a1.add("D");
	a1.add("E");
	System.out.println(" Iterating Original ArrayList");
	for(String str:a1){
		System.out.println(str);}
	
	a2.add("F");
	a2.add("G");
	a2.add("H");
	a2.add("I");
	a2.add("J");
	
	boolean baddAll=a1.addAll(a2);
	System.out.println(" Wheather Invoking ArrayList Changed"     +baddAll);
	for(String str:a1){
		System.out.println(str);}
		
	}
	

	}


