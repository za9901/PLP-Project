package com.collections;

import java.util.*;
public class ListToSet {

	public static void main(String[] args) {
		List aList=new ArrayList();
		aList.add("hi");
		aList.add("1");
		aList.add("welcome");
		
		Set<String> hSet=new HashSet<String>(aList);
		hSet.addAll(aList);
		System.out.println(" Created HashSet is");
		for(String x : hSet){
			System.out.println(x);}
		
		Set<String>tSet=new TreeSet<String>(aList);
		tSet.addAll(aList);
		System.out.println(" Created TreeSet is");
		for(String x : tSet){
			System.out.println(x);}

	}

}
