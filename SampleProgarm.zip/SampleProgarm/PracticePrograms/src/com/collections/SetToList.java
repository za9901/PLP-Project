package com.collections;
import java.util.*;
public class SetToList {

	public static void main(String[] args) {
	Set<String>s=new HashSet<String>();
	s.add("2");
	s.add("2");
	s.add("welcome");
	
	List<String>aList=new ArrayList<String>(s);
	aList.add("1");
	aList.add("B");
	aList.add("2");
	System.out.println(" Created ArrayList is");
	for(String x : aList){
		System.out.println(x);}
	
	
	List<String>bList=new LinkedList<String>(s);
	System.out.println(" Created LinkedList is");
	for(String x : bList){
		System.out.println(x);}
	}
	
	
	}


