package com.exceptions;


import java.io.IOException;

public class UsageTryCatch {

	public static void main(String[] args)   {
	try{
		
//		String s="hello";
//		System.out.println(s.length());
//		
//		String s1=(String)s;
//		System.out.println(s1);

		int x=10;
		int res=x/0;
		System.out.println("res");
	}
	catch(	NullPointerException e){
		System.out.println(" the execution is failed ");
		
	}
	
	catch(ArithmeticException e1)
	{
  System.out.println(" ERROR IS OCCURED");
}
	catch(Exception e){
		System.out.println(" finally, There is an compilation error");
	}
	finally{
		System.out.println(" done");}
	}
}