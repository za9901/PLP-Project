package com.exceptions;

public class Serialization {

	public static void main(String[] args) {


	}

}
