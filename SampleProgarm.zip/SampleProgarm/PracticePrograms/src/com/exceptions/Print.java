package com.exceptions;
import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
public class Print {
	public static void main(String[] args) {
		InputStreamReader r=new InputStreamReader(System.in);
		
		try {
			
			System.out.println(" Enter the Data:");
			int data=r.read();
			System.out.println((char)data);

				while(data!=13){
			 data=r.read();
				System.out.println((char)data);}}	
		 catch (IOException e) {
			System.out.println(" program executed");}
		}}
		


	


