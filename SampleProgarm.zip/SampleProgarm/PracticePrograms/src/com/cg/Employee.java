package com.cg;

public class Employee extends Object{

 private int empid;
 private String depart;

}
