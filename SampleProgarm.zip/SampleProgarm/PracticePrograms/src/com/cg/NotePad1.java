package com.cg;

public interface NotePad1 {
	
	public abstract void Write();
	public abstract void JavaProgram();
	public abstract void SaveAs();
}
