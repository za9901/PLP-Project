package com.cg;

public class OperatingSystem extends SystemUser implements NotePad1, NotePad2
{
	

@Override
public void Write()
{
System.out.println(" write a program");
}
@Override
public void JavaProgram()
{
System.out.println(" language is java ");
}
@Override
public void SaveAs()
{
System.out.println(" after writing save it ");
}
@Override
public void Textfile()
{
	System.out.println(" save it as a Text file");
}
@Override
public void Classfile()
{
	System.out.println(" OR save it as a Class file");
}	
}

