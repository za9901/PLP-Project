package com.cg;

public interface NotePad2 extends NotePad1 {

	public abstract void Textfile();
	public abstract void Classfile();

}
