package com.cg;

public class Manager extends Employee {

}
