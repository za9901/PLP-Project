package com.cg;

public abstract class TestInher {

}
