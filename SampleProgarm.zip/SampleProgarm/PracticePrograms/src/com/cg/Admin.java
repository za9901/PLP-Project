package com.cg;

public class Admin extends Employee {

}
