package com.cg;

public class Engineer extends Employee{

}
