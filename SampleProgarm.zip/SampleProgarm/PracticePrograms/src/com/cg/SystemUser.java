package com.cg;

public class SystemUser {

	public static void main(String[] args) {
		
	NotePad1 np1=null;
	np1=new OperatingSystem();
	np1.Write();
	np1.JavaProgram();
	np1 .SaveAs();
	
	NotePad2 np2=null;
	np2=new OperatingSystem();
	np2.Textfile();
	np2.Classfile();
	
	
	

	}

}
