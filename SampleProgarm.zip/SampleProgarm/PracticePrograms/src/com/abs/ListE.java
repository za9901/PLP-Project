package com.abs;

public class ListE extends EmployeeDetails{

	public static void main(String[] args) {
		

	}

}
