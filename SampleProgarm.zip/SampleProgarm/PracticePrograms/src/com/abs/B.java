package com.abs;

public class B  extends A implements I{

	@Override
	public void ice() {
		System.out.println("hi bro");
	}

	@Override
	public void cream() {
	System.out.println(" hai how r u");
	}

}
