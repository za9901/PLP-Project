package com.abs;

public interface I {

	public void ice();
	public void cream();
	
}
