package com.abs;

public class A {
public static void main(String args[]){
	I g=null;
	g=new B ();
	g.ice();
	g.cream();
}}
