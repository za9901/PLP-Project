class Samp1
{

Samp1()// default constructor// 
{
 system.out.println(" hello");
}

Samp1(int a,int b)// argumented constructor//
{
system.out.println(" how r u");
}
public static void main(string arg[])
{
Samp1 s1=new Samp1();
Samp1 s2=new Samp1(10,20);// passing values to the object//
}


