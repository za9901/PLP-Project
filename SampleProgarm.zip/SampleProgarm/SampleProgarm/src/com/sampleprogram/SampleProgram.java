package com.sampleprogram;


import java.util.Scanner;
public class SampleProgram
{
    public static void main(String args[])
    {
      double number= -5.5;
      
      (number  > 0.0)  ?  "positive"  :  "not positive";
      system.out.println(number +"is " );
      
    }
}
