package com.cg.ac.dao;

import com.cg.ac.bean.Account;
import com.cg.ac.bean.Customer;
import com.cg.ac.exception.AccountException;

public interface AccountDao {
	public String createAccount(Account account,Customer customer)throws AccountException;
	public Account showBalance(String accountNo)throws AccountException;
	public Account deposite(String accountNo, double amount)throws AccountException;
	public Account withDraw(String accountNo, double amount)throws AccountException;
	public Account fundTransfer(String accountNo,String accountNo1, double amount) throws AccountException;

}
