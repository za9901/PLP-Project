package com.cg.tms.service;
import java.util.List;
import java.util.Set;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.ticketexception.TicketException;

public interface TicketService {
	
  int raiseNewTicket(TicketBean t)throws TicketException;
}
