package com.cg.tms.service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDaoImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.ticketexception.TicketException;

public class TicketServiceImpl implements TicketService{
 TicketDAO tdr=null;
	
 private int generateTicketNo(){
		return (int)((Math.random())*10000);
	} 
	


	@Override
	public int raiseNewTicket(TicketBean t) throws TicketException {
		tdr = new TicketDaoImpl();
		t.setTicketNo(generateTicketNo());
		t.setTicketStatus("NEW");
		t.setDate(LocalDateTime.now());
		return tdr.raiseNewTicket(t);
		
	}}


