package com.cg.tms.test;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDaoImpl;
import com.cg.tms.dto.TicketBean;

public class TicketTest {
 
	private static TicketDAO tdr=null;
	@Before
	public void init(){
		tdr=new TicketDaoImpl();
		
	}
	@After
	public void destroy(){
		tdr=null;
	}
 @Test
 public void TestraiseNewTicket(){
	TicketBean  e=new TicketBean("Ticket Raised","LOW");
		e.setTicketPriority("HIGH");
		Assert.assertNotNull(e);
 }
}
