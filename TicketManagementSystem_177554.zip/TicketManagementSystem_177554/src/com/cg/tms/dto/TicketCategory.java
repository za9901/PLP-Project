package com.cg.tms.dto;

public class TicketCategory {

	private String ticketcategoryId;
	private String categoryName;
	public String getTicketcategoryId() {
		return ticketcategoryId;
	}
	public void setTicketcategoryId(String ticketcategoryId) {
		this.ticketcategoryId = ticketcategoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public TicketCategory(String ticketcategoryId, String categoryName) {
		super();
		this.ticketcategoryId = ticketcategoryId;
		this.categoryName = categoryName;
	}
	@Override
	public String toString() {
		return "TicketCategory [ticketcategoryId=" + ticketcategoryId
				+ ", categoryName=" + categoryName + "]";
	}
	
	
	
	
}