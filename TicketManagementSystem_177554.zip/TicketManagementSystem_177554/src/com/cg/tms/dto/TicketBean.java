package com.cg.tms.dto;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class TicketBean {

	private Integer ticketNo;
	private String ticketCategoryId;
	private String ticketDescription;
	private String ticketPriority;
	private String ticketStatus;
	private LocalDateTime date;
	public Integer getTicketNo() {
		return ticketNo;
	}
	public void setTicketNo(Integer ticketNo) {
		this.ticketNo = ticketNo;
	}
	public String getTicketCategoryId() {
		return ticketCategoryId;
	}
	public void setTicketCategoryId(String ticketCategoryId) {
		this.ticketCategoryId = ticketCategoryId;
	}
	public String getTicketDescription() {
		return ticketDescription;
	}
	public void setTicketDescription(String ticketDescription) {
		this.ticketDescription = ticketDescription;
	}
	public String getTicketPriority() {
		return ticketPriority;
	}
	public void setTicketPriority(String ticketPriority) {
		this.ticketPriority = ticketPriority;
	}
	public String getTicketStatus() {
		return ticketStatus;
	}
	public void setTicketStatus(String ticketStatus) {
		this.ticketStatus = ticketStatus;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime localDateTime) {
		this.date = localDateTime;
	}
	public TicketBean(Integer ticketNo, String ticketCategoryId,
			String ticketDescription, String ticketPriority,
			String ticketStatus, LocalDateTime date) {
		super();
		this.ticketNo = ticketNo;
		this.ticketCategoryId = ticketCategoryId;
		this.ticketDescription = ticketDescription;
		this.ticketPriority = ticketPriority;
		this.ticketStatus = ticketStatus;
		this.date = date;
	}
	public TicketBean(String ticketDescription2, String ticketPriority2) {
		this.ticketDescription=ticketDescription;
		this.ticketPriority=ticketPriority;
	}

	@Override
	public String toString() {
		return "TicketBean [ticketNo=" + ticketNo + ", ticketCategoryId="
				+ ticketCategoryId + ", ticketDescription=" + ticketDescription
				+ ", ticketPriority=" + ticketPriority + ", ticketStatus="
				+ ticketStatus + ", date=" + date + "]";
	}
	
	
}
