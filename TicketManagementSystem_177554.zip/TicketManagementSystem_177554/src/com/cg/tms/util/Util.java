package com.cg.tms.util;
import java.util.HashMap;
import java.util.Map;
public class Util {
 
private static Map<String, String> ticketcategory=new HashMap<String,String>();
public static Map<String, String> getTicketCategoryEntries(){
	ticketcategory.put("tc001", "software Installation");
	ticketcategory.put("tc002", "mailbox creation");
	ticketcategory.put("tc003", "mailbox issues");
	return ticketcategory;
}}