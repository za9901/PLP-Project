package com.cg.tms.dao;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.util.Util;
import com.ticketexception.TicketException;

public class TicketDaoImpl<raiseNewTicket> implements TicketDAO{
static Map<Integer, TicketBean> map = new HashMap<Integer, TicketBean>();
	
	@Override
	public int raiseNewTicket(TicketBean t) throws TicketException{
		map.put(t.getTicketNo(), t);
		System.out.println(map);
		return t.getTicketNo();	
	}
       
	@Override
	public Set<TicketCategory> listTicketCategory() throws TicketException {
		 Set<TicketCategory> r=null;
		if(Util.getTicketCategoryEntries()==null||Util.getTicketCategoryEntries().isEmpty()){
			throw new TicketException("NULL Exception");
		}
		else {
		Map<String,String> categorylist= Util.getTicketCategoryEntries();
		Set	s=Util.getTicketCategoryEntries().entrySet();
		r.addAll(s);
		}
		return r;
	}}





	

	

