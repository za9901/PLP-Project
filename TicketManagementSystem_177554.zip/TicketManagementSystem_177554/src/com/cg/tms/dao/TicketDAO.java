package com.cg.tms.dao;
import java.util.List;
import java.util.Set;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.ticketexception.TicketException;

public interface TicketDAO {

	
	Set<TicketCategory> listTicketCategory() throws TicketException;
	int raiseNewTicket(TicketBean t) throws TicketException;

}
