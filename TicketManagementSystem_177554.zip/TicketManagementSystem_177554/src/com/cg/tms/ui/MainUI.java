package com.cg.tms.ui;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;
import com.cg.tms.util.Util;
import com.ticketexception.TicketException;
import java.util.Collection;

/* Stored hardcoded values in the Util class using HashMap
 * Then returned to the TicketDaoImpl 
 * Follwed by to the TicketServiceImpl Layer
 * In the TicketDaoImpl Layer TicketNo is generated Using the Math.Random()method.
 * In the MainUI Layer passsing the constructor of the TicketBean Class
 */
public class MainUI {
	
	static Scanner scan = new Scanner(System.in);
	static String TicketCategory=null;
	static String TicketDescription=null;
	static String  TicketPriority=null;
	static String TicketStatus=null;
	static LocalDate date;
	static TicketService tsr=null;
	static int opt1,opt2;
	static Util util = null;
	static TicketBean b = new TicketBean(TicketCategory, TicketCategory);
	
	public static void main(String[] args)throws TicketException {
		
		do{
		System.out.println("Welcome to ITIMD Help Desk");
		System.out.println();
		System.out.println("Press 1. Raise a Ticket \n 2. Exit from the system");
		opt1=scan.nextInt();
		
		while(!(opt1==1 || opt1==2)){
			System.out.println("Please choose from available");
			opt1=scan.nextInt();
		}
		
		switch(opt1){
		
		case 1:
			int TicketNumber=raiseNewTicket();	
			System.out.println("Ticket Number "+TicketNumber + " logged successfully at " +b.getDate());
		break;
		
			
		}	
		
	}while(opt1!=2);
	}

	private static int raiseNewTicket()  {	
		 tsr= new TicketServiceImpl();
		util = new Util();
		Map<String, String> info = util.getTicketCategoryEntries();
		Collection<String> col = info.values();
		System.out.println("Select Ticket Category from below list");
		int i=0;
		for(String opt:col){
			System.out.println(++i +":" +opt);	
		}
			
		do{
		opt2=scan.nextInt();
		if(opt2==1){
			b.setTicketCategoryId("tc001");	
		}
		else if(opt2==2){
			b.setTicketCategoryId("tc002");
		}
		else if(opt2 == 3){
			b.setTicketCategoryId("tc003");
		}
		
		else{
			System.out.println("Enter from the available");
		}
	}while(!(opt2==1||opt2==2||opt2==3));
		
		System.out.println("Enter Ticket Description");
		TicketDescription=scan.next();
		
		System.out.println("Enter priority");
		TicketPriority = scan.next();
		
		while(!(TicketPriority.equalsIgnoreCase("low")||TicketPriority.equalsIgnoreCase("medium")||TicketPriority.equalsIgnoreCase("high"))){
			System.out.println("Enter only either 'LOW' 'MEDIUM' 'HIGH'");
			TicketPriority = scan.next();
		}
		
		 tsr= new TicketServiceImpl();
	TicketBean r=new TicketBean(TicketDescription,TicketPriority);
		try {
			return tsr.raiseNewTicket(b);
		} catch (TicketException e) {
			System.out.println("hi");
			e.printStackTrace();
		}
		return i;
	}
	
	
	
		
	

	



}
	
		
		