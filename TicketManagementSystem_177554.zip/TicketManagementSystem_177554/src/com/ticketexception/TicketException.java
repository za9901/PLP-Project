package com.ticketexception;

public class TicketException extends Exception {

	public TicketException(String s) {
		super(s);
	}
 
}
