package com.cg.pagebeans;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class RegistrationPageBean {

	WebDriver driver;
	
	@FindBy(how=How.NAME, using="uid")
	@CacheLookup
	private WebElement uid;

	@FindBy(how=How.NAME, using="passid")
	@CacheLookup
	private WebElement passid;
	
	@FindBy(how=How.NAME, using="uname")
	@CacheLookup
	private WebElement uname;
	
	@FindBy(how=How.NAME, using="uadd")
	@CacheLookup
	private WebElement uadd;
	
	@FindBy(how=How.NAME, using="ucountry")
	@CacheLookup
	private WebElement ucountry;
	
	@FindBy(how=How.NAME, using="uzip")
	@CacheLookup
	private WebElement uzip;
	
	@FindBy(how=How.NAME, using="uemail")
	@CacheLookup
	private WebElement uemail;
	
	@FindBy(how=How.NAME, using="umsex")
	@CacheLookup
	private WebElement umsex;

	@FindBy(how=How.NAME, using="ufsex")
	@CacheLookup
	private WebElement ufsex;
	
	@FindBy(how=How.NAME, using="about")
	@CacheLookup
	private WebElement about;

	
	@FindBy(how=How.NAME, using="request")
	@CacheLookup
	private WebElement request;
	
	@FindBy(how=How.NAME, using="reset")
	@CacheLookup
	private WebElement reset;
	
	@FindBy(how=How.NAME, using="text")
	@CacheLookup
	private WebElement text;
	
	

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid.sendKeys(uid);
	}

	public WebElement getPassid() {
		return passid;
	}

	public void setPassid(String passid) {
		this.passid.sendKeys(passid); 
	}

	public WebElement getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname.sendKeys(uname);
	}

	public WebElement getUadd() {
		return uadd;
	}

	public void setUadd(String uadd) {
		this.uadd.sendKeys(uadd);
	}

	public WebElement getUcountry() {
		return ucountry;
	}

	public void setUcountry(String ucountry) {
		Select dropDown=new Select(this.ucountry);
		dropDown.selectByVisibleText(ucountry);
	}

	public WebElement getUzip() {
		return uzip;
	}

	public void setUzip(String uzip) {
		this.uzip.sendKeys(uzip); 
	}

	public WebElement getUemail() {
		return uemail;
	}

	public void setUemail(String uemail) {
		this.uemail.sendKeys(uemail);
	}

	public WebElement getUmsex() {
		return umsex;
	}

	public void setUmsex(String umsex) {
		this.umsex.sendKeys(umsex);
	}

	public WebElement getUfsex() {
		return ufsex;
	}

	public void setUfsex(String ufsex) {
		this.ufsex.sendKeys(ufsex);
	}

	
	public WebElement getRequest() {
		return request;
	}

	public WebElement getReset() {
		return reset;
	}

	public void setRequest() {
		this.request.click();
	}

	public void setReset() {
		this.reset.click();
	}

	public String getText() {
		return text.getText();
	}

	public void setText(WebElement text) {
		this.text = text;
	}
	
	public WebElement getAbout() {
		return about;
	}
	
	public void setAbout(String about) {
		this.about.sendKeys(about);
	}
}
