package com.cg.registration;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.pagebeans.RegistrationPageBean;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class RegistrationStepDefinition {

	WebDriver driver;
	RegistrationPageBean page;
	
	@Given("user is on Registration  form")
	public void user_is_on_Registration_form() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\AngularDemo\\registration\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(
				"file:///C:/AngularDemo/registration/src/test/java/com/cg/htmlpages/RegistrationForm.html");
		driver.manage().window().maximize();
		page = PageFactory.initElements(driver, RegistrationPageBean.class);
	}

	@Then("check the title of the page")
	public void check_the_title_of_the_page() {
		System.out.println("Title of page: " + driver.getTitle());
		assertEquals("RegistrationForm", driver.getTitle());
	}

	@Then("check if text is present")
	public void check_if_text_is_present() {
		System.out.println("Text on the page: " + page.getText());
		assertEquals("Welcome to JobsWorld",page.getText());
	}

	@Given("fill form data exceptUserId")
	public void fill_form_data_exceptUserId() throws InterruptedException {
	   
		page.setUid("");Thread.sleep(500);
		page.setPassid("9");Thread.sleep(500);
		page.setUname("Zabi");Thread.sleep(500);
		page.setUadd("123navalurGATE");Thread.sleep(500);
		page.setUcountry("Australia");Thread.sleep(500);
		page.setUemail("zabiullashariff@gmail.com");Thread.sleep(500);
		page.setUzip("570019");Thread.sleep(500);
		page.setUmsex("Male");Thread.sleep(500);
		page.setUfsex("Female");Thread.sleep(500);
		page.setAbout("Registration for the user ");
	}

	@Given("click on submit")
	public void click_on_submit() throws InterruptedException {
		Thread.sleep(3000);
		page.setRequest();
	}

	@Then("switch to alert and accept it")
	public void switch_to_alert_and_accept_it() throws InterruptedException {
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	}

	@Given("fill form data except UpassId")
	public void fill_form_data_except_UpassId() throws InterruptedException {
		page.setUid("6");Thread.sleep(500);
		page.setPassid("");Thread.sleep(500);
		page.setUname("Zabi");Thread.sleep(500);
		page.setUadd("123navalurGATE");Thread.sleep(500);
		page.setUcountry("Australia");Thread.sleep(500);
		page.setUemail("zabiullashariff@gmail.com");Thread.sleep(500);
		page.setUzip("570019");Thread.sleep(500);
		page.setUmsex("Male");Thread.sleep(500);
		page.setUfsex("Female");Thread.sleep(500);
		page.setAbout("Registration for the user ");
	}

	@Given("fill form data except UserName")
	public void fill_form_data_except_UserName() throws InterruptedException {
		page.setUid("6");Thread.sleep(500);
		page.setPassid("9");Thread.sleep(500);
		page.setUname("");Thread.sleep(500);
		page.setUadd("123navalurGATE");Thread.sleep(500);
		page.setUcountry("Australia");Thread.sleep(500);
		page.setUemail("zabiullashariff@gmail.com");Thread.sleep(500);
		page.setUzip("570019");Thread.sleep(500);
		page.setUmsex("Male");Thread.sleep(500);
		page.setUfsex("Female");Thread.sleep(500);
		page.setAbout("Registration for the user ");
	}

	@Given("fill form data except Address")
	public void fill_form_data_except_Address() throws InterruptedException {
		page.setUid("6");Thread.sleep(500);
		page.setPassid("9");Thread.sleep(500);
		page.setUname("Zabi");Thread.sleep(500);
		page.setUadd("");Thread.sleep(500);
		page.setUcountry("Australia");Thread.sleep(500);
		page.setUemail("zabiullashariff@gmail.com");Thread.sleep(500);
		page.setUzip("570019");Thread.sleep(500);
		page.setUmsex("Male");Thread.sleep(500);
		page.setUfsex("Female");Thread.sleep(500);
		page.setAbout("Registration for the user ");
	}

	@Given("fill form data except Country")
	public void fill_form_data_except_Country() throws InterruptedException {
		page.setUid("6");Thread.sleep(500);
		page.setPassid("9");Thread.sleep(500);
		page.setUname("Zabi");Thread.sleep(500);
		page.setUadd("123navalurGATE");Thread.sleep(500);
		page.setUcountry("");Thread.sleep(500);
		page.setUemail("zabiullashariff@gmail.com");Thread.sleep(500);
		page.setUzip("570019");Thread.sleep(500);
		page.setUmsex("Male");Thread.sleep(500);
		page.setUfsex("Female");Thread.sleep(500);
		page.setAbout("Registration for the user ");
	}

	@Given("fill form data except UZip")
	public void fill_form_data_except_UZip() throws InterruptedException {
		page.setUid("");Thread.sleep(500);
		page.setPassid("9");Thread.sleep(500);
		page.setUname("Zabi");Thread.sleep(500);
		page.setUadd("123navalurGATE");Thread.sleep(500);
		page.setUcountry("Australia");Thread.sleep(500);
		page.setUemail("");Thread.sleep(500);
		page.setUzip("570019");Thread.sleep(500);
		page.setUmsex("Male");Thread.sleep(500);
		page.setUfsex("Female");Thread.sleep(500);
		page.setAbout("Registration for the user ");
	}

	@Given("fill form data except Email")
	public void fill_form_data_except_Email() throws InterruptedException {
		page.setUid("");Thread.sleep(500);
		page.setPassid("9");Thread.sleep(500);
		page.setUname("Zabi");Thread.sleep(500);
		page.setUadd("123navalurGATE");Thread.sleep(500);
		page.setUcountry("Australia");Thread.sleep(500);
		page.setUemail("zabiullashariff@gmail.com");Thread.sleep(500);
		page.setUzip("");Thread.sleep(500);
		page.setUmsex("Male");Thread.sleep(500);
		page.setUfsex("Female");Thread.sleep(500);
		page.setAbout("Registration for the user ");
	}

	@Given("fill form data except UmSex details")
	public void fill_form_data_except_UmSex_details() throws InterruptedException {
		page.setUid("");Thread.sleep(500);
		page.setPassid("9");Thread.sleep(500);
		page.setUname("Zabi");Thread.sleep(500);
		page.setUadd("123navalurGATE");Thread.sleep(500);
		page.setUcountry("Australia");Thread.sleep(500);
		page.setUemail("zabiullashariff@gmail.com");Thread.sleep(500);
		page.setUzip("570019");Thread.sleep(500);
		page.setUmsex("");Thread.sleep(500);
		page.setUfsex("Female");Thread.sleep(500);
		page.setAbout("Registration for the user ");
	}

	@Given("fill form data except UfSex details")
	public void fill_form_data_except_UfSex_details() throws InterruptedException {
		page.setUid("");Thread.sleep(500);
		page.setPassid("9");Thread.sleep(500);
		page.setUname("Zabi");Thread.sleep(500);
		page.setUadd("123navalurGATE");Thread.sleep(500);
		page.setUcountry("Australia");Thread.sleep(500);
		page.setUemail("zabiullashariff@gmail.com");Thread.sleep(500);
		page.setUzip("570019");Thread.sleep(500);
		page.setUmsex("Male");Thread.sleep(500);
		page.setUfsex("");Thread.sleep(500);
		page.setAbout("Registration for the user ");
	}

	@Given("fill form data")
	public void fill_form_data() throws InterruptedException {
		page.setUid("");Thread.sleep(500);
		page.setPassid("9");Thread.sleep(500);
		page.setUname("Zabi");Thread.sleep(500);
		page.setUadd("123navalurGATE");Thread.sleep(500);
		page.setUcountry("Australia");Thread.sleep(500);
		page.setUemail("zabiullashariff@gmail.com");Thread.sleep(500);
		page.setUzip("570019");Thread.sleep(500);
		page.setUmsex("Male");Thread.sleep(500);
		page.setUfsex("Female");Thread.sleep(500);
		page.setAbout("Registration for the user ");
	}
	
	@After
	public void closeDriver() throws InterruptedException {
		Thread.sleep(1000);
		driver.close();
	}



}
