package com.jdbc.bean;



/*---------------------------------BEAN CLASS WITH PARAMETERS DEFINED-------------------------*/
/*------------------------------ALONG WITH GETTERS & SETTERS-----------------------------*/
/*--------------------------------NON-ARGUMENT AND ARGUMENTED CONSTRUCTOR--------------------------*/
/*------------------------------------------ AND TO-STRING METHOD--------------------------------*/
/*----------------------------------This class used for printing transactions------------------------*/



public class TransactionsBean {
	int transactionId;
	int accountNumber;
	int accountBalance;
	String typeOfTransaction;
	int transactionAmount;
	
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(int accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getTypeOfTransaction() {
		return typeOfTransaction;
	}
	public void setTypeOfTransaction(String typeOfTransaction) {
		this.typeOfTransaction = typeOfTransaction;
	}
	public int getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(int transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public TransactionsBean( int accountBalance,
			String typeOfTransaction, int transactionAmount) {
		super();
		
		this.accountBalance = accountBalance;
		this.typeOfTransaction = typeOfTransaction;
		this.transactionAmount = transactionAmount;
	}
	
	public TransactionsBean()
	{
		
	}
	@Override
	public String toString() {
		return "TransactionsBean [transactionId=" + transactionId
				+ ", accountNumber=" + accountNumber + ", accountBalance="
				+ accountBalance + ", typeOfTransaction=" + typeOfTransaction
				+ ", transactionAmount=" + transactionAmount + "]";
	}
	
	

}
