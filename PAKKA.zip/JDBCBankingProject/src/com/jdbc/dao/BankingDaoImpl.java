package com.jdbc.dao;

import com.jdbc.dao.IBankingDao;
import com.jdbc.exception.BankingException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.jdbc.bean.BankingBean;
import com.jdbc.bean.TransactionsBean;

public class BankingDaoImpl implements IBankingDao{

	Connection  conn=null;
	PreparedStatement prst=null;
	Statement stmt=null;
	
	private Connection makeConnection()
	 {
	 try {
	  String url ="jdbc:oracle:thin:@10.219.34.3:1521/orcl";
	  String user ="Trg205";
	  String pass="training205";
	conn = DriverManager.getConnection(url, user, pass);
	  System.out.println("Connected");
	 }
	 
	 catch (SQLException e) {
	  
	  e.printStackTrace();
	 }
	 return conn;
	 }
	
	private void releaseConnection()
	 {
	 try {
	  if(conn!=null)
	  conn.close();
	 }
	 catch(SQLException e)
	 {
	  e.printStackTrace();
	 }
	 }

	@Override
	public int CreateAccount(BankingBean ad,TransactionsBean transaction) throws BankingException {
		if(ad!=null)
		{
			System.out.println("--------");
			System.out.println(ad.getPin());
			System.out.println("--------");
		 conn=makeConnection();
		 String query="insert into Bank (accountNo,username ,mobileNo,panNo,branch,aadharNo,customerName,password,typeOfBank,Pin,accountType,openingBalance,dateOfBirth,emailAdd ) values( ?,?,?,?,?,?,?,?,?,?,?,?,?,? )";
		 String transQuery="insert into transactions (transactionId,accountNumber,accountBalance,typeOfTransaction,transactionAmount) values(?,?,?,?,?)";
		 try {
			 prst = conn.prepareStatement(query);
			 prst.setInt(1,ad.getAccountNo());
			 prst.setString(2, ad.getUsername());
			 prst.setString(3, ad.getMobileNo());
			 prst.setString(4, ad.getPanNo());
			 prst.setString(5, ad.getBranch());
			 prst.setString(6, ad.getAadharNo());
			 prst.setString(7, ad.getCustomerName());
			 prst.setString(8, ad.getPassword());
			 prst.setString(9, ad.getTypeOfBank());
			 prst.setInt(10, ad.getPin());
			 prst.setString(11, ad.getAccountType());
			 prst.setInt(12, ad.getOpeningBalance());
			 prst.setString(13, ad.getDateOfBirth());
			 prst.setString(14, ad.getEmailAdd());
			 
			int insert= prst.executeUpdate();
			System.out.println(insert);
			prst=conn.prepareStatement(transQuery);
			prst.setInt(1,transaction.getTransactionId());
			prst.setInt(2, transaction.getAccountNumber());
			prst.setInt(3, transaction.getAccountBalance());
			prst.setString(4, transaction.getTypeOfTransaction());
			prst.setInt(5, transaction.getTransactionAmount());
			prst.executeUpdate();
			releaseConnection();
			
			return ad.getAccountNo();
		} 
		 catch (SQLException e) {
			
			e.printStackTrace();
			return 0;
		}
		}
		else
		{
			return 0;
		}
		
	}

	@Override
	public int ShowBalance(int AccountNo1) throws BankingException{
		conn=makeConnection();
		String query1="select accountNo from Bank where accountNo="+AccountNo1;
		String query = "select openingBalance from Bank where accountNo="
				+ AccountNo1;

		try {
			stmt = conn.createStatement();
			ResultSet result1 = stmt.executeQuery(query1);

			if(result1.next()) {
				int accNo=result1.getInt("accountNo");
				if(accNo==AccountNo1) {
					
					stmt = conn.createStatement();
					ResultSet result = stmt.executeQuery(query);
					result.next();
			        int openingBalance = result.getInt("openingBalance");
			return openingBalance;
				}
				
				else 
				{
					System.out.println("account number not existed");
					return 0;
				}
			
			}
			else
			{
				System.out.println("account number not existed");
				return 0;
			}

		} catch (SQLException e) {

			throw new BankingException("SHOW BALANCE EXCEPTION");
			
		}

	}

		
	

	@Override
	public int Deposit(int amt, int d,TransactionsBean transaction)throws BankingException {
		conn=makeConnection();
		String query11="select accountNo from Bank where accountNo="+amt;
		String query = "update Bank set openingBalance=openingBalance+" + d
				+ "where accountNo=" + amt;
		String query1 = "select openingBalance from Bank where accountNo="
				+ amt;
		String transQuery="insert into transactions (transactionId,accountNumber,accountBalance,typeOfTransaction,transactionAmount) values(?,?,?,?,?)";
		
		int insert;
		try {
			
			stmt = conn.createStatement();
			ResultSet result1 = stmt.executeQuery(query11);
			
			if(result1.next()) {
				
			
				int accNo=result1.getInt("accountNo");
				if(accNo==amt) {
			
			prst = conn.prepareStatement(query);
			insert = prst.executeUpdate();
			stmt = conn.createStatement();
			ResultSet result = stmt.executeQuery(query1);

			result.next();
			int openingBalance = result.getInt("openingBalance");
            System.out.println("your account has been debited with"+d);
			System.out.println("Your updated balance after depositing money is :"+openingBalance);
			prst=conn.prepareStatement(transQuery);
			prst.setInt(1,transaction.getTransactionId());
			prst.setInt(2, transaction.getAccountNumber());
			prst.setInt(3, openingBalance);
			prst.setString(4, transaction.getTypeOfTransaction());
			prst.setInt(5, transaction.getTransactionAmount());
			prst.executeUpdate();
			releaseConnection();
			return openingBalance;
				}
				
				else
				{
					System.out.println("from account number not existed");
					return 0;
				}
			}
			else
			{
				return 0;
			}
			
		} catch (SQLException e) {

			throw new BankingException("DEPOSIT EXCEPTION");
			
		}
		
	}

	@Override
	public int Withdraw(int amt1, int d11,TransactionsBean transaction) throws BankingException{
		conn=makeConnection();
		String query11="select accountNo from Bank where accountNo="+amt1;
		String query = "update Bank set openingBalance=openingBalance-" + d11
				+ "where accountNo=" + amt1;
		String query1 = "select openingBalance from Bank where accountNo="
				+ amt1;
		String transQuery="insert into transactions (transactionId,accountNumber,accountBalance,typeOfTransaction,transactionAmount) values(?,?,?,?,?)";
		try {
			stmt = conn.createStatement();
			ResultSet result1 = stmt.executeQuery(query11);
			
			if(result1.next()) {
				
			
				int accNo=result1.getInt("accountNo");
				if(accNo==amt1) {
			
			
			prst = conn.prepareStatement(query);
			int insert = prst.executeUpdate();
			stmt = conn.createStatement();
			ResultSet result = stmt.executeQuery(query1);

			result.next();
			int openingBalance = result.getInt("openingBalance");
			 System.out.println("your account has been credited with"+d11);
			System.out.println("Your available  balance after deduction is :"+openingBalance);
			prst=conn.prepareStatement(transQuery);
			prst.setInt(1,transaction.getTransactionId());
			prst.setInt(2, transaction.getAccountNumber());
			prst.setInt(3, openingBalance);
			prst.setString(4, transaction.getTypeOfTransaction());
			prst.setInt(5, transaction.getTransactionAmount());
			prst.executeUpdate();
			releaseConnection();
			return openingBalance;
}
				
				else
				{
					System.out.println("from account number not existed");
					return 0;
				}
			}
			else
			{
				return 0;
			}

		} catch (SQLException e) {

			throw new BankingException("WITHDRAW EXCEPTION");
		}
		
	}

	@Override
	public int FundTransfer(int a1, int a2, int a11,TransactionsBean transaction)throws BankingException {
		conn=makeConnection();
		String query11="select accountNo from Bank where accountNo="+a1;
		String query12="select accountNo from Bank where accountNo="+a2;
		String query = "update Bank set openingBalance=openingBalance-" + a11
				+ "where accountNo=" + a1;
		String query1 = "select openingBalance from Bank where accountNo="
				+ a1;
		

		String queryy = "update Bank set openingBalance=openingBalance+" + a11
				+ " where accountNo=" + a2;
		String query2 = "select openingBalance from Bank where accountNo="
				+ a2;
		String transQuery="insert into transactions (transactionId,accountNumber,accountBalance,typeOfTransaction,transactionAmount) values(?,?,?,?,?)";
		
		try {
			int FaccNo=0;
			int TaccNo=0;
			stmt = conn.createStatement();
			ResultSet result3 = stmt.executeQuery(query11);
			
			if(result3.next()) {
				
				
				 FaccNo=result3.getInt("accountNo");}
			else
			{
				System.out.println("from account number not existed");
				return 0;
			}
			
			ResultSet result2 = stmt.executeQuery(query12);
             if(result2.next()) {
				 TaccNo=result2.getInt("accountNo");}
			else
			{
				System.out.println("to account number not existed");
				return 0;
			}

        if(FaccNo==a1 && TaccNo==a2)
           {
			prst = conn.prepareStatement(query);
			int insert = prst.executeUpdate();
			stmt = conn.createStatement();
			ResultSet result = stmt.executeQuery(query1);

			result.next();
			int openingBalance1 = result.getInt("openingBalance");
			 System.out.println("your account has been credited with"+a11);
			System.out.println("Your available  balance after deduction is :"+openingBalance1);
            System.out.println(openingBalance1);
            prst=conn.prepareStatement(transQuery);
			prst.setInt(1,transaction.getTransactionId());
			prst.setInt(2, transaction.getAccountNumber());
			prst.setInt(3, openingBalance1);
			prst.setString(4, transaction.getTypeOfTransaction());
			prst.setInt(5, transaction.getTransactionAmount());
			prst.executeUpdate();
			
            prst = conn.prepareStatement(queryy);
			insert = prst.executeUpdate();
			stmt = conn.createStatement();
			ResultSet result1 = stmt.executeQuery(query2);

			result1.next();
			int openingBalance2 = result1.getInt("openingBalance");
            System.out.println("your account has been debited with"+a11);
			System.out.println("Your updated balance after depositing money is :"+openingBalance2);
			prst=conn.prepareStatement(transQuery);
			prst.setInt(1,transaction.getTransactionId()+1);
			prst.setInt(2, a2);
			prst.setInt(3,openingBalance2);
			prst.setString(4, transaction.getTypeOfTransaction());
			prst.setInt(5, transaction.getTransactionAmount());
			prst.executeUpdate();
		   releaseConnection();
			return openingBalance2;

           }
		else
		{
			System.out.println("enter proper account numbers");
			return 0;
		}
		} catch (SQLException e) {
   e.printStackTrace();
   return 0;
		}
	}

	@Override
	public void PrintTransactions(int accountNumber)throws BankingException {
		conn=makeConnection();
		String query="select * from transactions where accountNumber="+accountNumber;
		String query1="select accountNo from Bank where accountNo="+accountNumber;
		try {
			stmt=conn.createStatement();
			ResultSet result1 = stmt.executeQuery(query1);
			
			if(result1.next())
			{
				int AcNo = result1.getInt("accountNo");
				if(AcNo==accountNumber)
				{
					stmt = conn.createStatement();
					ResultSet result = stmt.executeQuery(query);

					if(result.next()){ 
						do{System.out.println("TRANSACTION ID = " +result.getInt(1)+","+"ACCOUNT NUMBER = "+result.getInt(2)+","+"ACCOUNT BALANCE = "+result.getInt(3)+","+"TYPE OF TRANSACTION  = "+result.getString(4)+","+"TRANSACTION AMOUNT = "+result.getInt(5));
						}while(result.next());
					}
					else{
						System.out.println("Record Not Found...");
					}
					
				}
				else
				{
					System.out.println("Record Not Found...");
				}
				}
			else
			{
				System.out.println("Record Not Found...");
			}
			releaseConnection();
		}
		catch (SQLException e) {

			e.printStackTrace();
			
			
			
		}

		
	}
							
						
		
		
	}
		
		
	
		
			
		
