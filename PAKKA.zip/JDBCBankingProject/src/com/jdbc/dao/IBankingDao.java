package com.jdbc.dao;

import com.jdbc.bean.BankingBean;
import com.jdbc.bean.TransactionsBean;
import com.jdbc.exception.BankingException;

public interface IBankingDao {


	
	public int ShowBalance(int AccountNo1) throws BankingException;
	
	
	int FundTransfer(int a1, int a2, int a11, TransactionsBean transaction) throws BankingException;
	void PrintTransactions(int accountNumber) throws BankingException;

	int Withdraw(int amt1, int d11, TransactionsBean transaction) throws BankingException;

	int Deposit(int amt, int d, TransactionsBean transaction) throws BankingException;

	int CreateAccount(BankingBean ad, TransactionsBean transaction) throws BankingException;
}