//@Consumes specifies what MIME type a resource accepts from the client. 
//@Produces, however, specifies what MIME type a resources gives to the client. 
//For example, a resource might accept application/json (@Consumes) and return text/plain (@Produces).

package com.demo.controller;

import com.demo.entity.User;
import com.demo.exception.UserNotFoundException;
import com.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	UserService userService;

	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public List<User> getAllUsers() {
		return this.userService.getAllUsers();
	}

	@RequestMapping(value = "/adduser", method = RequestMethod.POST, 
			consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public User addUser(@RequestBody User user) {
		return this.userService.addUser(user);
	}

//	@RequestMapping(value = "/updateuser", method = RequestMethod.PUT, 
//			consumes = MediaType.APPLICATION_JSON_VALUE, 
//			produces = MediaType.APPLICATION_JSON_VALUE)
	@RequestMapping(value = "/update", method = RequestMethod.PUT, 
			consumes = MediaType.APPLICATION_JSON_VALUE, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public User updateUser(@RequestBody User user) {
		return this.userService.updateUser(user);
	}


//Handling Exception
//	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
//	public Optional<User> getUser(@PathVariable int id) throws Exception {
//		Optional<User> user = this.userService.getUserById(id);
//		if(!user.isPresent())
//			throw new Exception("USER with this id does not exist!");
//		//return this.userService.getUserById(id);
//		return user;
//	
//	}
	
//	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="User with this id not present")
//  @ExceptionHandler({Exception.class})
//  public void handleException() {
//      //System.out.println("User with this id not present");
//  }

	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Optional<User> getUser(@PathVariable int id) throws UserNotFoundException{
		Optional<User> user = this.userService.getUserById(id);
		System.out.println(user.isPresent());
		if(!user.isPresent())
			throw new UserNotFoundException("USER with this id does not exist!");
		//return this.userService.getUserById(id);
		return user;
	}

	@RequestMapping(value = "/all", method = RequestMethod.DELETE)
	public void deleteAllUsers() {
		this.userService.deleteAllUsers();
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public void deleteUser(@PathVariable int id) {
		this.userService.deleteUserById(id);
	}

	



}
