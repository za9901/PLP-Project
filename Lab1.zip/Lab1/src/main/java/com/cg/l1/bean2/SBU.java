/**
 * 
 */
package com.cg.l1.bean2;

import java.util.List;

import com.cg.l1.bean1.Employee;

/**
 * @author anraipur
 *
 */
public class SBU {
	private int sbuId;
	private String sbuName;
	private String sbuHead;
	private List<Employee> list;
	
	public int getSbuId() {
		return sbuId;
	}
	public void setSbuId(int sbuId) {
		this.sbuId = sbuId;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public List<Employee> getList() {
		return list;
	}
	public void setList(List<Employee> list) {
		this.list = list;
	}
	@Override
	public String toString() {
		return "SBU [sbuId=" + sbuId + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + ", list=" + list + "]";
	}
	public SBU() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SBU(int sbuId, String sbuName, String sbuHead, List<Employee> list) {
		super();
		this.sbuId = sbuId;
		this.sbuName = sbuName;
		this.sbuHead = sbuHead;
		this.list = list;
	}

	
}
