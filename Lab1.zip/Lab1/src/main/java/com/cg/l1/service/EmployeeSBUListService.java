/**
 * 
 */
package com.cg.l1.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.l1.bean2.SBU;

/**
 * @author anraipur
 *
 */
public class EmployeeSBUListService {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		ApplicationContext context=new ClassPathXmlApplicationContext("Employee.xml");
		SBU sbu=(SBU)context.getBean("sbu");
		System.out.println(sbu);
	}

}
