/**
 * 
 */
package com.cg.l1.bean;

/**
 * @author anraipur
 *
 */
public class Employee {

	private int id;
	private String name;
	double salary ;
	private SBU bu;
	private int age;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public SBU getBu() {
		return bu;
	}
	public void setBu(SBU bu) {
		this.bu = bu;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", bu=" + bu + ", age=" + age + "]";
	}
	public Employee(int id, String name, double salary, SBU bu, int age) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.bu = bu;
		this.age = age;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
