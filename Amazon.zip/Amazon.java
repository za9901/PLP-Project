import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Amazon {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\svikas\\Desktop\\SeleniumWebDriver\\libs\\chromedriver.exe");
		WebDriver webDriver = new ChromeDriver();
		webDriver.get("https://www.amazon.in");
		webDriver.manage().window().maximize();
		String expectedTitle = "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in";
		String actualTitle = webDriver.getTitle();
		if(expectedTitle.equals(actualTitle)) {
			System.out.println("Matching...NO ERROR");	
		}
		else {
			System.out.println("NOT MATCHING");
		}
			webDriver.findElement(By.id("twotabsearchtextbox")).clear();
			webDriver.findElement(By.id("twotabsearchtextbox")).sendKeys("miband3"+Keys.ENTER);
			
			webDriver.findElement(By.xpath(".//*[contains(@class,'s-image')][1]")).click();
			ArrayList<String> tabs2 = new ArrayList<String> (webDriver.getWindowHandles());
			System.out.println(tabs2);
			webDriver.switchTo().window(tabs2.get(1));
//			webDriver.switchTo().window(webDriver.getCurrentUrl());
			System.out.println(webDriver.getCurrentUrl());
			webDriver.findElement(By.xpath(".//*[contains(@id,'add-to-cart-button')]")).click();
//			webDriver.quit();
			
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				
				e.printStackTrace();
			}
		
//			webDriver.close();
				System.out.println("Successful");
				
				System.exit(0);
	}

}
