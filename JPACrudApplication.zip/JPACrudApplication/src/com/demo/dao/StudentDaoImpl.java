package com.demo.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.demo.entity.Student;

public class StudentDaoImpl implements StudentDao{
	
private EntityManager em;
public StudentDaoImpl() {
   em=JPAUtil.getEntityManager();
}
	@Override
	public Student getStudentById(int id) {
		Student student=em.find(Student.class,id);
		return student;
	}

	@Override
	public void addStudent(Student student) {
		em.persist(student);
	}

	@Override
	public void removeStudent(Student student) {
		em.remove(student);
		
	}

	@Override
	public void updateStudent(Student student) {
		
		em.merge(student);
	}

	@Override
	public void commitTransaction() {
		em.getTransaction().commit();
	}

	@Override
	public void beginTransaction() {
		 em.getTransaction().begin();
		
		
	}

}
