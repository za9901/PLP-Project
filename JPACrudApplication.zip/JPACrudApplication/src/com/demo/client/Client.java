package com.demo.client;

import com.demo.entity.Student;
import com.demo.service.StudentService;
import com.demo.service.StudentServiceImpl;

public class Client {

	public static void main(String[] args) {
	StudentService service = new StudentServiceImpl();
		
	Student student = new Student();
		student.setStudentid(107);
		student.setName("Sachi");
		service.addStudent(student);
		System.out.println("Added record");
		
		
		student = service.getStudentById(107);
		System.out.println("ID:"+student.getStudentid());
		System.out.println(" Name:"+student.getName());
//		
//		student.setName("Sachin Tendulkar");
//		service.updateStudent(student);
//		student = service.getStudentById(100);
//		System.out.print("ID:"+student.getStudentid());
//		System.out.println(" Name:"+student.getName());
//		service.removeStudent(student);
//		System.out.println("End of program...");

	}
}
