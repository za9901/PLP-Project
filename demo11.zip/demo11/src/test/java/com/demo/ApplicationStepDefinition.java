package com.demo;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ApplicationStepDefinition {
	
	WebDriver driver;
	
	@Given ("^user is on the registration page$")
	public void user_is_on_the_registration_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\zshariff\\Desktop\\starter\\lib/chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.get("file:///C:/Users/zshariff/Downloads/demo11/htmlpages/registration.html");
	}

	@When("^user enters the details in reg page$")
	public void user_enters_the_details_in_reg_page() throws Throwable {
	    driver.findElement(By.id("txtName")).sendKeys("Mia");
	    driver.findElement(By.id("txtAddress")).sendKeys("10, Chennai");
	    new Select(driver.findElement(By.name("Country"))).selectByVisibleText("Chennai");
	    driver.findElement(By.id("txtZipCode")).sendKeys("603103");
	    driver.findElement(By.id("txtEmail")).sendKeys("mia@gmail.com");
	    driver.findElement(By.id("male")).click();
	    Thread.sleep(5000);
	}

	@When("^click on the submit button$")
	public void click_on_the_submit_button() throws Throwable {
		driver.findElement(By.id("btnSub")).click();
	}
	
	@Then("^user gets redirected to login page and enters the details$")
	public void user_gets_redirected_to_login_page_and_enters_the_details() throws Throwable {
		driver.findElement(By.id("userName")).sendKeys("Mia");
		driver.findElement(By.id("userPwd")).sendKeys("johnny");
		Thread.sleep(5000);
	}

	@Then("^clicks on login button$")
	public void clicks_on_login_button() throws Throwable {
		driver.findElement(By.id("btnLogin")).click();
	}

	@Then("^alert message should be displayed$")
	public void alert_message_should_be_displayed() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String expectedMsg = alert.getText();
		Thread.sleep(3000);
		alert.accept();
		Assert.assertEquals(expectedMsg, "login successfully");
		driver.close();
		System.out.println("Test completed successfully");
	}
}
