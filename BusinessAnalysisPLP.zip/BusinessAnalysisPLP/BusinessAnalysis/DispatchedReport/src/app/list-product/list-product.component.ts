import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import{Router} from '@angular/router';
import{Product} from '../model/products.model';
import {ProductsService} from '../service/products.service';

@Component({
  selector: 'app-list-product',
  templateUrl: './list-product.component.html',
  styleUrls: ['./list-product.component.css']
})
export class ListProductComponent implements OnInit {

 

  products :Product[];
  filteredProducts: Product[];

    _listFilter: string = '';
    get listFilter(): string {
      return this._listFilter;
    }
    set listFilter(value: string) {
      console.log('set listFilter' + this._listFilter);
      this._listFilter = value;
      this.filteredProducts = this.listFilter ? this.performFilter(this.listFilter) : this.products;
    }

    performFilter(filterBy: string): Product[] {
      filterBy = filterBy.toLocaleLowerCase();
      return this.products.filter((product: Product) =>
        product.category.toLocaleLowerCase().indexOf(filterBy) !== -1);
    }
  
   constructor(private proService: ProductsService,private router:Router){}

   ngOnInit() {
    this.proService.getProducts()
    .subscribe((data: Product[]) =>{
      this.products=data;
      this.filteredProducts = this.products;
    });}

    deletePro(product: Product): void{
      this.proService.deleteProducts(product.id)
      .subscribe(data => {
         this.filteredProducts = this.products.filter(pro => pro !== product);
      })
    }
      editPro(product: Product): void {  
        localStorage.removeItem('editProId');  
        localStorage.setItem('editProId', product.id.toString());  
        this.router.navigate(['edit-product']);  
      } 
      
      getPro(pro:Product){
        this.proService.getProductById(pro.id).subscribe((data: Product[]) => { this.filteredProducts=this.products.filter(product=>product==pro) },
        (error) => { console.log("Error occured" + error); alert(error); }); 
         
        
      }

      onSubmit(){
        this.router.navigate(['add-product']);
      }

}


