import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes, RouterModule} from '@angular/router';
import { ListProductComponent } from '../list-product/list-product.component';
import { EditProductComponent } from '../edit-product/edit-product.component';
import { AddProductComponent } from '../add-product/add-product.component';

export const routes: Routes= [
  {path: '', component:ListProductComponent,pathMatch:'full'},
  {path: 'list-product', component:ListProductComponent},
  {path: 'edit-product', component:EditProductComponent},
  {path: 'add-product', component:AddProductComponent},
]

@NgModule({
  imports: [
    CommonModule,RouterModule.forRoot(routes)
  ],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }
