import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup,Validators} from '@angular/forms';
import{Router} from '@angular/router';
import { ProductsService } from '../service/products.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  // proformlabel: string ='Add Product';

  constructor(private formBuilder: FormBuilder, private proService: ProductsService,private router:Router) { }

  addForm: FormGroup;

  ngOnInit() {

    this.addForm=this.formBuilder.group({

      id:[],
      name:['',Validators.required],
      merchant:['',Validators.required],
      dispatched_date:['',Validators.required],
      dispatched_time:['',Validators.required],
      delivery_date:['',Validators.required],
      delivery_time:['',Validators.required],
      category:['',Validators.required],
      shipped:['',Validators.required],
      customer:['',Validators.required],
      customer_mobile:['',[Validators.required,Validators.maxLength(10)]],
      customer_address:['',Validators.required],
      out_for_delivery:['',Validators.required]
      
   });
  }

  onSubmit() {

    console.log('Product details sent to server!');
    this.proService.createUser(this.addForm.value)
     .subscribe(data => {
      alert("Data Saved!");
      this.router.navigate(['list-product']);  
     },
      error => {
       console.log("Error occured " + error);
       alert(error);
  
     });

     
  
   }

   onSubmitss(){
    this.router.navigate(['list-product']);
  }
}



