export class Product{
    id? : number;
    name? : string;
    merchant? : string;
    dispatched_date? : string;
    dispatched_time? : string;
    delivery_date? :  string;
    delivery_time? : string;
    category? : string;
    shipped? : string;
    customer? : string;
    customer_mobile? : string;
    customer_address? : string;
    out_for_delivery? : string;
}