import { Component, OnInit } from '@angular/core';
import{Router} from '@angular/router';
import {FormBuilder,FormGroup,Validators} from '@angular/forms';
import {ProductsService} from '../service/products.service';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, private proService: ProductsService,private router:Router ) { }
  editForm: FormGroup;
  btnvisibility: boolean = true;  
  proformlabel: string = 'Edit Product';  
  proformbtn: string = 'Update';
  ngOnInit() {
    this.editForm = this.formBuilder.group({  
      
      id:[],
      name:['',Validators.required],
      merchant:['',Validators.required],
      dispatched_date:['',Validators.required],
      dispatched_time:['',Validators.required],
      delivery_date:['',Validators.required],
      delivery_time:['',Validators.required],
      category:['',Validators.required],
      shipped:['',Validators.required],
      customer:['',Validators.required],
      customer_mobile:['',[Validators.required,Validators.maxLength(10)]],
      customer_address:['',Validators.required],
      out_for_delivery:['',Validators.required]
    });  

    let proid = localStorage.getItem('editProId');  
    if (+proid > 0) {  
      this.proService.getProductById(+proid).subscribe(data => {  
        this.editForm.patchValue(data);  
      })  
      this.btnvisibility = false;  
      this.proformlabel = 'Edit Product';  
      this.proformbtn = 'Update';  
    }  
  }  
  onUpdate() {  
    console.log('Update fire');  
    this.proService.updateProduct(this.editForm.value).subscribe(data => {  
      alert("Record Updated");
      this.router.navigate(['list-product']);  
    },  
      error => {  
        alert(error);  
      });  

      
}
onSubmitss(){
  this.router.navigate(['list-product']);
}

}


