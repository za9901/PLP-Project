package com.jdbc.dao;

import com.jdbc.bean.BankingBean;
import com.jdbc.bean.TransactionsBean;

public interface IBankingDao {

	int CreateAccount(BankingBean ad);
	
	public int ShowBalance(int AccountNo1);
	int Deposit(int amt, int d);
	int Withdraw(int amt1, int d11);
	int FundTransfer(int a1, int a2, int a11);
}