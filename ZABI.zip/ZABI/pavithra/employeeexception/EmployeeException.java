package com.employeeexception;

public class EmployeeException extends Exception{

	public EmployeeException(String r) {
		super(r);
	}

}
