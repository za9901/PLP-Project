
package com.exceptionui3;
import java.time.LocalDate;
import java.util.Scanner;

import com.employeeexception.EmployeeException;
import com.employeemanagementsystembean.Employee;
import com.employeemanagementsystembean.Trainee;
import com.employeemanagementsystembean.Trainer;
import com.exceptionservice3.ExceptionService3;
import com.exceptionservice3.IExceptionService;
public class ExceptionUi3 {
	static Scanner scan = new Scanner(System.in);
	static IExceptionService iserv=null;
	static boolean res = false;
	static String name1=null;
	static String mob1=null;
    static	String doj=null; 
	static String password=null;
	static String email=null;
	static int salary=0;
	static String designation=null;
	public static void main(String[] args) throws EmployeeException {
		System.out.println("enter any option b/1 to 5");
		System.out.println(" 1.  AddDetails \n 2. DeleteById\n 3.  ViewAllEmployees");
		System.out.println("4. ViewById \n 5. Update ");
		int a=scan.nextInt();
//	   int opt=0;
		
do{ 
	  
		switch (a) {
		case 1:int finalEmployeeId=AddDetails();
		System.out.println("Employee   is  Added");
		System.out.println(" Employee Id   is "+finalEmployeeId);
			break;
			
		case 2:System.out.println(" enter the id to be deleted");
		int id=scan.nextInt();
			DeleteById( id);
			break;

		case 3:ViewAllEmployees();
			break;
			
		case 4:System.out.println(" enter the Id Of employee who's name u need");
         int e=scan.nextInt();
         Employee e1=ViewById(e);
         if(e1!=null){
        	 System.out.println(e1.getEmpName());
        	 System.out.println(e1.getEmployeeId());
         }
         else{
        	 System.out.println(" Enter the proper Id");
         }
			break;
			
		case 5:System.out.println("Enter opt 1 to update name");
		System.out.println("Enter opt 2 to update password");
			int opt3;
			do{
		opt3=scan.nextInt();
		if(opt3 == 1){
			if(updName())
				System.out.println("Employee name has been changed successfully");
			else
				System.out.println("Invalid ID"); 
			break;
			
		}
		else if(opt3 == 2){
			if(updPwd())
			System.out.println("Employee password has been changed successfully");
			else
				System.out.println("Invalid ID"); 
			break;
		}
		
		else
			System.out.println("Enter a proper option");
		}while(opt3>2); 
			break;
		default:
			break;
		}
//		    while(opt==6)
//			opt=scan.nextInt();
//	    System.out.println( "EXIT");
		System.out.println("enter any option b/1 to 5");
		 a=scan.nextInt();
		}while(a>0);}
	
	

	private static Employee ViewById(int e) {
	iserv=new ExceptionService3();
		return iserv.ViewById(e);
	}
	
	private static boolean updName() {
			System.out.println("Enter id of emp whose Password to be changed : ");
			int id = scan.nextInt();
			System.out.println("Enter the new paassword");
			String pass = scan.next();
			return iserv.updatepwd(id, pass);}
			
	private static boolean updPwd() {
			System.out.println("Enter id of emp whose Password to be changed : ");
			int id = scan.nextInt();
			System.out.println("Enter the new paassword");
			String pass = scan.next();
			return iserv.updatepwd(id, pass);}
	
	private static void ViewAllEmployees() {
		iserv=new ExceptionService3();
		iserv.ViewAllEmployees();}
	
	private static void DeleteById(int id) {
		iserv=new ExceptionService3();
		iserv.DeleteById(id);}
	
	private static  int AddDetails( ) throws EmployeeException {String name;
	String mob;
//	System.out.println("enter the name");
//    String name=scan.next();
//	System.out.println("enter the Mob");
	
//	do {
//		try {
//			System.out.println("enter the employee name");
//			name = scan.next();
//			
//			res = iserv.validateName(name);
//			
//		} catch (Exception e) {
//			System.out.println(e.getMessage());
//
//		}
//	} while (!res);

	

	iserv=new ExceptionService3();
	do{
		try{
		System.out.println("Enter  name1 ");
		name1=scan.next();
    boolean	validate=iserv.validatename1(name1);}
		catch(Exception e){
			System.out.println("Name Exception");
		}
	}while(iserv.validatename1(name1)==false);
	
	do{
		System.out.println("Enter  mob1 ");
		mob1=scan.next();
    boolean	validate=iserv.validatemob1(mob1);		
		}while(iserv.validatemob1(mob1)==false);
	
  do{
		System.out.println("Enter  doj ");
		doj=scan.next();
    boolean	validate=iserv.validatedoj(doj);		
		}while(iserv.validatedoj(doj)==false);

  do{
	System.out.println("Enter  password ");
	password=scan.next();
   boolean	validate=iserv.validatepassword(password);		
	}while(iserv.validatepassword(password)==false);
	
  do{
		System.out.println("Enter  designation ");
		designation=scan.next();
  boolean	validate=iserv.validatedesignation(designation);		
		}while(iserv.validatedesignation(designation)==false);
 
  do{
		System.out.println("Enter  salary ");
		 salary=scan.nextInt();
boolean	validate=iserv.validatesalary(salary);		
		}while(iserv.validatesalary(salary)==false);
  
  do{
		System.out.println("Enter  email ");
		email=scan.next();
boolean	validate=iserv.validateemail(email);		
		}while(iserv.validateemail(email)==false);
  
	Employee emp1=new Trainee();
	Employee emp2=new Trainer();
	int aid=iserv.AddDetails(emp1);
	iserv=new ExceptionService3();
	int aid1=iserv.AddDetails(emp2);
	return aid;}}


