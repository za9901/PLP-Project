package com.exceptionservice3;
import java.util.regex.Matcher;

import com.employeeexception.EmployeeException;
import com.employeemanagementsystembean.Employee;

import java.util.regex.Pattern;

import com.exceptiondao3.ExceptionDao3;
import com.exceptiondao3.IExceptionDao;
public class ExceptionService3 implements IExceptionService{
	IExceptionDao idao=null;
	private int generateEmployeeId(){
		int id=0;
		id=(int) (Math.random()*1000000);
		return id;
	}
	@Override
	public int AddDetails(Employee ad) {
		ad.setEmployeeId(generateEmployeeId());
		idao=new ExceptionDao3();
		return idao.AddDetails(ad);	
	}
	@Override
	public void DeleteById(int id) {
		idao=new ExceptionDao3();
		idao.DeleteById(id);
	}
	@Override
	public void ViewAllEmployees() {
		idao=new ExceptionDao3();
		idao.ViewAllEmployees();}
	
	@Override
	public Employee ViewById(int  e) {
		idao=new ExceptionDao3();
		return idao.ViewById(e);}
		
	@Override
		public boolean updatepwd(int id, String pwd) {
			return idao.updatepwd(id, pwd); }
		
	@Override
	public boolean validatename1(String name1) throws EmployeeException{
		Pattern p=Pattern.compile("^[A-Z][a-z]{3,}");
		Matcher m=p.matcher(name1);
		if(m.find()){
			
			return true;
		}
			else {
				throw new EmployeeException(" name error");}}
	
//	public boolean validateName(String name){
//		if(name==null || name.equals(null)){
//			throw new  ArithmeticException("obj is null");
//		}
//		
//		if(!Pattern.compile("^[A-Z][a-z]{3,16}").matcher(name).find()){
//			throw new ArithmeticException("not matching pattern");
//		}
//		
//		return true;
//		
//	}
	@Override
	public boolean validatemob1(String mob1)  {
		Pattern p=Pattern.compile("^[7-9][0-9]{9,}");
		Matcher m=p.matcher(mob1);
		if(m.find()){
			return true;
		}
			else {
			return false;}}
@Override
public boolean validatedoj(String doj) {
	Pattern p=Pattern.compile("^\\d{2}-\\d{2}-\\d{4}$");
	Matcher m=p.matcher(doj);
	if(m.find()){
		return true;
	}
	else
	return false;
} 

@Override
public boolean validatepassword(String password) {
Pattern p=Pattern.compile("^[A-Z][0-9]{6,}");
Matcher m=p.matcher(password);
if(m.find()){
	return true;
}
else
	return false;
}

@Override
public boolean validatedesignation(String designation) {
Pattern p=Pattern.compile("^[A-Z][a-z]{9,}");
Matcher m=p.matcher(designation);
if(m.find()){
	return true;}
else
	return false;
}

@Override
public boolean validatesalary(int salary) {
return (salary>1000);
}

@Override
public boolean validateemail(String email) {
	Pattern p=Pattern.compile("^(.+)@(.+)$");
	Matcher m=p.matcher(email);
	if(m.find()){
		return true;
	}
	else  
	return false;
}
	
}

	
	
	
	
	
	
	
	
	
			
		
	
		
		
	
