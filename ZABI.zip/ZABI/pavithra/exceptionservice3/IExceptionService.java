package com.exceptionservice3;
import com.employeeexception.EmployeeException;
import com.employeemanagementsystembean.Employee;
public interface IExceptionService {
	public int AddDetails(Employee ad);
	public void	DeleteById(int id);
	public void ViewAllEmployees();
	public boolean validatemob1(String mob1) ;
	Employee ViewById(int e);
	boolean updatepwd(int id, String pwd);
	boolean validatename1(String name1) throws EmployeeException;
	public boolean validatedoj(String doj);
	public boolean validatepassword(String password);
	public boolean validatedesignation(String designation);
	public boolean validatesalary(int salary);
	public boolean validateemail(String email);
	
	
}
