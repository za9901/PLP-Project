package com.exceptiondao3;
import com.employeemanagementsystembean.Employee;
public interface IExceptionDao {
	public int AddDetails(Employee ad);
	public void	DeleteById(int id);
	public void ViewAllEmployees();
	public boolean updatepwd(int id, String pwd);
	Employee ViewById(int e);
	

}
