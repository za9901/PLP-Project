package com.exceptiondao3;
import java.util.*;
import com.employeemanagementsystembean.Employee;
public class ExceptionDao3 implements IExceptionDao{
	static  Map<Integer,Employee> accountlist=new HashMap<Integer,Employee>();
	@Override
	public int AddDetails(Employee ad) {
		accountlist.put(ad.getEmployeeId(),ad);
		System.out.println(accountlist);
//		System.out.println( ad.getEmpName());
		return ad.getEmployeeId();	}
	
	@Override
	public void DeleteById(int id) {
		Collection<Employee> e1= accountlist.values();
		accountlist.remove(id);}
	
	@Override
	public void ViewAllEmployees() {
	Collection<Employee> e1= accountlist.values();
	System.out.println(e1);
	for(Employee emp:e1){
		System.out.println(emp.getEmployeeId());}}
	
	@Override
	public Employee ViewById(int e) {
		Employee e2= accountlist.get(e);
		if(e2!=null)
			return e2;
			else 
				return null;}
	@Override
		public boolean updatepwd(int id, String pwd) {
			Employee emp = accountlist.get(id);
			if(emp!=null) {
				emp.setPwd(pwd);
				return true;
			}
			return false;}}
			
		
	 
		
	


