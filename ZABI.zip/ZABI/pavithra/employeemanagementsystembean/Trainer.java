package com.employeemanagementsystembean;

import java.time.LocalDate;

public class Trainer extends Employee{
public Trainer(){
}

public Trainer(String empName, int salary, LocalDate doj, String pwd) {
	this.empName = empName;
	this.salary = salary;
	this.doj = doj;
	this.pwd = pwd;
}
}