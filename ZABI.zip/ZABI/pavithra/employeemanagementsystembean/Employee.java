package com.employeemanagementsystembean;

import java.time.LocalDate;

public abstract class Employee extends Object{
	int EmployeeId;
public String empName;
public 	String mob;
public String getMob() {
	return mob;
}
public void setMob(String mob) {
	this.mob = mob;
}
public int salary;
public LocalDate doj;
public String pwd;



public int getEmployeeId() {
	return EmployeeId;
}
public void setEmployeeId(int employeeId) {
	EmployeeId = employeeId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
public LocalDate getDoj() {
	return doj;
}
public void setDoj(LocalDate doj) {
	this.doj = doj;
}
public String getPwd() {
	return pwd;
}
public void setPwd(String pwd) {
	this.pwd = pwd;
}
  public Employee(){
	  
  }
public Employee(String empName,String mob, int salary, LocalDate doj, String pwd) {
	super();
	this.empName = empName;
	this.salary = salary;
	this.doj = doj;
	this.pwd = pwd;
	this.mob=mob;
}
}
