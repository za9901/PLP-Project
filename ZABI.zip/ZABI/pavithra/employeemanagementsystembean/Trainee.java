package com.employeemanagementsystembean;

import java.time.LocalDate;

public class Trainee extends Employee{
	public Trainee(){
	}

	public Trainee(String empName, int salary, LocalDate doj, String pwd) {
		this.empName = empName;
		this.salary = salary;
		this.doj = doj;
		this.pwd = pwd;
	}
}
