"use strict";
exports.__esModule = true;
var Mobile_1 = require("./Mobile");
var SmartPhone_1 = require("./SmartPhone");
var BasicPhone_1 = require("./BasicPhone");
var mobile = new Mobile_1.Mobile('1234', 'Nokia', '10000');
console.log(mobile.getMobileDetails());
var basicphone = new BasicPhone_1.BasicPhone('0001', 'Samsung', '15000', 'TouchScreen');
console.log(basicphone.toString());
var mobiles = [
    new BasicPhone_1.BasicPhone('0002', 'lenovo', '20000', 'keypad'),
    new BasicPhone_1.BasicPhone('0001', 'Samsung', '15000', 'TouchScreen')
];
console.log(mobiles);
var smartphone = new SmartPhone_1.SmartPhone('0003', 'IOS', '50000', 'MatFinish');
console.log(smartphone.toString());
var mobiles1 = [
    new SmartPhone_1.SmartPhone('0004', 'Lava', '8000', 'Basic'),
    new SmartPhone_1.SmartPhone('0003', 'IOS', '50000', 'MatFinish')
];
console.log(mobiles1);
for (var _i = 0, mobiles1_1 = mobiles1; _i < mobiles1_1.length; _i++) {
    var smartphone_1 = mobiles1_1[_i];
    console.log(smartphone_1.toString());
}
for (var _a = 0, mobiles_1 = mobiles; _a < mobiles_1.length; _a++) {
    var basicphone_1 = mobiles_1[_a];
    console.log(basicphone_1.toString());
}
