export class Mobile{
    MobileId: string;
    MobileName: string;
    MobileCost: string;

    constructor(MId: string,MName: string,MCost: string){
        this.MobileId= MId;
        this.MobileName=MName;
        this.MobileCost=MCost;
    }
    getMobileDetails(){
        return `Mobile Id : ${this.MobileId} Mobile Name : ${this.MobileName} Mobile Cost : ${this.MobileCost}`;
    }
    }
