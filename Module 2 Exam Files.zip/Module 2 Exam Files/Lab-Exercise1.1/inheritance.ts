import  { Mobile } from './Mobile'
import {SmartPhone} from './SmartPhone'
import {BasicPhone} from './BasicPhone'

let mobile=new Mobile('1234','Nokia','10000');
console.log(mobile.getMobileDetails());


let basicphone=new BasicPhone(
    '0001',
    'Samsung',
    '15000',
    'TouchScreen'
);

console.log(basicphone.toString());
let mobiles: BasicPhone[] = [
    new BasicPhone('0002',
        'lenovo',
        '20000',
        'keypad'),
    new BasicPhone(
        '0001',
    'Samsung',
    '15000',
    'TouchScreen'
    )
];

console.log(mobiles);
for (const basicphone of mobiles) {
    console.log(basicphone.toString());
}



let smartphone=new SmartPhone(
    '0003',
    'IOS',
    '50000',
    'MatFinish'
);

console.log(smartphone.toString());
let mobiles1: SmartPhone[] = [
    new SmartPhone('0004',
        'Lava',
        '8000',
        'Basic'),
    new SmartPhone(
        '0003',
        'IOS',
        '50000',
        'MatFinish'
    )
];

console.log(mobiles1);

for (const smartphone of mobiles1) {
    console.log(smartphone.toString());
}



