"use strict";
exports.__esModule = true;
var Mobile = /** @class */ (function () {
    function Mobile(MId, MName, MCost) {
        this.MobileId = MId;
        this.MobileName = MName;
        this.MobileCost = MCost;
    }
    Mobile.prototype.getMobileDetails = function () {
        return "Mobile Id : " + this.MobileId + " Mobile Name : " + this.MobileName + " Mobile Cost : " + this.MobileCost;
    };
    return Mobile;
}());
exports.Mobile = Mobile;
