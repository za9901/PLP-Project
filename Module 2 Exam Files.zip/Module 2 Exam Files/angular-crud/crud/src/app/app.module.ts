import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { ListEmpComponent } from './list-emp/list-emp.component';


@NgModule({
  declarations: [
    AppComponent,
    ListEmpComponent,
   
  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [],                                                                                                                                                                                                                                                                                                                                                                                                                 
  bootstrap: [AppComponent]
})
export class AppModule { }
