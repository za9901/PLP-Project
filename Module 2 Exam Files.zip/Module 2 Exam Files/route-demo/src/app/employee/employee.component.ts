import { Component, OnInit } from '@angular/core';
import { IEmployee } from './employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  employee:IEmployee[]=[
    { eid:1001,ename:'Raushan',esalary:20000},
    { eid:1006,ename:'Raushan',esalary:50000},
    { eid:1003,ename:'Raushan',esalary:20000}
  ];

  constructor() { }

  ngOnInit() {
  }
  delete(emp:IEmployee)
  {
  let arr= this.employee.filter(p=>p.eid != emp.eid);
this.employee=arr;  
}

}
