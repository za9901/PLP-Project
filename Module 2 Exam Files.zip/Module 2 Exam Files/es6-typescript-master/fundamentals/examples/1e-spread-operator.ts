// Spread syntax allows an iterable such as an array expression or string to be expanded in places where zero or more arguments (for function calls) or elements (for array literals) are expected, or an object expression to be expanded in places where zero or more key-value pairs (for object literals) are expected.

//https://www.typescriptlang.org/play/

//SPREAD IN FUNCTION CALLS
function sum(x, y, z) {
  return x + y + z;
}

const numbers = [1, 2, 3];

//spread syntax
console.log(...numbers);
//console.log(sum(...numbers));
// expected output: 6

//javascript syntax
console.log(sum.apply(null, numbers));
// expected output: 6

//SPREAD IN ARRAY LITERALS
// Without spread syntax, to create a new array using an existing array as one part of it
var parts = ['shoulders', 'knees'];
var lyrics = ['head', ...parts, 'and', 'toes',...parts];
// ["head", "shoulders", "knees", "and", "toes"]
console.log(lyrics);

// traditional way to copy arrays
var arr1 = [0, 1, 2];
var arr2 = [3, 4, 5];
// Append all items from arr2 onto arr1
arr1 = arr1.concat(arr2);
console.log(arr1);

//spread syntax
var arr1 = [0, 1, 2];
var arr2 = [3, 4, 55];
arr1 = [...arr1, ...arr2];
console.log(arr1);

//Spread in object literals
var obj1 = { foo: 'bar', x: 42 };
var obj2 = { foo: 'baz', y: 13 };
console.log(obj1, obj2);
var clonedObj = { ...obj1 };
console.log(clonedObj);
// Object { foo: "bar", x: 42 }

var mergedObj = { ...obj1, ...obj2 };
console.log(mergedObj);

// Object { foo: "baz", x: 42, y: 13 }