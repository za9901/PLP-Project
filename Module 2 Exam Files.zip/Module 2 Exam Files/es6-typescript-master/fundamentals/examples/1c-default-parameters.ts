// Default function parameters 
// allow named parameters to be initialized with default values if no value or undefined is passed.

function multiply(a, b = 1) {
    return a * b;
  }
  
  console.log(multiply(5, 2));
  // expected output: 10
  
  console.log(multiply(5));
  // expected output: 5

//   function multiply1(a, b) {
//     return a * b;
//   }
  
//   multiply1(5, 2); // 10
// multiply1(5);    // NaN !
  
// function multiply2(a, b) {
//     b = (typeof b !== 'undefined') ?  b : 1;
//     return a * b;
//   }
  
//   multiply2(5, 2); // 10
//   multiply2(5);    // 5