// An arrow function expression
//is a syntactically compact alternative to a regular function expression
var materials = [
    'Hydrogen',
    'Helium',
    'Lithium',
    'Beryllium'
];
console.log(materials.map(function (material) { return material.length; }));
// expected output: Array [8, 6, 7, 9]
//function expression
//The function keyword can be used to define a function inside an expression.
//You can also define functions using the Function constructor and a function declaration.
var getRectArea = function (width, height) {
    return width * height;
};
console.log(getRectArea(3, 4));
//The Function constructor
//creates a new Function object
var sum = new Function('a', 'b', 'return a + b');
console.log(sum(2, 6));
// expected output: 8
//The function declaration (function statement)
//defines a function with the specified parameters.
function calcRectArea(width, height) {
    return width * height;
}
console.log(calcRectArea(5, 6));
// expected output: 30
