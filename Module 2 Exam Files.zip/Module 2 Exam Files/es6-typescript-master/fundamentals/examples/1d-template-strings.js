//Template literals (Template strings)
//Template literals are string literals allowing embedded expressions. You can use multi-line strings and string interpolation features with them. They were called "template strings" in prior editions of the ES2015 specification.
//Template literals are enclosed by the back-tick (` `)  or grave accent.
// Template literals can contain placeholders. These are indicated by the dollar sign and curly braces (${expression}). The expressions in the placeholders and the text between the back-ticks (` `) get passed to a function.
var __makeTemplateObject = (this && this.__makeTemplateObject) || function (cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};
// SyntaxSection
// `string text`
// `string text line 1
//  string text line 2`
// `string text ${expression} string text`
// tag `string text ${expression} string text`
//Multi-line strings
//normal string
console.log('string text line 1\n' +
    'string text line 2');
//using template literals
console.log("string text line 1\nstring text line 2");
//Expression interpolation
//normal string
var a = 5;
var b = 10;
console.log('Fifteen is ' + (a + b) + ' and\nnot ' + (2 * a + b) + '.');
// "Fifteen is 15 and
// not 20."
//using template literals
var a = 5;
var b = 10;
console.log("Fifteen is " + (a + b) + " and\nnot " + (2 * a + b) + ".");
// "Fifteen is 15 and
// not 20."
//Tagged Templates
// A more advanced form of template literals are tagged templates. Tags allow you to parse template literals with a function. The first argument of a tag function contains an array of string values. The remaining arguments are related to the expressions. In the end, your function can return your manipulated string (or it can return something completely different as described in the next example). The name of the function used for the tag can be whatever you want.
var person = 'Mike';
var age = 28;
function myTag(strings, personExp, ageExp) {
    var str0 = strings[0]; // "That "
    var str1 = strings[1]; // " is a "
    var ageStr;
    if (ageExp > 99) {
        ageStr = 'centenarian';
    }
    else {
        ageStr = 'youngster';
    }
    // We can even return a string built using a template literal
    return "" + str0 + personExp + str1 + ageStr;
}
var output = myTag(__makeTemplateObject(["That ", " is a ", ""], ["That ", " is a ", ""]), person, age);
console.log(output);
// That Mike is a youngster
