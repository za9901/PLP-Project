// The destructuring assignment syntax is a JavaScript expression that makes it possible to unpack values from arrays, or properties from objects, into distinct variables.
var _a, _b;
// Expressions - Destructuring assignment
var a, b, rest;
_a = [10, 20], a = _a[0], b = _a[1];
console.log(a);
// expected output: 10
console.log(b);
// expected output: 20
_b = [10, 20, 30, 40, 50], a = _b[0], b = _b[1], rest = _b.slice(2);
console.log(rest);
// expected output: [30,40,50]
//Basic variable assignment
var foo = ['one', 'two', 'three'];
var one = foo[0], two = foo[1], three = foo[2];
console.log(one); // "one"
console.log(two); // "two"
console.log(three); // "three"
// Object destructuring
// Basic assignment
var o = { p: 42, q: true };
var p = o.p, q = o.q;
console.log(p); // 42
console.log(q); // true
