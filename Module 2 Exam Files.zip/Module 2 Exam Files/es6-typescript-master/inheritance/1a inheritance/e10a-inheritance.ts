import { Employee } from './e10a-Employee';
import { Person } from './e10a-Person';
let person = new Person('Success', 'Failure');
console.log(person.getFullName());
let employee: Employee = new Employee(
  'Stone',
  'Clone',
  '1234',
  'Software Engineer'
);
console.log(employee);
console.log(employee.toString());

let employees: Employee[] = [
    new Employee(
        'Smiling',
        'Snake',
        '5678',
        'Fashion Designer'
    ),
    new Employee(
        'Sun',
        'Song',
        '3489',
        'Trainer'
    )
];

console.log(employees);
employees.forEach(employee => {
   console.log(employee.toString()) 
});

for (const employee of employees) {
    console.log(employee);
}
