"use strict";
exports.__esModule = true;
var e10a_Employee_1 = require("./e10a-Employee");
var e10a_Person_1 = require("./e10a-Person");
var person = new e10a_Person_1.Person('Success', 'Failure');
console.log(person.getFullName());
var employee = new e10a_Employee_1.Employee('Stone', 'Clone', '1234', 'Software Engineer');
console.log(employee);
console.log(employee.toString());
var employees = [
    new e10a_Employee_1.Employee('Smiling', 'Snake', '5678', 'Fashion Designer'),
    new e10a_Employee_1.Employee('Sun', 'Song', '3489', 'Trainer')
];
console.log(employees);
employees.forEach(function (employee) {
    console.log(employee.toString());
});
for (var _i = 0, employees_1 = employees; _i < employees_1.length; _i++) {
    var employee_1 = employees_1[_i];
    console.log(employee_1);
}
