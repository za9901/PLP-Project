let message: string = "hello";
console.log(message);
