import { Employee } from './../Model/employee.model';

import { EmpService } from './../service/emp.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-emp',
  templateUrl: './add-emp.component.html',
  styleUrls: ['./add-emp.component.css']
})
export class AddEmpComponent implements OnInit {

  employees:Employee[];
  myForm:FormGroup;
  constructor(private form:FormBuilder, private empservice:EmpService) { }

  ngOnInit() {
    this.myForm=this.form.group(
      {
        'id':[],
        'employee_name':[],
        'employee_salary':[],
        'employee_age':[]
      }
    )
  }

  onSubmit(myForm:FormGroup){
    this.empservice.createEmp(this.myForm.value).subscribe((data:Employee[])=>{this.employees=data;});
  }

}
