import { HttpClient } from '@angular/common/http';
import { Employee } from './../Model/employee.model';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmpService {

  constructor(private http:HttpClient) { }
  baseUrl:string='http://localhost:3000/employees';
  getEmployee(){
    return this.http.get<Employee[]>(this.baseUrl);
  }

  createEmp(emp:Employee){
    return this.http.post(this.baseUrl,emp);
  }

  deleteEmp(emp:Employee){
    return this.http.delete<Employee[]>(this.baseUrl+'/'+emp.id);
  }

  getEmployeeById(id:number){
    return this.http.get(this.baseUrl+'/'+id);
  }

  updateEmployee(emp:Employee){
    return this.http.put(this.baseUrl+'/'+emp.id,emp);
  }
}
