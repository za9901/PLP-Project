import { AddEmpComponent } from './../add-emp/add-emp.component';
import { Router, Routes, RouterModule } from '@angular/router';
import { NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListEmpComponent } from '../list-emp/list-emp.component';
import { EditEmpComponent } from '../edit-emp/edit-emp.component';

export const routes:Routes=[
  {
    path:'',component:ListEmpComponent,pathMatch:'full'
  },
  {
    path:'list',component:ListEmpComponent
  },
  {
    path:'add', component:AddEmpComponent
  },
  {
    path:'edit', component:EditEmpComponent
  }
]

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports:[RouterModule],
  declarations: []
})
export class EmpRoutingModule { }
