import { EmpService } from './../service/emp.service';
import { Employee } from './../Model/employee.model';
import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-list-emp',
  templateUrl: './list-emp.component.html',
  styleUrls: ['./list-emp.component.css']
})
export class ListEmpComponent implements OnInit {

  employees:Employee[];
  constructor(private empService:EmpService, private routes:Router) { }

  ngOnInit() {
    this.empService.getEmployee().subscribe((data: Employee[]) => { this.employees = data; }, 
    (error) => { console.log("Error occured" + error); alert(error); }); 
  }

  deleteEmp(emp:Employee){
      this.empService.deleteEmp(emp).subscribe((data:Employee[])=>{this.ngOnInit();});
  }

  editEmp(emp:Employee){
    localStorage.setItem('editEmpId',emp.id.toString());
    this.routes.navigate(['edit']);
  }

}
