import { EmpService } from './../service/emp.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Employee } from './../Model/employee.model';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-emp',
  templateUrl: './edit-emp.component.html',
  styleUrls: ['./edit-emp.component.css']
})
export class EditEmpComponent implements OnInit {
  employees:Employee[];
  myForm:FormGroup;
  constructor(private form:FormBuilder, private empservice:EmpService) { }

  ngOnInit() {
    this.myForm=this.form.group(
      {
        'id':[],
        'employee_name':[],
        'employee_salary':[],
        'employee_age':[]
      }
    )

    let empId = localStorage.getItem('editEmpId');
    if(+empId>0){
      this.empservice.getEmployeeById(+empId).subscribe(data=>{this.myForm.patchValue(data);});
    }
  }

  updateEmp(myForm:FormGroup){
    this.empservice.updateEmployee(this.myForm.value).subscribe((data:Employee[])=>{this.employees=data;});
  }

}
