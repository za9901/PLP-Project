import { Component } from '@angular/core';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators
} from '@angular/forms';
import { log } from 'util';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Lab Exercise 1.2';
  myForm: FormGroup;

  constructor(private myFormBuilder: FormBuilder) {}
  ngOnInit(): void {
    this.myForm = this.myFormBuilder.group({
      ID: ['', Validators.required],
      Name: ['', Validators.required],
      Salary: ['',Validators.required],
      Department:['',Validators.required]
    });
  }

  onSubmit(form: FormGroup) {
    console.log('Is the form valid ? ', form.valid);
    console.log('ID is ', form.value.ID);
    console.log('Name is ', form.value.Name);
    console.log('Salary is ', form.value.Salary);
    console.log('Department is ', form.value.Department);
  }
}




