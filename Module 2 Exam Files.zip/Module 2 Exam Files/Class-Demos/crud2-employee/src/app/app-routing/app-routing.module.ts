
import { AddEmpComponent } from './../add-emp/add-emp.component';
import { EditEmpComponent } from './../edit-emp/edit-emp.component';
import { LoginComponent } from './../login/login.component';
import { ListEmpComponent } from './../list-emp/list-emp.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes, RouterModule} from '@angular/router';

export const routes: Routes= [
  {path: '', component:LoginComponent,pathMatch:'full'},
  {path: 'login', component:LoginComponent},
  {path: 'list-emp', component:ListEmpComponent},
  {path: 'edit-emp', component:EditEmpComponent},
  {path: 'add-emp', component:AddEmpComponent},
 
]


@NgModule({
  imports: [
    CommonModule,RouterModule.forRoot(routes)
  ],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }
