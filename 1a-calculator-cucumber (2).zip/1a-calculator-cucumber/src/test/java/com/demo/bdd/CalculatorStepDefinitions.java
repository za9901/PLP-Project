package com.demo.bdd;

import static org.assertj.core.api.Assertions.assertThat;
import com.demo.bdd.calculator.Calculator;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CalculatorStepDefinitions {
	Calculator calculator;
	Integer result;
	
	
	//FEATURE
	@Given("The user has a calculator")
	public void the_user_has_a_calculator() {
	    calculator = new Calculator();
	}
	
	
	//BACKGROUND
	@Before
	@Given("user has a calculator")
	public void user_has_a_calculator() {
	   System.out.println("I Have a Calculator");
	}

	@When("user enters the numbers")
	public void user_enters_the_numbers() {
		  System.out.println("I am entering the required numbers to perform the operations");
	}

	@When("enters type of operation")
	public void enters_type_of_operation() {
		  System.out.println("I am enetring the type of operations to be performed based on the given numbers");
	}

	@After
	@Then("user should get answers")
	public void user_should_get_answers() {
		  System.out.println("Finally, I get the required and expected results");
	}

	
	//SCENARIOS
	@When("User adds {int} and {int}")
	public void user_adds_and(Integer number1, Integer number2) {
	    result = calculator.add(number1, number2);
	}

	@When("User subtracts {int} and {int}")
	public void user_subtracts_and(Integer number1, Integer number2) {
		 result = calculator.subtract(number1, number2);
	   
	}

	@When("User divides {int} and {int}")
	public void user_divides_and(Integer number1, Integer number2) {
		 result = calculator.divide(number1, number2);
	  
	}

	@When("User multiplies {int} and {int}")
	public void user_multiplies_and(Integer number1, Integer number2) {
		 result = calculator.multiply(number1, number2);
	   
	}

//SCENARIO RESULT
	@Then("User should get {int}")
	public void user_should_get(Integer sum) {
	    assertThat(result).isEqualTo(sum);
	}
}
