package com.bankproject.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import com.bankproject.bean.Account;
import com.bankproject.bean.Transaction;

public class BankUtil {
	
	static String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
	static String un="trg226";
	static String pw="training226";
	static Connection conn = null;
	
	public static int createAccount(Account account) {
		int status =0;
		try {
			conn=DriverManager.getConnection(url, un, pw);
			String qry = "INSERT INTO account VALUES(?,?,?,?,?,?,?,?)";
			PreparedStatement pst = conn.prepareStatement(qry);
			pst.setInt(1, account.getAccountId());
			pst.setString(2, account.getAccountHolderName());
			pst.setString(3, account.getMob());
			pst.setString(4, account.getEmail());
			pst.setString(5, account.getPan());
			pst.setString(6, account.getAccountType());
			pst.setFloat(7, account.getBalance());
			pst.setString(8, account.getBranch());
			status = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
		
		
	}
	
	public static int createTransaction(Transaction transaction) {
		int status =0;
		try {
			conn=DriverManager.getConnection(url, un, pw);
			conn.setAutoCommit(false);
			String qry = "INSERT INTO transaction VALUES(?,?,?,?,?)";
			PreparedStatement pst = conn.prepareStatement(qry);
			pst.setInt(1, transaction.getTransactionId());
			pst.setInt(2, transaction.getAccountNo());
			pst.setString(3, transaction.getTypeTransaction());
			pst.setFloat(4, transaction.getAmount());
			pst.setFloat(5, transaction.getBalance());
			status = pst.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				System.out.println("Rolled back");
				e1.printStackTrace();
			}
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
		
	}
	
	public static int createFundTransaction(Transaction transaction, Transaction transaction1) {
		int status =0, status1=0;
		try {
			conn=DriverManager.getConnection(url, un, pw);
			conn.setAutoCommit(false);
			String qry = "INSERT INTO transaction VALUES(?,?,?,?,?)";
			PreparedStatement pst = conn.prepareStatement(qry);
			pst.setInt(1, transaction.getTransactionId());
			pst.setInt(2, transaction.getAccountNo());
			pst.setString(3, transaction.getTypeTransaction());
			pst.setFloat(4, transaction.getAmount());
			pst.setFloat(5, transaction.getBalance());
			status = pst.executeUpdate();
			
			PreparedStatement pst1 = conn.prepareStatement(qry);
			pst1.setInt(1, transaction1.getTransactionId());
			pst1.setInt(2, transaction1.getAccountNo());
			pst1.setString(3, transaction1.getTypeTransaction());
			pst1.setFloat(4, transaction1.getAmount());
			pst1.setFloat(5, transaction1.getBalance());
			status1 = pst.executeUpdate();
			if(status!=status1)
			{
				conn.rollback();
			}
			conn.commit();
		} catch (SQLException e) {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				System.out.println("Rolled back");
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		return status;
		
	}

	public static Account showBalance(int accId) {
		Account account = new Account();
		try {
			conn=DriverManager.getConnection(url, un, pw);
			String qry = "SELECT * FROM Account where accountid="+accId;
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(qry);
			while(rs.next()){
				account.setAccountId(rs.getInt(1));
				account.setAccountHolderName(rs.getString(2));
				account.setMob(rs.getString(3));
				account.setEmail(rs.getString(4));
				account.setPan(rs.getString(5));
				account.setAccountType(rs.getString(6));
				account.setOpeningBalance(rs.getInt(7));
				account.setBranch(rs.getString(8));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return account;
	}
	
	public static Collection<Transaction> getAllTransaction(int accid) {
		ResultSet trans=null;
		Collection<Transaction> transactions = new ArrayList<>();
		try {
			conn=DriverManager.getConnection(url, un, pw);
			String qry = "SELECT * FROM transaction where accountno="+accid ;
			Statement st = conn.createStatement();
			trans = st.executeQuery(qry);
			while (trans.next()) {
				Transaction transaction = new Transaction();
				transaction.setTransactionId(trans.getInt(1));
				transaction.setAccountNo(trans.getInt(2));
				transaction.setTypeTransaction(trans.getString(3));
				transaction.setAmount(trans.getInt(4));
				transaction.setBalance(trans.getInt(5));
				transactions.add(transaction);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return transactions;
	}

	public static Account getAccountById(int accid) {
		ResultSet rs=null;
		Account account = new Account();
		Collection<Transaction> transactions = new ArrayList<>();
		try {
			conn=DriverManager.getConnection(url, un, pw);
			String qry = "SELECT * FROM account where accountid="+accid ;
			Statement st = conn.createStatement();
			rs = st.executeQuery(qry);
			while (rs.next()) {
					account.setAccountId(rs.getInt(1));
					account.setAccountHolderName(rs.getString(2));
					account.setMob(rs.getString(3));
					account.setEmail(rs.getString(4));
					account.setPan(rs.getString(5));
					account.setAccountType(rs.getString(6));
					account.setOpeningBalance(rs.getInt(7));
					account.setBranch(rs.getString(8));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return account;
	}

	public static int updateAccountAmount(long balance, int accid) {
		int rs=0;
		Account account = new Account();
		Collection<Transaction> transactions = new ArrayList<>();
		try {
			conn=DriverManager.getConnection(url, un, pw);
			String qry = "update account set balance="+balance+" where accountid="+accid ;
			Statement st = conn.createStatement();
			rs = st.executeUpdate(qry);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
}
