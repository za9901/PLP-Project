package com.bankproject.bean;

public class Transaction {

	private int transactionId;
	private int accountNo;
	private String typeTransaction;
	private long amount;
	private long balance;
	
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", accountNo="
				+ accountNo + ", typeTransaction=" + typeTransaction
				+ ", transaction amount=" + amount + ", balance=" + balance + "]";
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transaction(int accountNo, String typeTransaction, long amount2,
			long amount3) {
		super();
		this.accountNo = accountNo;
		this.typeTransaction = typeTransaction;
		this.amount = amount2;
		this.balance = amount3;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getTypeTransaction() {
		return typeTransaction;
	}
	public void setTypeTransaction(String typeTransaction) {
		this.typeTransaction = typeTransaction;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	
}
