package com.bankproject.bean;

public class Account {
	int accountId;
	String accountHolderName;
	String mob; 
	String email;
	String pan;
	String accountType;
	long balance;
	String branch;
	
	public Account() {
		// TODO Auto-generated constructor stub
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getMob() {
		return mob;
	}

	public void setMob(String mob) {
		this.mob = mob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public long getBalance() {
		return balance;
	}

	public void setOpeningBalance(long balance) {
		this.balance = balance;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public Account(String accountHolderName, String mob, String email,
			String pan, String accountType, long balance, String branch) {
		this.accountHolderName = accountHolderName;
		this.mob = mob;
		this.email = email;
		this.pan = pan;
		this.accountType = accountType;
		this.balance = balance;
		this.branch = branch;
	}
	
	public String toString(){
		return "Account id: "+accountId+"\nAccount Holder Name: "+accountHolderName+"\nMobile Number: "+mob+"\nEmail: "+email+"\nPan: "+pan+"\nBalance: "+balance+"\nBranch: "+branch;
	}
}

