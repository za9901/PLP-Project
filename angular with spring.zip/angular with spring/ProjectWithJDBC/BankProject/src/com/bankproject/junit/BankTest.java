package com.bankproject.junit;

import junit.framework.Assert;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.bankproject.bean.Account;
import com.bankproject.bean.Transaction;
import com.bankproject.dao.AccountDaoImpl;
import com.bankproject.dao.IAccountDao;
import com.bankproject.exception.BankException;


public class BankTest {

	private static IAccountDao idao=null;
	
	@Before
	public void init(){
		idao=new AccountDaoImpl();
	}
	
	@After
	public void destroy(){
		idao=null;
	}
	
	//create Account
	@Test
	public void createAccount(){
		Account acc = new Account("Chaitra", "7896541230", "chaitra@gmail.com", "ABC7896542", "savings", 5000, "Bangalore");
		acc.setAccountId(1001);
		Transaction transaction = new Transaction(1001, "account creation", 5000, 5000);
		Assert.assertEquals(1001, idao.createAccount(acc,transaction));
	}
	
	//showBalance
	@Test
	public void showBalance(){
		Account acc = new Account("Chaitra", "7896541230", "chaitra@gmail.com", "ABC7896542", "savings", 5000, "Bangalore");
		acc.setAccountId(1001);
		Transaction transaction = new Transaction(1001, "account creation", 5000, 5000);
		idao.createAccount(acc,transaction);
		try {
			Assert.assertEquals(5000, idao.showBalance(1001).getBalance());
		} catch (BankException e) {
			System.out.println(e.getMessage());
		}
	}
	
	//DepositAmount
	@Test
	public void depositAmount(){
		Account acc = new Account("Chaitra", "7896541230", "chaitra@gmail.com", "ABC7896542", "savings", 5000, "Bangalore");
		acc.setAccountId(1001);
		Transaction transaction = new Transaction(1001, "account creation", 5000, 5000);
		idao.createAccount(acc,transaction);
		try {
			Assert.assertEquals(6000, idao.deposit(1001, 1000, transaction).getBalance());
		} catch (BankException e) {
			System.out.println(e.getMessage());
		}
	}
	
	//Withdraw amount
	@Test
	public void withDrawAmount(){
		Account acc = new Account("Chaitra", "7896541230", "chaitra@gmail.com", "ABC7896542", "savings", 5000, "Bangalore");
		acc.setAccountId(1001);
		Transaction transaction = new Transaction(1001, "account creation", 5000, 5000);
		idao.createAccount(acc,transaction);
		try {
			Assert.assertEquals(3000, idao.withDraw(1001, 2000, transaction).getBalance());
		} catch (BankException e) {
			System.out.println(e.getMessage());
		}
	}
	
	//Transfer fund
	@Test
	public void transferFund(){
		Account acc = new Account("Chaitra", "7896541230", "chaitra@gmail.com", "ABC7896542", "savings", 5000, "Bangalore");
		acc.setAccountId(1001);
		Account acc1 = new Account("bharath", "7896541230", "bharath@gmail.com", "ABC7878542", "savings", 6000, "Bangalore");
		acc.setAccountId(1002);
		Transaction transaction = new Transaction(1, "account creation", 5000, 5000);
		Transaction transaction1 = new Transaction(2, "account creation", 6000, 6000);
		idao.createAccount(acc, transaction);
		try {
			Assert.assertEquals(4000, idao.transferFund(1001,1002, 1000, transaction,transaction1).getBalance());
		} catch (BankException e) {
			System.out.println(e.getMessage());
		}
	}

	//Get all transaction
	@Test
	public void getAllTransaction(){
		Account acc = new Account("Chaitra", "7896541230", "chaitra@gmail.com", "ABC7896542", "savings", 5000, "Bangalore");
		acc.setAccountId(1001);
		Transaction transaction = new Transaction(1001, "account creation", 5000, 5000);
		idao.createAccount(acc, transaction);
		try {
			Assert.assertNotNull(idao.getAllTransaction(1001));
		} catch (BankException e) {
			System.out.println(e.getMessage());
		}
	}
}
