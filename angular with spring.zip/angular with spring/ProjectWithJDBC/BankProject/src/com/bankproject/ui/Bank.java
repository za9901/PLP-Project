package com.bankproject.ui;
import java.time.LocalDate;
import java.util.Collection;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.bankproject.bean.Account;
import com.bankproject.bean.Transaction;
import com.bankproject.exception.BankException;
import com.bankproject.service.AccountServiceImpl;
import com.bankproject.service.IAccountService;


public class Bank {

	static Scanner scan = new Scanner(System.in);
	static IAccountService accser = null;
	
	//main method
	public static void main(String[] args) {
		String res="no";
		do{
			try{	
				System.out.println("enter any option b/w 1 to 5");
				System.out.println("1. Create Account \n2. Show Balance\n3. Deposit");
				System.out.println("4. Withdraw\n5. Fund Transfer\n6. Print Transactions");
				switch (Integer.parseInt(scan.next().trim())) {
				case 1:int accountID = createAccount();
					if(accountID>0)
						System.out.println("Account is created with account id "+accountID);
					else
						System.out.println("Account is not created");
					break;
				case 2:Account acc = showBalance();
					System.out.println("The balance of Account "+acc.getAccountId()+" is Rs."+acc.getBalance());
					break;
				case 3:Account acc1 = deposit();
					System.out.println("Amount is deposited to the Account "+acc1.getAccountId());
					System.out.println(acc1);
					break;
				case 4:Account acc2=withDraw();
					System.out.println("Amount is withdraw from the Account "+acc2.getAccountId());
					System.out.println(acc2);
					break;
				case 5:Account acc3=transferFund();
					System.out.println("Amount is transfered as fund from the Account "+acc3.getAccountId());
					System.out.println(acc3);
					break;
				case 6:Collection<Transaction> transaction= getAllTransaction();
					for(Transaction obj:transaction){
						System.out.println(obj);
						System.out.println("-------------------------");
					}
					break;
				default:
					System.out.println("Enter the correct option");
					break;
				}
				System.out.println("Do you want to exit say yes/no");
				res=scan.next();
			}catch(BankException e){
				System.out.println(e.getMessage());
			}catch(InputMismatchException e){
				System.out.println("Wrong input option");
			}
			catch(Exception e){
				System.out.println("Wrong input option");
			}
			
		}while(res.equalsIgnoreCase("no"));

	}
	
	//getting all transaction details
	public static Collection<Transaction> getAllTransaction() throws BankException {
		accser=new AccountServiceImpl();
		System.out.println("Enter the account id:");
		int accid = scan.nextInt();
		return accser.getAllTransaction(accid);
	}

	//transfering fund
	public static Account transferFund() throws BankException {
		accser=new AccountServiceImpl();
		long amount=0;
		System.out.println("Enter the from Account id");
		int fromAccid=scan.nextInt();
		System.out.println("Enter the To Account id");
		int toAccid=scan.nextInt();
		System.out.println("Enter the amount which you want to transfer as fund");
		try{
		amount = Long.parseLong(scan.next().trim());}catch(InputMismatchException e){
			System.out.println("Amount is mimatching");
			amount=0;
		}
		Transaction transaction = new Transaction(fromAccid, "Fund Transfer Withdraw", 0, 0);
		Transaction transaction1 = new Transaction(toAccid, "Fund Got Deposit", 0, 0);
		return accser.transferFund(fromAccid,toAccid,amount,transaction,transaction1);
	}

	//withdrawing amount from account
	public static Account withDraw() throws BankException {
		accser=new AccountServiceImpl();
		System.out.println("Enter the Account id");
		int accid=scan.nextInt();
		long amount=0;
		System.out.println("Enter the amount which you want to withdraw");
		try{
			amount = Long.parseLong(scan.next().trim());}catch(InputMismatchException e){
				System.out.println("Amount is mimatching");
				amount=0;
			}
		Transaction transaction= new Transaction(accid, "Withdraw", 0, 0);
		return accser.withDraw(accid,amount,transaction);
	}

	//depositing amount in account
	public static Account deposit() throws BankException {
		accser=new AccountServiceImpl();
		System.out.println("Enter the Account id");
		int accid=scan.nextInt();
		long amount=0;
		System.out.println("Enter the amount which you want to deposit");
		try{
			amount = Long.parseLong(scan.next().trim());}catch(InputMismatchException e){
				System.out.println("Amount is mismatching");
				amount=0;
			}
		Transaction transaction = new Transaction(accid, "Deposit", 0, 0);
		return accser.deposit(accid,amount,transaction);
	}

	//getting particular account balance
	public static Account showBalance() throws BankException {
		accser= new AccountServiceImpl();
		System.out.println("Enter the Account id");
		int accid=scan.nextInt();
		return accser.showBalance(accid);
	}

	//Create account method
	public static int createAccount() {
		accser=new AccountServiceImpl();
		String name=null, mob=null, email=null, pan=null, accType=null;
		long amount = 0L;
		boolean res=false;
		//getting input from client and validating name
		do{
			try{
				System.out.println("Enter the Account Holder name");
				name = scan.next();
				res=accser.validateName(name);
			}
			catch(BankException e)
			{
				System.out.println(e.getMessage());
			}
		}while(!res);
		
		//getting input from client and validating mobile number
		do{
			try{
				System.out.println("Enter the mobile number which contains ten digits");
				mob = scan.next();
				res= accser.validateMob(mob);
				}
				catch(BankException e)
				{
					res=false;
					System.out.println(e.getMessage());
				}
		}while(!res);
		
		//getting input from client and validating email
		do{
			try{
			System.out.println("Enter the email id");
				email = scan.next();
				res = accser.validateEmail(email);
			} catch (BankException e) {
				res=false;
				System.out.println(e.getMessage());
			}
		}while(!res);
		
		//getting input from client and validating pan number
		do{
			try{
				System.out.println("Enter the Account holder pan number");
				pan = scan.next();
				res=accser.validatePan(pan);
			}catch(BankException e){
				res=false;
				System.out.println(e.getMessage());
			}
		}while(!res);
		
		//getting input from client and validating accountType
		do{
			try{
				System.out.println("Enter the accountType");
				accType = scan.next();
				res=accser.validateAccType(accType);
			}catch(BankException e){
				res=false;
				System.out.println(e.getMessage());
			}
		}while(!res);
		
		//getting input from client and validating amount
		do{
			try{
				System.out.println("Enter the Account opening amount");
				amount = Long.parseLong(scan.next().trim());
				res=accser.validateAmount(amount);
			}catch(BankException e){
				res=false;
				System.out.println(e.getMessage());
			}
			catch (InputMismatchException e) {
				System.out.println("Amount should be present in numbers only");
			}
		}while(!res);
		
		System.out.println("Enter the Account opening Branch");
		String branch = scan.next();
		
		//calling bean
		Account acc = new Account(name, mob, email, pan, accType, amount, branch);
		Transaction transaction = new Transaction(0, "account creation", amount, amount);
		accser =new  AccountServiceImpl();
		//calling service class
		int accid=accser.creatAccount(acc,transaction);
		return accid;
	}

}
