package com.bankproject.service;

import java.util.Collection;

import com.bankproject.bean.Account;
import com.bankproject.bean.Transaction;
import com.bankproject.exception.BankException;

public interface IAccountService {

	boolean validateName(String name) throws BankException;

	boolean validateMob(String mob) throws BankException;

	boolean validateEmail(String email) throws BankException;

	boolean validatePan(String pan) throws BankException;

	boolean validateAccType(String accType) throws BankException;

	boolean validateAmount(long amount) throws BankException;

	Account showBalance(int accid) throws BankException;

	Collection<Transaction> getAllTransaction(int accid) throws BankException;

	int creatAccount(Account acc, Transaction transaction);

	Account deposit(int accid, long amount, Transaction transaction) throws BankException;

	Account withDraw(int accid, long amount, Transaction transaction) throws BankException;

	Account transferFund(int fromAccid, int toAccid, long amount, Transaction transaction, Transaction transaction1)
			throws BankException;

}
