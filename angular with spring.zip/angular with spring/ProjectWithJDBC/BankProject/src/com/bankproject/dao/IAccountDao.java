package com.bankproject.dao;

import java.util.Collection;

import com.bankproject.bean.Account;
import com.bankproject.bean.Transaction;
import com.bankproject.exception.BankException;

public interface IAccountDao {

	Account showBalance(int accid) throws BankException;

	Collection<Transaction> getAllTransaction(int accid) throws BankException;

	int createAccount(Account acc, Transaction transaction);

	Account deposit(int accid, long amount, Transaction transaction) throws BankException;

	Account withDraw(int accid, long amount, Transaction transaction) throws BankException;

	Account transferFund(int fromAccid, int toAccid, long amount, Transaction transaction, Transaction transaction1)
			throws BankException;

}
