package com.bankproject.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import com.bankproject.bean.Account;
import com.bankproject.bean.Transaction;
import com.bankproject.exception.BankException;
import com.bankproject.util.BankUtil;

public class AccountDaoImpl implements IAccountDao {

	// creating an account
	@Override
	public int createAccount(Account acc, Transaction transaction) {
		int accStatus = BankUtil.createAccount(acc);
		int transStatus = BankUtil.createTransaction(transaction);
		if (accStatus == 1) {
			System.out.println("Account is inserted");
		} else {
			System.out.println("Account is not inserted");
		}
		if (transStatus == 1) {
			System.out.println("Transaction is inserted");
		} else {
			System.out.println("Transaction is not inserted");
		}
		return acc.getAccountId();
	}

	// showing paricular account balance
	@Override
	public Account showBalance(int accid) throws BankException {
		Account account = BankUtil.showBalance(accid);
		return account;
	}

	// depositing amount into the particular account
	@Override
	public Account deposit(int accid, long amount, Transaction transaction) throws BankException {
		Account acc = new Account();
		if (BankUtil.getAccountById(accid) == null)
			throw new BankException("Account is not exist in database");
		else if (amount < 0)
			throw new BankException("Amount should be greater than zero");
		else {
			acc = BankUtil.getAccountById(accid);
			long balance = acc.getBalance();
			balance += amount;
			transaction.setBalance(balance);
			transaction.setAmount(amount);
			BankUtil.createTransaction(transaction);
			int result = BankUtil.updateAccountAmount(balance,accid);
			if(result==0) {
				throw new BankException("Balance is not updated");
			}
		}
		return BankUtil.getAccountById(accid);
	}

	// withdrawing amount from the account
	@Override
	public Account withDraw(int accid, long amount, Transaction transaction) throws BankException {
		Account acc = new Account();
		if (amount >= ((BankUtil.getAccountById(accid).getBalance()) - 500))
			throw new BankException("Amount is greater than the balance");
		else if (amount < 0)
			throw new BankException("Amount should be greater than zero");
		else {
			acc = BankUtil.getAccountById(accid);
			long balance = acc.getBalance();
			balance -= amount;
			transaction.setBalance(balance);
			transaction.setAmount(amount);
			BankUtil.createTransaction(transaction);
			int result = BankUtil.updateAccountAmount(balance,accid);
			if(result==0) {
				throw new BankException("Balance is not updated");
			}
		}
		return BankUtil.getAccountById(accid);
	}

	// transfering amount from the account
	@Override
	public Account transferFund(int fromAccid, int toAccid, long amount, Transaction transaction,
			Transaction transaction1) throws BankException {
		Account fromAcc = null;
		Account toAcc = null;
		if (BankUtil.getAccountById(fromAccid) == null || BankUtil.getAccountById(toAccid) == null) {
			throw new BankException("Account is not exist in the Bank ");

		} else if (amount >=  ((BankUtil.getAccountById(fromAccid).getBalance()) - 500))
			throw new BankException("Amount is greater than the balance");
		else if (amount < 0)
			throw new BankException("Amount should be greater than zero");
		else {
			fromAcc = BankUtil.getAccountById(fromAccid);
			toAcc = BankUtil.getAccountById(toAccid);
			long fromBalance = fromAcc.getBalance();
			long toBalance = toAcc.getBalance();
			fromBalance -= amount;
			toBalance += amount;
			fromAcc.setOpeningBalance(fromBalance);
			toAcc.setOpeningBalance(toBalance);
			transaction.setBalance(fromBalance);
			transaction.setAmount(amount);
			transaction1.setBalance(toBalance);
			transaction1.setAmount(amount);
			int result = BankUtil.updateAccountAmount(fromBalance,fromAccid);
			if(result==0) {
				throw new BankException("Balance is not updated");
			}
			result = BankUtil.updateAccountAmount(toBalance,toAccid);
			if(result==0) {
				throw new BankException("Balance is not updated");
			}
			BankUtil.createFundTransaction(transaction, transaction1);
		}
		return  BankUtil.getAccountById(fromAccid);
	}

	// getting all transaction details
	@Override
	public Collection<Transaction> getAllTransaction(int accid) throws BankException {
		if(BankUtil.getAllTransaction(accid).isEmpty() || BankUtil.getAllTransaction(accid)==null) {
			throw new BankException("Transaction is empty");
		}
		return BankUtil.getAllTransaction(accid);
	}

}
