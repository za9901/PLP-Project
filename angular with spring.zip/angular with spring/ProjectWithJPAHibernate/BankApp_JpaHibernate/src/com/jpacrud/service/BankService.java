package com.jpacrud.service;

import java.util.Collection;
import java.util.List;

import com.jpacrud.entity.Account;
import com.jpacrud.entity.Transaction;
import com.jpacrud.exception.BankException;

public interface BankService {

	boolean validateName(String name) throws BankException;

	boolean validateMob(String mob) throws BankException;

	boolean validateEmail(String email) throws BankException;

	boolean validatePan(String pan) throws BankException;

	boolean validateAccType(String accType) throws BankException;

	boolean validateAmount(long amount) throws BankException;

	Account showBalance(int accid) throws BankException;

	List<Transaction> getAllTransaction(int accid) throws BankException;

	int creatAccount(Account acc, Transaction transaction);

	Account deposit(int accid, long amount, Transaction transaction) throws BankException;

	Account withDraw(int accid, long amount, Transaction transaction) throws BankException;

	Account transferFund(int fromAccid, int toAccid, long amount, Transaction transaction, Transaction transaction1)
			throws BankException;
}
