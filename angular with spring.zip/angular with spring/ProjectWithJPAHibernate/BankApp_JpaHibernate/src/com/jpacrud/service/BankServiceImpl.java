package com.jpacrud.service;

import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.jpacrud.dao.BankDao;
import com.jpacrud.dao.BankDaoImpl;
import com.jpacrud.entity.Account;
import com.jpacrud.entity.Transaction;
import com.jpacrud.exception.BankException;

public class BankServiceImpl implements BankService
{
	Matcher m = null;
	private BankDao dao= null;
	
	public BankServiceImpl() {
		dao=new BankDaoImpl();
	}

	//validating Account holder name
		@Override
		public boolean validateName(String name) throws BankException {
			m=Pattern.compile("^[A-Z]([a-z]){3,}$").matcher(name);
			if(!m.find())
				throw new BankException("Name is not matching");
			return true;
		}

		//validating Account holder mobile number
		@Override
		public boolean validateMob(String mob) throws BankException {
			m=Pattern.compile("^[6789]([0-9]){9}$").matcher(mob);
			if(!m.find())
				throw new BankException("This number is not valid");
			return true;
		}

		//validating Account holder email id
		@Override
		public boolean validateEmail(String email) throws BankException {
			m=Pattern.compile("^([a-zA-Z0-9.]){6,}@gmail.com$").matcher(email);
			if(!m.find())
				throw new BankException("This email id is not valid");
			return true;
		}

		//validating Account holder pan number
		@Override
		public boolean validatePan(String pan) throws BankException {
			m=Pattern.compile("^([A-Z0-9]){10}$").matcher(pan);
			if(!m.find())
				throw new BankException("This pan number is not valid");
			return true;
		}

		//validating Account holder accountType
		@Override
		public boolean validateAccType(String accType) throws BankException {
			if(accType.equalsIgnoreCase("savings") || accType.equalsIgnoreCase("current"))
				return true;
			throw new BankException("This pan number is not valid");
		}

		//validating Account holder account balance
		@Override
		public boolean validateAmount(long amount) throws BankException {
			if(amount<500)
				throw new BankException("Amount should be greater than or equal to 500");
			return true;
		}
		
		//creating an account
		@Override
		public int creatAccount(Account acc, Transaction transaction) {
			acc.setAccountId(generateaAccId());
			transaction.setAccountNo(acc.getAccountId());
			transaction.setTransactionId(generateTransactionID());
			dao.beginTransaction();
			int accid=dao.createAccount(acc,transaction);
			dao.commitTransaction();
			return accid;
		}

		private int generateTransactionID() {
			return (int)(Math.random()*1000);
		}

		//generating account id
		private int generateaAccId() {
			// TODO Auto-generated method stub
			return (int)(Math.random()*1000);
		}

		//showing particular account balance
		@Override
		public Account showBalance(int accid) throws BankException {
			dao.beginTransaction();
			Account acc= dao.showBalance(accid);
			dao.commitTransaction();
			return acc;
		}

		//depositing amount to the particular account
		@Override
		public Account deposit(int accid, long amount, Transaction transaction) throws BankException {
			transaction.setTransactionId(generateTransactionID());
			dao.beginTransaction();
			Account account=dao.deposit(accid,amount,transaction);
			dao.commitTransaction();
			return account;
		}

		//withdrawing amount
		@Override
		public Account withDraw(int accid, long amount,Transaction transaction) throws BankException {
			transaction.setTransactionId(generateTransactionID());
			dao.beginTransaction();
			Account account=dao.withDraw(accid,amount,transaction);
			dao.commitTransaction();
			return account;
		}

		//transfering fund
		@Override
		public Account transferFund(int fromAccid, int toAccid, long amount, Transaction transaction,
				Transaction transaction1) throws BankException {
			transaction.setTransactionId(generateTransactionID());
			transaction1.setTransactionId(generateTransactionID());
			dao.beginTransaction();
			Account account=dao.transferFund(fromAccid, toAccid, amount, transaction, transaction1);
			dao.commitTransaction();
			return account;
		}

		//getting all transactions
		@Override
		public List<Transaction> getAllTransaction(int accid) throws BankException {
			dao.beginTransaction();
			List<Transaction> transactions=dao.getAllTransaction(accid);
			dao.commitTransaction();
			return transactions;
		}
}
