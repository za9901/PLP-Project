package com.jpacrud.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="transaction")
public class Transaction {

	@Id
	private int transactionId;
	private int accountNo;
	private String typeTransaction;
	private long trasactionAmount;
	private long balance;
	
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", accountNo="
				+ accountNo + ", typeTransaction=" + typeTransaction
				+ ", transaction amount=" + trasactionAmount + ", balance=" + balance + "]";
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transaction(int accountNo, String typeTransaction, long trasactionAmount,
			long balance) {
		super();
		this.accountNo = accountNo;
		this.typeTransaction = typeTransaction;
		this.trasactionAmount = trasactionAmount;
		this.balance = balance;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getTypeTransaction() {
		return typeTransaction;
	}
	public void setTypeTransaction(String typeTransaction) {
		this.typeTransaction = typeTransaction;
	}
	public long getTrasactionAmount() {
		return trasactionAmount;
	}
	public void setTrasactionAmount(long trasactionAmount) {
		this.trasactionAmount = trasactionAmount;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	
}
