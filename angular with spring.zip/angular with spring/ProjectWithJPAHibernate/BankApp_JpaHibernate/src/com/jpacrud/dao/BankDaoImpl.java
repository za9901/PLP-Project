package com.jpacrud.dao;

import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.rmi.CORBA.StubDelegate;

import com.jpacrud.entity.Account;
import com.jpacrud.entity.Transaction;

public class BankDaoImpl implements BankDao{
	
	private EntityManager entityManager;
	
	public BankDaoImpl() {
		entityManager=JPAUtil.getEntityManager();
	}

	@Override
	public Account showBalance(int id) {
		Account account = entityManager.find(Account.class, id);
		return account;
	}

	@Override
	public int createAccount(Account acc, Transaction transaction) {
		entityManager.persist(acc);
		entityManager.persist(transaction);
		return acc.getAccountId();
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	@Override
	public Account deposit(int accid, long amount, Transaction transaction) {
		Account account = entityManager.find(Account.class, accid);
		account.setOpeningBalance(account.getBalance()+amount);
		transaction.setBalance(account.getBalance());
		transaction.setTrasactionAmount(amount);
		entityManager.merge(account);
		entityManager.persist(transaction);
		return entityManager.find(Account.class, accid);
	}

	@Override
	public Account withDraw(int accid, long amount, Transaction transaction) {
		Account account = entityManager.find(Account.class, accid);
		account.setOpeningBalance(account.getBalance()-amount);
		transaction.setBalance(account.getBalance());
		transaction.setTrasactionAmount(amount);
		entityManager.merge(account);
		entityManager.persist(transaction);
		return entityManager.find(Account.class, accid);
	}

	@Override
	public Account transferFund(int fromAccid, int toAccid, long amount, Transaction transaction,
			Transaction transaction1) {
		Account fromAccount = entityManager.find(Account.class, fromAccid);
		Account toAccount = entityManager.find(Account.class, toAccid);
		fromAccount.setOpeningBalance(fromAccount.getBalance()-amount);
		toAccount.setOpeningBalance(toAccount.getBalance()+amount);
		transaction.setTrasactionAmount(amount);
		transaction.setBalance(fromAccount.getBalance());
		transaction1.setTrasactionAmount(amount);
		transaction1.setBalance(toAccount.getBalance());
		entityManager.merge(fromAccount);
		entityManager.merge(toAccount);
		entityManager.persist(transaction);
		entityManager.persist(transaction1);
		return entityManager.find(Account.class, fromAccid);
	}

	@Override
	public List<Transaction> getAllTransaction(int accid) {
		
//		String hql = "FROM Employee E ORDER BY E.name.lastName";  
//		Query query = session.createQuery(hql);  
//		employeeList = query.list(); 
//		
		String qStr="from Transaction transaction where transaction.accountNo=:accountId";
		Query query = entityManager.createQuery(qStr, Transaction.class);
		query.setParameter("accountId", accid);
		return query.getResultList();
	}

}
