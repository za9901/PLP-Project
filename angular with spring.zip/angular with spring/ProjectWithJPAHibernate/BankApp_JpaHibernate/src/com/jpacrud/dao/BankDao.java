package com.jpacrud.dao;

import java.util.Collection;
import java.util.List;

import com.jpacrud.entity.Account;
import com.jpacrud.entity.Transaction;

public interface BankDao {
	
	public abstract Account showBalance(int id);
	
	public abstract int createAccount(Account acc, Transaction transaction);
	
	public abstract void commitTransaction();
	
	public abstract void beginTransaction();

	public abstract Account deposit(int accid, long amount, Transaction transaction);

	public abstract Account withDraw(int accid, long amount, Transaction transaction);

	public abstract Account transferFund(int fromAccid, int toAccid, long amount, Transaction transaction,
			Transaction transaction1);

	public abstract List<Transaction> getAllTransaction(int accid);

}
