import { CountryService } from '../service/country.service';

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Country } from '../model/country_model';

@Component({
  selector: 'app-country-list',
  templateUrl: './country-list.component.html',
  styleUrls: ['./country-list.component.css']
})
export class CountryListComponent implements OnInit {

  myform: FormGroup;
  constructor(private countryService: CountryService, private formBuilder: FormBuilder, private router:Router) { }
  countries: Country[];

  ngOnInit() {
    this.myform = this.formBuilder.group({
      id: ['', Validators.required],
      countryName: ['', Validators.required],
      population: ['', [Validators.required, Validators.maxLength(5)]]
    })
    this.countryService.getCountry().subscribe((data: Country[]) => { this.countries = data; });

  }

  onSubmit(myform: FormGroup) {
    console.log(myform.value);
    this.countryService.createCountry(this.myform.value).subscribe((data: Country[]) => { this.ngOnInit(); },
    (error) => { console.log("Error occured" + error); alert(error);});
    window.location.reload();
  }

  deleteCountry(myform: FormGroup) {
    console.log(myform.value)
    this.countryService.deleteCountry(myform.value).subscribe((data: Country[]) => { this.ngOnInit(); }
      ,(error) => { console.log("Error occured" + error); alert(error); }
    );
     window.location.reload();
  }

  getCountryById(country: Country) {

    this.countryService.getCountryById(country.id).subscribe((data: Country[]) => { this.countries=this.countries.filter(cou=>cou==country) });
  }

  backMenu(){
    this.ngOnInit();
  }

  editCountry(cou:Country){
    localStorage.removeItem('editCountryId');
    localStorage.setItem('editCountryId',cou.id.toString());
    this.router.navigate(['edit']);
  }

}
