import { CountryService } from '../service/country.service';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Country } from '../model/country_model';

@Component({
  selector: 'app-add-country',
  templateUrl: './add-country.component.html',
  styleUrls: ['./add-country.component.css']
})
export class AddCountryComponent implements OnInit {

  myform: FormGroup;
  constructor(private countryService: CountryService, private formBuilder: FormBuilder) { }
  countries: Country[];

  ngOnInit() {
    this.myform = this.formBuilder.group({
      id: ['', Validators.required],
      countryName: ['', Validators.required],
      population: ['', [Validators.required, Validators.maxLength(7)]]
    })
    this.countryService.getCountry().subscribe((data: Country[]) => { this.countries = data; }, 
    (error) => { console.log("Error occured" + error); alert(error); });

  }

  onSubmit(myform: FormGroup) {
    
    console.log(myform.value);
    this.countryService.createCountry(this.myform.value).subscribe((data: Country[]) => { this.ngOnInit(); },
    (error) => { console.log("Error occured" + error); alert(error);});
    window.location.reload();
  }

}
