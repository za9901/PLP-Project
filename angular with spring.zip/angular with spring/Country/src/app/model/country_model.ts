export class Country {
    id?: number;
    countryName?: string;
    population?: number;
}