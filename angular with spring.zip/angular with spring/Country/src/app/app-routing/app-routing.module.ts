import { AddCountryComponent } from './../add-country/add-country.component';
import { CountryListComponent } from './../country-list/country-list.component';

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { EditcountryComponent } from '../edit-country/edit-country.component';

export const routes:Routes=[
  {
    path:'',component:CountryListComponent, pathMatch:'full'
  },
  {
    path:'list',component:CountryListComponent
  },
  {
    path:'add',component:AddCountryComponent
  },
  {
    path:'edit',component:EditcountryComponent
  }
]


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports:[RouterModule],
  declarations: []
})
export class AppRoutingModule { }
