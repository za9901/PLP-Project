
import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { CountryService } from '../service/country.service';
import { Country } from '../model/country_model';

@Component({
  selector: 'app-edit-country',
  templateUrl: './edit-country.component.html',
  styleUrls: ['./edit-country.component.css']
})
export class EditcountryComponent implements OnInit {

  myform: FormGroup;
  constructor(private countryService: CountryService, private formBuilder: FormBuilder, private router:Router) { }
  countries: Country[];

  ngOnInit() {
    this.myform = this.formBuilder.group({
      id: ['', Validators.required],
      countryName: ['', Validators.required],
      population: ['', [Validators.required, Validators.maxLength(7)]]
    })
   let couid=localStorage.getItem('editCountryId');
   if(+couid>0){
     this.countryService.getCountryById(+couid).subscribe(data=>{this.myform.patchValue(data);});
   }

  }

  update(myform: FormGroup) {
    console.log(myform.value);
    this.countryService.updateCountry(this.myform.value).subscribe((data: Country[]) => { this.ngOnInit(); },
    (error) => { console.log("Error occured" + error); alert(error);});
    this.router.navigate(['list']);
  }

}
