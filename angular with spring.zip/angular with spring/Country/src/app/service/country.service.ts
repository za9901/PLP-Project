import { Country } from './../model/country_model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CountryService {

  baseUrl:string="http://localhost:9999/country/";
  constructor(private http:HttpClient) { }

  getCountry(){
    return this.http.get<Country[]>(this.baseUrl+'all');
  }

  createCountry(country:Country){
    return this.http.post(this.baseUrl+'add',country);
  }

  getCountryById(id:number){
    return this.http.get<Country[]>(this.baseUrl+id);
  }

  updateCountry(country:Country){
    return this.http.put(this.baseUrl+'update/',country);
  }

  
  deleteCountry(country:Country){
    return this.http.delete<Country[]>(this.baseUrl+'delete/'+country);
  }


  
}
