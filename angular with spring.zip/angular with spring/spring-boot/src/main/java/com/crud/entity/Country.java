//Class Name : Entity
//Type : Entity class
//Purpose : To persist country details in the database using JPA with Hibernate implemention.
//Created By : Chaitra
//Creation Date : 20-May-2019
//Modified By : Nil

package com.crud.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//The entity is mapped to Country table.
@Table(name="Country")
public class Country {
	@Column(name="ID")
	//Represents a primary key in the database.
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	//Setting the characteristics of COUNTRYNAME column.
	@Column(name="COUNTRYNAME", nullable=true, length=10)
	private String countryName;
	
	@Column(name="POPULATION", nullable=true, length=10)
	private int population;

	//constructors section
	public Country() {
		super();
	}

	public Country(int id, String countryName, int population) {
		super();
		this.id = id;
		this.countryName = countryName;
		this.population = population;
	}

	//getters and setters.
	public int getId() {
		return id;
	}

	public String getCountryName() {
		return countryName;
	}

	public int getPopulation() {
		return population;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public void setPopulation(int population) {
		this.population = population;
	}

	@Override
	public String toString() {
		return "Country Details : \tId" + id + "\tName :" + countryName + ", population=" + population + "]";
	}

}
