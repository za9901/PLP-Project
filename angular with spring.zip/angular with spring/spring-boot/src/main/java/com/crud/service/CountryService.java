package com.crud.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.dao.CountryDao;
import com.crud.entity.Country;


@Service
public class CountryService {
	
	@Autowired
	CountryDao countryDao;
	
	public List<Country> getAllCountries(){
		return countryDao.findAll();
	}

	public Country addCountry(Country country) {
		return countryDao.save(country);
	}
	
	public Country updateCountry(Country country) {
		return countryDao.save(country);
	}
	
	public Optional<Country> getCountryById(int id) {
		return countryDao.findById(id);
	}
	
	public void deleteCountry(Country country) {
		countryDao.delete(country);
	}
	
	public void deleteAllCountry() {
		countryDao.deleteAll();
	}
}
