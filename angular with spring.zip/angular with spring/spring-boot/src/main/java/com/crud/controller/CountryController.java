package com.crud.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.crud.entity.Country;
import com.crud.service.CountryService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/country")
public class CountryController {

	@Autowired
	CountryService countryService;
	
	@RequestMapping(value="/all", method=RequestMethod.GET)
	public List<Country> getAllCountries(){
		return countryService.getAllCountries();
	}
	
	@RequestMapping(value="/{id}", method=RequestMethod.GET)
	public Optional<Country> getCountryById(@PathVariable int id){
		return countryService.getCountryById(id);
	}
	
	@RequestMapping(value="/add", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	public Country addCountry(@RequestBody Country country){
		return countryService.addCountry(country);
	}
	
	@RequestMapping(value="/update", method=RequestMethod.PUT, consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	public Country updateCountry(@RequestBody Country country){
		return countryService.updateCountry(country);
	}
	
	@RequestMapping(value="/delete", method=RequestMethod.DELETE)
	public void deleteCountry(@RequestBody Country country){
		countryService.deleteCountry(country);
	}
	
	@RequestMapping(value="/all", method=RequestMethod.DELETE)
	public void deleteAllCountry(){
		countryService.deleteAllCountry();
	}
	
	
}
