package com.crud.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Country")
public class Country {
	@Column(name="ID")
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	@Column(name="COUNTRYNAME", nullable=true, length=10)
	private String countryName;
	
	@Column(name="POPULATION", nullable=true, length=10)
	private int population;

	public Country() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Country(int id, String countryName, int population) {
		super();
		this.id = id;
		this.countryName = countryName;
		this.population = population;
	}

	public int getId() {
		return id;
	}

	public String getCountryName() {
		return countryName;
	}

	public int getPopulation() {
		return population;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public void setPopulation(int population) {
		this.population = population;
	}

	@Override
	public String toString() {
		return "Country [id=" + id + ", countryName=" + countryName + ", population=" + population + "]";
	}

	

}
