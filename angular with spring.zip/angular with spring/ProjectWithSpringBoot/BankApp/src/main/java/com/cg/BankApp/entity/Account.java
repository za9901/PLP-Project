package com.cg.BankApp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BankAccount")
public class Account {

	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int accountId;
	
	@Column(name="name")
	private String accountHolderName;
	
	@Column(name="mobile")
	private String mobile; 
	
	@Column(name="email")
	private String email;
	
	@Column(name="pan")
	private String pan;
	
	@Column(name="type")
	private String accountType;
	
	@Column(name="balance")
	private long balance;
	
	@Column(name="branch")
	private String branch;
	
	public Account() {
		// TODO Auto-generated constructor stub
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public long getBalance() {
		return balance;
	}

	public void setOpeningBalance(long balance) {
		this.balance = balance;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public Account(String accountHolderName, String mobile, String email,
			String pan, String accountType, long balance, String branch) {
		this.accountHolderName = accountHolderName;
		this.mobile = mobile;
		this.email = email;
		this.pan = pan;
		this.accountType = accountType;
		this.balance = balance;
		this.branch = branch;
	}
	
	public String toString(){
		return "Account id: "+accountId+"\nAccount Holder Name: "+accountHolderName+"\nMobile Number: "+mobile+"\nEmail: "+email+"\nPan: "+pan+"\nBalance: "+balance+"\nBranch: "+branch;
	}
}
