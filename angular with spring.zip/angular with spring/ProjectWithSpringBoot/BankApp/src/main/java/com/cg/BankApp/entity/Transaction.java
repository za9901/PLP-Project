package com.cg.BankApp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BankTransaction")
public class Transaction {

	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	@Column(name="accountno")
	private int accountNo;
	@Column(name="typeTransaction")
	private String typeTransaction;
	@Column(name="transactionAmount")
	private long transactionAmount;
	@Column(name="balance")
	private long balance;
	
	@Override
	public String toString() {
		return "Transaction [transactionId=" + id + ", accountNo="
				+ accountNo + ", typeTransaction=" + typeTransaction
				+ ", transaction amount=" + transactionAmount + ", balance=" + balance + "]";
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transaction(int accountNo, String typeTransaction, long transactionAmount,
			long balance) {
		super();
		this.accountNo = accountNo;
		this.typeTransaction = typeTransaction;
		this.transactionAmount = transactionAmount;
		this.balance = balance;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getTypeTransaction() {
		return typeTransaction;
	}
	public void setTypeTransaction(String typeTransaction) {
		this.typeTransaction = typeTransaction;
	}
	public long getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(long transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	
}

