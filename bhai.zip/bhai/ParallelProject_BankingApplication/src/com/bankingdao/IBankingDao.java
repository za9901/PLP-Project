package com.bankingdao;

import com.bankingbean.BankingBean;

public interface IBankingDao {

	int CreateAccount(BankingBean ad);
	int CreateAccount1(BankingBean ad);
	public void ShowBalance(int AccountNo1);
	void Deposit(int amt, int d);
	void Withdraw(int amt1, int d1);
	int FundTransfer(int a1, int a2, int a11);

}
