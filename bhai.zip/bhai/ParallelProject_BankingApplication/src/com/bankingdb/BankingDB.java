package com.bankingdb;

public class BankingDB {

}
