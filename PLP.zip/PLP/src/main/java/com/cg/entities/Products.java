package com.cg.entities;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "products")
@SequenceGenerator(name="my_seq",sequenceName="MY_SEQ",initialValue=100, allocationSize=1)
public class Products implements Serializable {

	@Id
	@Column(name = "Pid")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator="my_seq")
	private int Pid;

	@Column(name = "Pname", length = 20)
	private String Pname;

	
	@Column(name = "Pcategory", length = 20)
	private String Pcategory;

	@Column(name = "Disdate")
	private String Disdate;

	@Column(name = "Distime", length = 20)
	private String Distime;
	
	@Column(name = "Exdate", length = 20)
	private String Exdate;

	@Column(name = "Extime", length = 20)
	private String Extime;

	@Column(name = "Order")
	private String order;

	@Column(name = "Shipped", length = 20)
	private String Shipped;
	
	
	@Column(name = "PMerchant", length = 20)
	private String PMerchant;

	@Column(name = "Cname", length = 20)
	private String Cname;

	@Column(name = "Cmob")
	private String Cmob;

	@Column(name = "Cadd", length = 20)
	private String Cadd;
	

	public Products() {
	
	}

	public int getPid() {
		return Pid;
	}


	public void setPid(int pid) {
		Pid = pid;
	}


	public String getPname() {
		return Pname;
	}


	public void setPname(String pname) {
		Pname = pname;
	}


	public String getPcategory() {
		return Pcategory;
	}


	public void setPcategory(String pcategory) {
		Pcategory = pcategory;
	}


	public String getDisdate() {
		return Disdate;
	}


	public void setDisdate(String disdate) {
		Disdate = disdate;
	}


	public String getDistime() {
		return Distime;
	}


	public void setDistime(String distime) {
		Distime = distime;
	}


	public String getExdate() {
		return Exdate;
	}


	public void setExdate(String exdate) {
		Exdate = exdate;
	}


	public String getExtime() {
		return Extime;
	}


	public void setExtime(String extime) {
		Extime = extime;
	}


	public String getOrder() {
		return order;
	}


	public void setOrder(String order) {
		this.order = order;
	}


	public String getShipped() {
		return Shipped;
	}


	public void setShipped(String shipped) {
		Shipped = shipped;
	}


	public String getPMerchant() {
		return PMerchant;
	}


	public void setPMerchant(String pMerchant) {
		PMerchant = pMerchant;
	}


	public String getCname() {
		return Cname;
	}


	public void setCname(String cname) {
		Cname = cname;
	}


	public String getCmob() {
		return Cmob;
	}


	public void setCmob(String cmob) {
		Cmob = cmob;
	}


	public String getCadd() {
		return Cadd;
	}


	public void setCadd(String cadd) {
		Cadd = cadd;
	}

	public Products(int pid, String pname, String pcategory, String disdate, String distime, String exdate,
			String extime, String order, String shipped, String pMerchant, String cname, String cmob, String cadd) {
		super();
		Pid = pid;
		Pname = pname;
		Pcategory = pcategory;
		Disdate = disdate;
		Distime = distime;
		Exdate = exdate;
		Extime = extime;
		this.order = order;
		Shipped = shipped;
		PMerchant = pMerchant;
		Cname = cname;
		Cmob = cmob;
		Cadd = cadd;
	}

	public Products(String pname, String pcategory, String disdate, String distime, String exdate, String extime,
			String order, String shipped, String pMerchant, String cname, String cmob, String cadd) {
		super();
		Pname = pname;
		Pcategory = pcategory;
		Disdate = disdate;
		Distime = distime;
		Exdate = exdate;
		Extime = extime;
		this.order = order;
		Shipped = shipped;
		PMerchant = pMerchant;
		Cname = cname;
		Cmob = cmob;
		Cadd = cadd;
	}

	@Override
	public String toString() {
		return "Employee [Pid=" + Pid + ", Pname=" + Pname + ", Pcategory=" + Pcategory + ", Disdate=" + Disdate
				+ ", Distime=" + Distime + ", Exdate=" + Exdate + ", Extime=" + Extime + ", order=" + order
				+ ", Shipped=" + Shipped + ", PMerchant=" + PMerchant + ", Cname=" + Cname + ", Cmob=" + Cmob
				+ ", Cadd=" + Cadd + "]";
	}


	
}