package com.cg.services;
import java.util.List;

import com.cg.entities.Products;

public interface ProductService {
	
	void save(Products emp);
	void update(Products emp);
	void delete(Integer id);
	List<Products> findAll();
	Products findById(Integer id);

}