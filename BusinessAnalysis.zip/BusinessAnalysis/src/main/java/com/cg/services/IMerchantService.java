package com.cg.services;

public interface IMerchantService {

}
