package com.cg.services;

public interface IProductService {

}
