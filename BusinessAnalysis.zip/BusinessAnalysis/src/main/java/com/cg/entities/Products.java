package com.cg.entities;


import javax.persistence.*;
import java.io.Serializable;


@Entity
@Table(name = "products")
@SequenceGenerator(name="my_seq",sequenceName="MY_SEQ",initialValue=1, allocationSize=1)
public class Products {
 
	@Id
	@Column(name = "Pid")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator="my_seq")
	private int Pid;

	@Column(name = "Pname", length = 20)
	private String Pname;

	public Products(int pid, String pname, String pcategory) {
		super();
		Pid = pid;
		Pname = pname;
		Pcategory = pcategory;
	}


	@Column(name = "Pcategory", length = 20)
	private String Pcategory;

	
	public Products () {
		
	}


	@Override
	public String toString() {
		return "Products [Pid=" + Pid + ", Pname=" + Pname + ", Pcategory=" + Pcategory + "]";
	}


	public int getPid() {
		return Pid;
	}


	public void setPid(int pid) {
		Pid = pid;
	}


	public String getPname() {
		return Pname;
	}


	public void setPname(String pname) {
		Pname = pname;
	}


	public String getPcategory() {
		return Pcategory;
	}


	public void setPcategory(String pcategory) {
		Pcategory = pcategory;
	}
	
	
}
