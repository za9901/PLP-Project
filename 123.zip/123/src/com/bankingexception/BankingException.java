package com.bankingexception;

public class BankingException extends Exception{

	public BankingException(String be) {
		super(be);
	}
}
