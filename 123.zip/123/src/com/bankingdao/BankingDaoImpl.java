package com.bankingdao;

import java.util.*;
import com.bankingbean.BankingBean;
import com.bankingbean.TransactionsBean;


public class BankingDaoImpl implements IBankingDao{

	static  Map<Integer,BankingBean> accountlist=new HashMap<Integer,BankingBean>();
	static Map<Integer, TransactionsBean> transactionlist=new HashMap<Integer, TransactionsBean>();
	@Override
	public int CreateAccount(BankingBean ad, TransactionsBean transaction) {
		accountlist.put(ad.getAccountNo(),ad);
		System.out.println(accountlist);
		transactionlist.put(transaction.getTransactionId(), transaction);
		return ad.getAccountNo();	
		}
	
	@Override
	public int CreateAccount1(BankingBean ad,TransactionsBean transaction) {
		accountlist.put(ad.getPin(),ad);
		System.out.println(accountlist);
		transactionlist.put(transaction.getTransactionId(), transaction);
		return ad.getPin();	
	}
	
	public void ShowBalance(int AccountNo1){
		BankingBean b=accountlist.get(AccountNo1);
		System.out.println(b.getOpeningBalance());
	
}

	@Override
	public void Deposit(int amt, int d, TransactionsBean transaction) {
		BankingBean b=accountlist.get(amt);
	b.setOpeningBalance(b.getOpeningBalance()+d);
	System.out.println(" The amount has been Deposited With "+d);
	 transaction.setAccountBalance(b.getOpeningBalance());
			transactionlist.put(transaction.getTransactionId(), transaction);
			
			 System.out.println(b.getOpeningBalance());
		
	}

	@Override
	public void Withdraw(int amt1, int d11, TransactionsBean transaction) {
		BankingBean b=accountlist.get(amt1);
		if(b.getOpeningBalance()>1000){
		       b.setOpeningBalance(b.getOpeningBalance()-d11);	
		       System.out.println("WithDrawn Successfully:"+b.getOpeningBalance());
		       transaction.setAccountBalance(b.getOpeningBalance());
		       transactionlist.put(transaction.getTransactionId(), transaction);
		       
		}
		else{
			System.out.println("You Balance Is Very Low");
		}
		}

	@Override
	public int FundTransfer(int a1, int a2, int a11,TransactionsBean transaction ) {
		BankingBean b1=accountlist.get(a1);
		BankingBean b2=accountlist.get(a2);
		if(b1!=null&&b2!=null){
			int am=b1.getOpeningBalance()-a11;
			int  amount=b2.getOpeningBalance()+a11;
			b1.setOpeningBalance(am);
			b2.setOpeningBalance(amount);
	System.out.println(" The amount has been transfered from your AccountNo:"+a1);
	System.out.println(" The amount has been transfered To This  AccountNo:"+a2);
	System.out.println("The amount transfered is:"+a11);
	transaction.setAccountBalance(b1.getOpeningBalance());
	transactionlist.put(transaction.getTransactionId(), transaction);
	
	System.out.println(b1.getOpeningBalance());
		}
		
		  return b1.getOpeningBalance(a1);
		}
	
	@Override
	public HashMap<Integer, TransactionsBean> printTransactions() {
		 HashMap<Integer, TransactionsBean> transaction = (HashMap<Integer, TransactionsBean>) transactionlist;
		 
		 return transaction;
		
	}
	}
		
	
