package com.cg.entities;

import javax.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "products")
@SequenceGenerator(name="my_seq",sequenceName="MY_SEQ",initialValue=1, allocationSize=1)
public class Product  {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator="my_seq")
	private int id;

	@Column(name = "name", length = 20)
	private String name;

	@Column(name = "merchant", length = 20)
	private String merchant;
	
	@Column(name = "dispatched_date", length = 20)
	private String dispatched_date;
	
	@Column(name = "dispatched_time", length = 20)
	private String dispatched_time;
	
	@Column(name = "delivery_date", length = 20)
	private String delivery_date;
	
	@Column(name = "delivery_time", length = 20)
	private String delivery_time;
	
	@Column(name = "category", length = 20)
	private String category;
	
	@Column(name = "shipped", length = 20)
	private String shipped;
	
	@Column(name = "customer", length = 20)
	private String customer;
	
	@Column(name = "customer_mobile", length = 20)
	private String customer_mobile;
	
	@Column(name = "customer_address", length = 20)
	private String customer_address;
	
	@Column(name = "out_for_delivery", length = 20)
	private String out_for_delivery;
	
	public String getMerchant() {
		return merchant;
	}

	public void setMerchant(String merchant) {
		this.merchant = merchant;
	}

	public String getDispatched_date() {
		return dispatched_date;
	}

	public void setDispatched_date(String dispatched_date) {
		this.dispatched_date = dispatched_date;
	}

	public String getDispatched_time() {
		return dispatched_time;
	}

	public void setDispatched_time(String dispatched_time) {
		this.dispatched_time = dispatched_time;
	}

	public String getDelivery_date() {
		return delivery_date;
	}

	public void setDelivery_date(String delivery_date) {
		this.delivery_date = delivery_date;
	}

	public String getDelivery_time() {
		return delivery_time;
	}

	public void setDelivery_time(String delivery_time) {
		this.delivery_time = delivery_time;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getShipped() {
		return shipped;
	}

	public void setShipped(String shipped) {
		this.shipped = shipped;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getCustomer_mobile() {
		return customer_mobile;
	}

	public void setCustomer_mobile(String customer_mobile) {
		this.customer_mobile = customer_mobile;
	}

	public String getCustomer_address() {
		return customer_address;
	}

	public void setCustomer_address(String customer_address) {
		this.customer_address = customer_address;
	}

	public String getOut_for_delivery() {
		return out_for_delivery;
	}

	public void setOut_for_delivery(String out_for_delivery) {
		this.out_for_delivery = out_for_delivery;
	}

	

	public Product() {
		super();
	}

	public Product(String name, String merchant,
			String dispatched_date, String dispatched_time, String delivery_date, String delivery_time, String category,
			String shipped, String customer, String customer_mobile, String customer_address, String out_for_delivery) {
		super();
		this.name = name;
		this.merchant = merchant;
		this.dispatched_date = dispatched_date;
		this.dispatched_time = dispatched_time;
		this.delivery_date = delivery_date;
		this.delivery_time = delivery_time;
		this.category = category;
		this.shipped = shipped;
		this.customer = customer;
		this.customer_mobile = customer_mobile;
		this.customer_address = customer_address;
		this.out_for_delivery = out_for_delivery;
	}

	public int getid() {
		return id;
	}

	public void setid(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", merchant=" + merchant + ", dispatched_date="
				+ dispatched_date + ", dispatched_time=" + dispatched_time + ", delivery_date=" + delivery_date
				+ ", delivery_time=" + delivery_time + ", category=" + category + ", shipped=" + shipped + ", customer="
				+ customer + ", customer_mobile=" + customer_mobile + ", customer_address=" + customer_address
				+ ", out_for_delivery=" + out_for_delivery + "]";
	}

	
	

	
	
	
}