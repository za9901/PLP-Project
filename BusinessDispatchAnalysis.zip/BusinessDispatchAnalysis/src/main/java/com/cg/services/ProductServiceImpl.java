package com.cg.services;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ProductDao;
import com.cg.entities.Product;
import com.cg.exceptions.ApplicationException;

@Service
public class ProductServiceImpl 
	implements ProductService {

	@Autowired private ProductDao dao;

	@Override
	public void save(Product emp) {
		// TODO Auto-generated method stub
		System.out.println("Saving PRODUCT: "+emp.getid());
		if(dao.existsById(emp.getid())) {
			throw new ApplicationException("Record already exists!");
		}
		dao.save(emp);
		
	}

	@Override
	public void update(Product emp) {
		// TODO Auto-generated method stub
		System.out.println("Updating PRODUCT: "+emp.getid());
		if(! dao.existsById(emp.getid())) {
			throw new ApplicationException("Record did not exists!"); 
		}
		dao.save(emp);
		
	}

	@Override
	public void delete(Integer id) {
		// TODO Auto-generated method stub
		System.out.println("Deleting PRODUCT: "+id);
		if(!dao.existsById(id)) {
			throw new ApplicationException("Unable to delete, record not found!");
		}
		dao.deleteById(id);
		
	}

	@Override
	public List<Product> findAll(String name) {
		List<Product> products=dao.findAll();
		List<Product> product= new ArrayList<>();
		for(Product prod:products) {
			System.out.println(prod.getName());
			if(prod.getCategory().equals(name)) {
				System.out.println(prod.getName());
				product.add(prod);
			}
		}
		return product;
	}

	@Override
	public Product findById(Integer id) {
		// TODO Auto-generated method stub
		System.out.println("Finding PRODUCT: "+id);
		Optional<Product> temp = dao.findById(id);
		if(!temp.isPresent()) {
			throw new ApplicationException("Unable to find product "+id);
		}
		return temp.get();
	}

	@Override
	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}
	
	
}
