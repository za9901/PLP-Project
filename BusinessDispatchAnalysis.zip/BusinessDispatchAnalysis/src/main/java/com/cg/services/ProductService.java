package com.cg.services;
import java.util.List;
import com.cg.entities.Product;

public interface ProductService {
	
	void save(Product emp);
	void update(Product emp);
	void delete(Integer id);
	List<Product> findAll(String name);
	Product findById(Integer id);
	List<Product> findAll();
	

}