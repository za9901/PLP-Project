package com.bridgelabz.fundooNotes;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.bridgelabz.fundooNotes.note.dto.NoteDto;
import com.bridgelabz.fundooNotes.response.ResponseToken;
import com.bridgelabz.fundooNotes.user.dto.LoginDto;
import com.bridgelabz.fundooNotes.user.dto.UserDto;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class FundooNotesApplicationTests {

	@Autowired
	private WebApplicationContext webapp;

	private MockMvc mockMvc;

	private Logger log = LoggerFactory.getLogger(FundooNotesApplicationTests.class);

	private static String token;

	public static String asJsonString(final Object obj) {
		try {
			return new ObjectMapper().writeValueAsString(obj);
			
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public static ResponseToken asJavaObject(String data) {
		
		try {
			return new ObjectMapper().readValue(data,ResponseToken.class);
		} catch (IOException e) {

			e.printStackTrace();
			return null;
		}
	}
	
	@Before
	public void getMockMvcInstance() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webapp).build();
	}

//	@Test
//	public void userRegisterTest() {
//		//MvcResult mvcResult = this.mockMvc.perform(post("/user/register").contentType(MediaType.APPLICATION_JSON).content(new UserDto("fundoo","test", "phulsundarsushant26@gmail.com", "9966670662", "123456")))
////		MvcResult mvcResult = this.mockMvc.perform( MockMvcRequestBuilders
////				.post("/user/register")
////				.content(asJsonString(new UserDto("fundoo","test", "phulsundarsushant26@gmail.com", "9966670662", "123456")))
//		
//		try {
//			MvcResult mvcResult = this.mockMvc
//					.perform(post("/user/register")
//							.contentType("application/json;charset=UTF-8")
//							.content("{\"firstName\":\"Spring\",\"lastName\":\"Testing\",\"emailid\":\"venakattestmail@gmail.com\",\"phoneno\":\"9966670662\",\"password\":\"123456\"}"))
//							.andDo(print())
//							.andExpect(status().isOk()).andReturn();
//			log.info(mvcResult.toString());
//			//Status status = new ObjectMapper().readValue(mvcResult.getResponse().getContentAsString(), Status.class);
//		} catch (Exception e) {
//			log.info(e.getMessage());
//		}
//	}
	
	@Test
	public void registerTest() {
		try {
			log.info("inside registration test");
			mockMvc.perform(MockMvcRequestBuilders.post("/user/register")
					.content(asJsonString(
							new UserDto("venkat", "reddy", "venakattestmail@gmail.com", "9966670662", "123456")))
					.contentType(MediaType.APPLICATION_JSON)
					.accept(MediaType.APPLICATION_JSON))
					.andDo(print())
					.andExpect(status().isOk())
					.andReturn();
		} catch (Exception e) {

			log.error("exception occured in registration test------>"+e.getMessage());
			e.getMessage();
		}
	}
	
	@Test
	@Before
	public void loginTest() {
		try {
			log.info("inside login test case");
			MvcResult mvcResult = 	mockMvc.perform(MockMvcRequestBuilders.post("/user/login")
					.content(asJsonString(new LoginDto("venky70662@gmail.com","12345")))
					.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
					.andDo(print())
					.andExpect(status().isOk())
					.andReturn();
			String data = mvcResult.getResponse().getContentAsString();
			
			ResponseToken token = asJavaObject(data);
			this.token = token.getToken();
			System.err.println(this.token);
		} catch (Exception e) {
			log.error("exception occured in login test ------->"+e.getMessage());
			e.getMessage();
		}
	}
	
//	@Test
//	public void forgotPasswordTest() {
//		log.info("inside forgotpasword test case");
//		try {
//			mockMvc.perform(MockMvcRequestBuilders.post("/user/forgetpassword?emailid=venky70662@gmail.com")
//					.contentType(MediaType.APPLICATION_JSON)
//					.accept(MediaType.APPLICATION_JSON))
//					.andDo(print())
//					.andExpect(status().isOk())
//					.andReturn();
//		} catch (Exception e) {
//			log.error("exception in forgot password test--------->"+e.getMessage());
//			e.getMessage();
//		}
//	}
	
//	@Test
//	public void restPassswordTest() {
//		log.info("inside rest password test");
//		try {
//			mockMvc.perform(MockMvcRequestBuilders.put("/user/resetPassword/"+token+"?password=12345")
//				   .contentType(MediaType.APPLICATION_JSON)
//				   .accept(MediaType.APPLICATION_JSON))
//				   .andDo(print()).andExpect(status().isOk())
//				   .andReturn();
//		} catch (Exception e) {
//			log.error("exception in reset password test---------->"+e.getMessage());
//			e.getMessage();
//		}
//	}
	
//	@Test
//	public void validateEmailTest() {
//		log.info("inside rest validate email test");
//		try {
//			mockMvc.perform(MockMvcRequestBuilders.put("/user/validEmail/"+token)
//				   .contentType(MediaType.APPLICATION_JSON)
//				   .accept(MediaType.APPLICATION_JSON))
//				   .andDo(print()).andExpect(status().isOk())
//				   .andReturn();
//		} catch (Exception e) {
//			log.error("exception in validate email test---------->"+e.getMessage());
//			e.getMessage();
//		}
//	}
	
	@Test
	public void getAllUsers() {
		log.info("inside getallusers validate email test");
		try {
			mockMvc.perform(MockMvcRequestBuilders.get("/user/getall")
				   .contentType(MediaType.APPLICATION_JSON)
				   .accept(MediaType.APPLICATION_JSON))
				   .andDo(print()).andExpect(status().isOk())
				   .andReturn();
		} catch (Exception e) {
			log.error("exception in validate email test---------->"+e.getMessage());
			e.getMessage();
		}
	}
	
//	@Test
//	public void createNoteTest() {
//		
//		log.info("inside createnote test");
//		try {
//			mockMvc.perform(MockMvcRequestBuilders.post("/note/create")
//					.header("token",token)
//					.content(asJsonString(new NoteDto("test case","test case",null)))
//				   .contentType(MediaType.APPLICATION_JSON)
//				   .accept(MediaType.APPLICATION_JSON))
//				   .andDo(print()).andExpect(status().isOk())
//				   .andReturn();
//		} catch (Exception e) {
//			log.error("exception in createnote test---------->"+e.getMessage());
//			e.getMessage();
//		}
//		
//	}
	
	@Test
	public void updateNoteTest() {
		
		log.info("inside update note test");
		try {
			mockMvc.perform(MockMvcRequestBuilders.put("/note/update?noteId=28")
					.header("token",token)
					.content(asJsonString(new NoteDto("test case updated","test case updated",null)))
				   .contentType(MediaType.APPLICATION_JSON)
				   .accept(MediaType.APPLICATION_JSON))
				   .andDo(print())
				   .andExpect(status().isOk())
				   .andReturn();
		} catch (Exception e) {
			log.error("exception in update note  test---------->"+e.getMessage());
			e.getMessage();
		}	
	}

	@Test
	public void trashNoteTest() {
		
		log.info("inside trash note test");
		try {
			mockMvc.perform(MockMvcRequestBuilders.delete("/note/trash?noteId=28")
					.header("token",token)
				   .contentType(MediaType.APPLICATION_JSON)
				   .accept(MediaType.APPLICATION_JSON))
				   .andDo(print()).andExpect(status().isOk())
				   .andReturn();
		} catch (Exception e) {
			log.error("exception in trash note  test---------->"+e.getMessage());
			e.getMessage();
		}	
	}
	
	
	
	
	
	
	
	
	
	
}
