package com.bridgelabz.fundooNotes.search;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetRequest;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.bridgelabz.fundooNotes.note.model.Note;
import com.bridgelabz.fundooNotes.user.repository.UserRepository;
import com.bridgelabz.fundooNotes.utility.TokenUtil;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@Service
public class ElasticSearchServiceImpl implements ElasticSearchService
{

	Logger log=LoggerFactory.getLogger(ElasticSearchServiceImpl.class);
	String INDEX="fundoonotes";
	String TYPE="notes";
	
	@Autowired
	private RestHighLevelClient client;

	@Autowired
    private ObjectMapper objectMapper;
	
	@Autowired
	private UserRepository userRepository;

	@Override
    @SuppressWarnings("unchecked")
	public String createNote(Note note) throws IOException
	{
			Map<String, Object> documentMapper = objectMapper.convertValue(note, Map.class);
	        IndexRequest indexRequest = new IndexRequest(INDEX, TYPE, String.valueOf(note.getNoteId())).source(documentMapper);
	        System.out.println(documentMapper.isEmpty());
	        System.out.println(indexRequest);
	        IndexResponse indexResponse = client.index(indexRequest, RequestOptions.DEFAULT);

	        return indexResponse.getResult().name();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public String UpdateNote(Long noteid, Note note) {
		 try {
						
			 UpdateRequest updateRequest = new UpdateRequest( INDEX, TYPE,noteid+"");
			 Map<String, Object> documentMapper = objectMapper.convertValue(note, Map.class);
			 updateRequest.doc(documentMapper);
			 
			 UpdateResponse updateResponse = client.update(updateRequest, RequestOptions.DEFAULT);
			        return updateResponse.getResult().name();
		} catch (IOException e) {
						e.printStackTrace();
		}
				return "fail";
	}

	@Override
	public Note findById(String id) throws IOException
	{
		GetRequest getRequest = new GetRequest(INDEX, TYPE, id);

        GetResponse getResponse = client.get(getRequest, RequestOptions.DEFAULT);
        
        Map<String, Object> resultMap = getResponse.getSource();

        return objectMapper.convertValue(resultMap, Note.class);

	}

	@Override
	public List<Note> findAll() throws IOException 
	{
		 SearchRequest searchRequest = new SearchRequest();
	        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
	        searchSourceBuilder.query(QueryBuilders.matchAllQuery());
	        searchRequest.source(searchSourceBuilder);

	        SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);

	        return getSearchResult(searchResponse);
	}
	
	private List<Note> getSearchResult(SearchResponse response)
	
	{
        SearchHit[] searchHit = response.getHits().getHits();
        List<Note> profileDocuments = new ArrayList<>();

        if (searchHit.length > 0) 
        {
            Arrays.stream(searchHit).forEach(hit -> profileDocuments.add(objectMapper.convertValue(hit.getSourceAsMap(),Note.class)) );
        }

        return profileDocuments;
    }

	@Override
	public String deleteNote(String id) throws IOException
	{
		 DeleteRequest deleteRequest = new DeleteRequest(INDEX, TYPE, id);
	     DeleteResponse response = client.delete(deleteRequest, RequestOptions.DEFAULT);

	     return response.getResult().name();
	}
	
	@Override
	public List<Note> getNoteByAllFeilds(String searchName,String token)
	{
		Long userId = TokenUtil.decodeToken(token);
		userRepository.findById(userId);
		log.info("Inside get Search--->"+searchName);
		System.out.println(searchName+" "+userId);
		
		try {		
			SearchRequest searchRequest = new SearchRequest("fundoonotes");
			SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();

			QueryBuilder queryBuilder = QueryBuilders.boolQuery().must(QueryBuilders.queryStringQuery("*"+searchName+"*")
											.analyzeWildcard(true).field("title", 2.0f).field("description",1.0f))
											.filter(QueryBuilders.termQuery("userId", String.valueOf(userId)));
			
			searchSourceBuilder.query(queryBuilder);
			searchRequest.source(searchSourceBuilder);
//			SearchRequest searchRequest = new SearchRequest("es","createnote").source(searchSourceBuilder);

			System.out.println(searchRequest);
			SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
			SearchHit[] searchedNotes = searchResponse.getHits().getHits();

			
			List<Note> ListOfNotes = new ArrayList<Note>();

			if (searchedNotes.length > 0) {
				Arrays.stream(searchedNotes).forEach(note -> {
					try {
						ListOfNotes.add(objectMapper.readValue(note.getSourceAsString(), Note.class));
					} catch (JsonParseException e) {

						e.printStackTrace();
					} catch (JsonMappingException e) {

						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
				});
			}
			return ListOfNotes;
		} 
		catch (IOException e) 
		{
			return null;
			//throw new Exception("Internal Server error");
		}
	
	}

}
