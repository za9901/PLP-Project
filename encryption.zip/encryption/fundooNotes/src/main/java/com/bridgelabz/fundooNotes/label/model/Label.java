package com.bridgelabz.fundooNotes.label.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.bridgelabz.fundooNotes.note.model.Note;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
//@ToString
@Table(name = "labels")
public class Label {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long labelid;

	private String labelName;
	
	/*@JoinColumn(name = "id")
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private User user;*/
	
	@ManyToMany(mappedBy="label",cascade = {CascadeType.MERGE,CascadeType.PERSIST} )
	@JsonIgnore
	private Set<Note> note;
}
