package com.bridgelabz.fundooNotes.profilepic.service;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.bridgelabz.fundooNotes.response.Response;
import com.bridgelabz.fundooNotes.response.ResponseImage;
public interface ProfilePicService {
	
	public ResponseEntity<Response> uploadFileToS3Bucket(MultipartFile multipartFile, boolean enablePublicReadAccess,String token);

	public ResponseEntity<Response> deleteFileFromS3Bucket(String token);
	public ResponseEntity<ResponseImage> getFileFromS3Bucket(String token);
}
