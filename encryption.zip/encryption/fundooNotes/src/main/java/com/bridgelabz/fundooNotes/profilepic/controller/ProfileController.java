package com.bridgelabz.fundooNotes.profilepic.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.bridgelabz.fundooNotes.profilepic.service.ProfilePicService;
import com.bridgelabz.fundooNotes.response.Response;
import com.bridgelabz.fundooNotes.response.ResponseImage;

@RestController
@RequestMapping("/profiepic")
@CrossOrigin(origins="http://localhost:4200",allowedHeaders="*",exposedHeaders="jwtTokens")
public class ProfileController {
	
	@Autowired
	private ProfilePicService profilePicService;
	
	
	@PostMapping(value = "/upload",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Response> uploadFile(@RequestParam(name = "File") MultipartFile file,@RequestHeader(name ="token") String token)
    {
		 return this.profilePicService.uploadFileToS3Bucket(file, true,token);
        
    }
	
	@DeleteMapping("/delete")
    public ResponseEntity<Response> deleteFile(@RequestHeader(name="token") String token)
    {
        return this.profilePicService.deleteFileFromS3Bucket(token);


}
	@GetMapping("/getphoto")
	 public ResponseEntity<ResponseImage> getFile(@RequestHeader(name = "token") String token)
	    {
			System.out.println("photo"+token);
	        return this.profilePicService.getFileFromS3Bucket(token);
			
	    }
}
