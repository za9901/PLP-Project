package com.bridgelabz.fundooNotes.rabbitmq;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.bridgelabz.fundooNotes.user.model.Mail;

@Component
@PropertySource("classpath:application.properties")
public class Producer {

	@Autowired
	private AmqpTemplate amqpTemplate;

	//@Value("${spring.rabbitmq.template.exchange}")
	private String exchangeName = "mailsender-exchange";

	//@Value("${spring.rabbitmq.template.routing-key}")
	private String routingKey = "mail-routingkey";

	public void sendMessage(Mail message)
	{
		System.out.println(message);
		try {
			amqpTemplate.convertAndSend(exchangeName, routingKey, message);
		}catch(Exception e){
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

}
