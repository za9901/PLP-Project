package com.bridgelabz.fundooNotes.user.model;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.security.core.Transient;

import com.bridgelabz.fundooNotes.label.model.Label;
import com.bridgelabz.fundooNotes.note.model.Note;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "accounts")
@Setter
@Getter
//@ToString
//@JsonIdentityInfo(generator=ObjectIdGenerators.IntSequenceGenerator.class, property="noteId")
@Data
public class User  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "email_id")
	private String emailid;

	@Column(name = "phone_no")
	private String phoneno;

	@Column(name = "password")
	private String password;

	@Column(name = "update_date")
	private String updateDate;

	@Column(name = "register_date")
	private String registerDate;

	@Column(name = "is_verified")
	private boolean isVerified;
	
	@Column(name = "image")
	private String image;
	
	@JoinColumn(name ="id")
	@OneToMany(targetEntity = Note.class, cascade = CascadeType.ALL,fetch=FetchType.LAZY)
	@JsonIgnore
	private List<Note> note;
	
	@JoinColumn(name = "id")
	@OneToMany(targetEntity = Label.class,cascade = {CascadeType.MERGE,CascadeType.PERSIST},fetch = FetchType.LAZY)
	private Set<Label> labels;

	 
	@ManyToMany(mappedBy = "collabrateUser")
	@JsonIgnoreProperties("collabrateUser")
  //  @JsonManagedReference
	//@JsonIdentityInfo(generator=ObjectIdGenerators.IntSequenceGenerator.class, property="@collabrateUser")
	//@JsonIgnore
	private Set<Note> collabratorNotes;
	
}
