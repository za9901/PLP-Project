package com.bridgelabz.fundooNotes.user.services;

import java.io.UnsupportedEncodingException;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bridgelabz.fundooNotes.response.Response;
import com.bridgelabz.fundooNotes.response.ResponseToken;
import com.bridgelabz.fundooNotes.user.dto.LoginDto;
import com.bridgelabz.fundooNotes.user.dto.UserDto;
import com.bridgelabz.fundooNotes.user.exception.UserException;
import com.bridgelabz.fundooNotes.user.model.User;
@Service
public interface UserService {
	public ResponseEntity<ResponseToken> onLogin(LoginDto loginDto) throws UnsupportedEncodingException;

	public ResponseEntity<Response> onRegister(UserDto userDto) throws UserException, UnsupportedEncodingException;

	public ResponseEntity<Response> forgetPassword(String emailId) throws UserException, UnsupportedEncodingException;

	public  ResponseEntity<Response> resetPassword(String token, String password) throws UserException, UnsupportedEncodingException;

	public ResponseEntity<Response> validEmail(String token) throws UserException, UnsupportedEncodingException;

//	public void sendmail(String mailSubject, Long userId,String mail,String url);

	public List<User> findAll();
}
