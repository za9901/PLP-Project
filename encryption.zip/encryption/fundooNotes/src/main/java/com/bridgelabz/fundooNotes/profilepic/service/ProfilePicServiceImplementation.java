package com.bridgelabz.fundooNotes.profilepic.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.HttpMethod;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.util.IOUtils;
import com.bridgelabz.fundooNotes.response.Response;
import com.bridgelabz.fundooNotes.response.ResponseImage;
import com.bridgelabz.fundooNotes.user.exception.UserException;
import com.bridgelabz.fundooNotes.user.model.User;
import com.bridgelabz.fundooNotes.user.repository.UserRepository;
import com.bridgelabz.fundooNotes.utility.ResponseSender;
import com.bridgelabz.fundooNotes.utility.TokenUtil;

@Component
public class ProfilePicServiceImplementation implements ProfilePicService {

	private String awsS3AudioBucket;
	private AmazonS3 amazonS3;

	@Autowired
	public ProfilePicServiceImplementation(Region awsRegion, AWSCredentialsProvider awsCredentialsProvider,
			String awsS3AudioBucket) {
		this.amazonS3 = AmazonS3ClientBuilder.standard().withCredentials(awsCredentialsProvider)
				.withRegion(awsRegion.getName()).build();
		this.awsS3AudioBucket = awsS3AudioBucket;

	}
	
	@Autowired
	private	UserRepository userRepository;

	@Override
	@Async
	public ResponseEntity<Response> uploadFileToS3Bucket(MultipartFile multipartFile, boolean enablePublicReadAccess,String token) {
		
		Long userid = TokenUtil.decodeToken(token);
		User user = userRepository.findById(userid).orElseThrow(()-> new UserException(404, "user not found"));
		//generating random uuid
		String keyForImage = UUID.randomUUID().toString();
		System.out.println(keyForImage);
		String fileName = multipartFile.getOriginalFilename();
//		System.out.println(fileName);
		try {
			// creating the file in the server (temporarily)
			File file = new File(fileName);
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(multipartFile.getBytes());
			fos.close();
			System.out.println(file);
			PutObjectRequest putObjectRequest = new PutObjectRequest(this.awsS3AudioBucket, keyForImage, file);
			System.out.println(this.awsS3AudioBucket);
			if (enablePublicReadAccess) {
				putObjectRequest.withCannedAcl(CannedAccessControlList.Private);
			}
			this.amazonS3.putObject(putObjectRequest);
			System.out.println(putObjectRequest);
			// removing the file created in the server
			file.delete();
			user.setImage(keyForImage);
			userRepository.save(user);
			return ResponseSender.sendResponse("file uploaded successfully ", 200);
			
		} catch (Exception ex) {

			return ResponseSender.sendResponse("error in uploading file ", 404);

		}
	}

	@Override
	@Async
	public ResponseEntity<Response> deleteFileFromS3Bucket(String token) {
		try {
			Long userid = TokenUtil.decodeToken(token);
			User user =userRepository.findById(userid).orElseThrow(()-> new UserException(404, "user not found"));
			amazonS3.deleteObject(new DeleteObjectRequest(awsS3AudioBucket,user.getImage()));
			return ResponseSender.sendResponse("file deleted successfully ", 200);
		} catch (AmazonServiceException ex) {

			return ResponseSender.sendResponse("error in uploading file ", 404);
		}
	}
	@Override
	@Async
	public ResponseEntity<ResponseImage>  getFileFromS3Bucket(String token){
		Long userid = TokenUtil.decodeToken(token);
		
		User user =userRepository.findById(userid).orElseThrow(()-> new UserException(404, "user not found"));	
		//S3Object file = amazonS3.getObject(awsS3AudioBucket,user.getImage());
		GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(awsS3AudioBucket,user.getImage());
		generatePresignedUrlRequest.setMethod(HttpMethod.GET);
			System.out.println(user.getImage());
				URL Url = amazonS3.generatePresignedUrl(generatePresignedUrlRequest);
		System.out.println(Url.toString());
		return ResponseSender.sendResponseWithImage("sucess", 200,Url.toString() );
		
//		/**
//		 * This method takes image key and validate to exist image or not. useful in
//		 * obtaining only the object metadata, and avoids wasting bandwidth on fetching
//		 * the object data.
//		 * 
//		 * @param key Image key
//		 * @return signed Image Url
//		 * @throws UploadImageException
//		 */
//		public String getSignedImgUrl(String key) throws ImageException {
//		try {
//		GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(S3_BUCKET_NAME,key);
//		generatePresignedUrlRequest.setMethod(HttpMethod.GET);
//		generatePresignedUrlRequest.setExpiration(DateTime.now().plusMinutes(2).toDate());
//
//		URL signedUrl = s3Client.generatePresignedUrl(generatePresignedUrlRequest);
//
//		return signedUrl.toString();
//		} catch (Exception e) {
//		e.printStackTrace();
//		throw new ImageException(-106);
//		}
//		}
		
		
		
//		System.out.println(file);
//		  S3ObjectInputStream objectContent = file.getObjectContent();
//		  	try {
//			String data = StreamUtils.copyToString(objectContent, StandardCharsets.UTF_8 );
//			System.out.println("gfgdsgdsgdsgdsgdsgs");
//				return ResponseSender.sendBase64Response("success", 200, data);
//			} catch (IOException e) {
//				e.printStackTrace();
//				return ResponseSender.sendBase64Response("falied to convert", 200,null);
//			}
//		  try {
//			IOUtils.copy(objectContent, new FileOutputStream("/home/admin1/Documents/test.jpeg"));
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
	}

}
