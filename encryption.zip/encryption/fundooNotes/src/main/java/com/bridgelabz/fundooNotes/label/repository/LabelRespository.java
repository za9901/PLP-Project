package com.bridgelabz.fundooNotes.label.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bridgelabz.fundooNotes.label.model.Label;

@Repository
public interface LabelRespository extends JpaRepository<Label, Long> {

	public Label findBylabelid(Long labelid);
	  
	public Optional<Label> deleteBylabelid(Long labelid);

}
