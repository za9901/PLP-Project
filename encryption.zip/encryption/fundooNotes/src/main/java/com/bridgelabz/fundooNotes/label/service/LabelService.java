package com.bridgelabz.fundooNotes.label.service;

import java.util.List;
import java.util.Set;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bridgelabz.fundooNotes.label.dto.LabelDto;
import com.bridgelabz.fundooNotes.label.model.Label;
import com.bridgelabz.fundooNotes.note.model.Note;
import com.bridgelabz.fundooNotes.response.Response;
@Service
public interface LabelService {

	public ResponseEntity<Response> createLabel(String labelTitle, String token);

	public ResponseEntity<Response> updateLabel(Long labelid, String labelTitle, String token);

	public List<Label> getAllLabels();
	
	public ResponseEntity<Response> addLabelToNote(String token,Long noteid,String labelTitle );

	public Set<Label> getUserLabel(String token);

	public ResponseEntity<Response> deleteLabel(Long labelid,String token);
	
	public ResponseEntity<Response> deleteNoteLabel(String token,Long noteId,Long labelId);
	
	public List<Note> getLabelNote(String token,Long labelId);
}
