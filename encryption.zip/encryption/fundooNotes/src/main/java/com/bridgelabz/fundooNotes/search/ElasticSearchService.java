package com.bridgelabz.fundooNotes.search;


import java.io.IOException;
import java.util.List;

import com.bridgelabz.fundooNotes.note.model.Note;
import com.bridgelabz.fundooNotes.user.model.User;

public interface ElasticSearchService 
{
	public String createNote(Note note)  throws IOException;
	
	public String UpdateNote(Long noteid , Note note);

	public Note findById(String id) throws IOException;

	public List<Note> findAll() throws IOException;

	public String deleteNote(String id) throws IOException;

	List<Note> getNoteByAllFeilds(String searchName,String token) throws Exception;
	
}
