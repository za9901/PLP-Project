package com.bridgelabz.fundooNotes.rabbitmq;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bridgelabz.fundooNotes.user.model.Mail;
import com.bridgelabz.fundooNotes.utility.EmailService;


@Component
public class Consumer{

	 @Autowired
	    private EmailService emailService;
	 
	@RabbitListener(queues="mailsender-queue")
	public void reciveMessage(Mail message)  {
		System.out.println("received msg : "+message);
		emailService.sendSimpleMessage(message);
	}

	/*
	 * @Override public void onMessage(Message message) {
	 * System.out.println("messaage");
	 * 
	 * }
	 */
}
