//package com.bridgelabz.fundooNotes.note.dto;
//
//public class CollabDto {
//	
//private String emailid;
//private String 
//}
