package com.bridgelabz.fundooNotes.label.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bridgelabz.fundooNotes.label.dto.LabelDto;
import com.bridgelabz.fundooNotes.label.model.Label;
import com.bridgelabz.fundooNotes.label.service.LabelService;
import com.bridgelabz.fundooNotes.note.model.Note;
import com.bridgelabz.fundooNotes.response.Response;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/label")
@CrossOrigin(origins="http://localhost:4200",allowedHeaders="*",exposedHeaders={"jwtTokens"})
public class LabelController {

	@Autowired
	private LabelService labelService;
	
	@PostMapping("/create")
	@ApiOperation(value = "api to create label")
	public ResponseEntity<Response> createLabel(@RequestParam(name = "labelTitle") String labelTitle,@RequestHeader String token)
	{
	
		return labelService.createLabel(labelTitle, token);	
	}
	
	@PutMapping("/update")
	@ApiOperation(value = "api to update the label and save the label")
	public ResponseEntity<Response> updateLabel(@RequestParam(name = "labelid") Long labelid,@RequestParam(name = "labelTitle") String labelTitle,@RequestHeader(value = "token") String token)
	{
		System.out.println("00000000000000000000000000000000000000000000000000000000000000000000000");
		return labelService.updateLabel(labelid,labelTitle, token);
	}
	
	@GetMapping("/getall")
	@ApiOperation("api to get all labels associated with paticular user")
	public List<Label> getAllLabels()
	{
		return labelService.getAllLabels();
	}
	
	@DeleteMapping("/delete")
	@ApiOperation(value = "api to delete a label")
	public ResponseEntity<Response> deleteLabel(@RequestParam Long labelid,@RequestHeader(name = "token")String token)
	{
		return labelService.deleteLabel(labelid,token);
	}
	
	@PostMapping("/addlabeltonote")
	@ApiOperation(value = "api to add label to a paticular user")
	public ResponseEntity<Response> addLabel(@RequestParam(name = "labelTitle") String labelTitle,@RequestParam(name = "noteid") Long noteid,@RequestHeader(value = "token") String token)
	{
		System.out.println(labelTitle);
		return labelService.addLabelToNote(token, noteid, labelTitle);
		
	}
	@GetMapping("/getlabels")
	@ApiOperation(value = "api to get all the labels of a user")
	public Set<Label> getAllLabels(@RequestHeader String token){
		return labelService.getUserLabel(token);
	}
	
	@DeleteMapping("/deletelabelfromnote")
	@ApiOperation(value = "api to delete the label of a user")
	public ResponseEntity<Response> deleteLabel(@RequestParam Long noteid,@RequestParam Long labelid,@RequestHeader String token)
	{
		return labelService.deleteNoteLabel(token, noteid, labelid);
		
	}
	
	@GetMapping("/getlabelnotes")
	public List<Note> getLabelNotes(@RequestHeader String token,@RequestParam Long labelid)
	{
		return labelService.getLabelNote(token, labelid);
	}
	
	

}
