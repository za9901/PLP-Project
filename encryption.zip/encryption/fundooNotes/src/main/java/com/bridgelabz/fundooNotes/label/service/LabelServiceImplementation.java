package com.bridgelabz.fundooNotes.label.service;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bridgelabz.fundooNotes.label.dto.LabelDto;
import com.bridgelabz.fundooNotes.label.model.Label;
import com.bridgelabz.fundooNotes.label.repository.LabelRespository;
import com.bridgelabz.fundooNotes.note.model.Note;
import com.bridgelabz.fundooNotes.note.repository.NoteRepository;
import com.bridgelabz.fundooNotes.response.Response;
import com.bridgelabz.fundooNotes.search.ElasticSearchService;
import com.bridgelabz.fundooNotes.user.exception.NoteException;
import com.bridgelabz.fundooNotes.user.exception.UserException;
import com.bridgelabz.fundooNotes.user.model.User;
import com.bridgelabz.fundooNotes.user.repository.UserRepository;
import com.bridgelabz.fundooNotes.utility.ResponseSender;
import com.bridgelabz.fundooNotes.utility.TokenUtil;

@Service
public class LabelServiceImplementation implements LabelService {

	@Autowired
	private LabelRespository labelRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private Environment environment;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private NoteRepository noteRepository;
	
	@Autowired(required=true)
	ElasticSearchService esService;

	@Override
	public ResponseEntity<Response> createLabel(String labelTitle, String token) {
		//System.out.println(labelDto);
		
		//Label label = modelMapper.map(labelDto, Label.class);
		Label label = new Label();
		label.setLabelName(labelTitle);
		Long userId = TokenUtil.decodeToken(token);
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new UserException(404, environment.getProperty("105")));
		user.getLabels().add(label);
		userRepository.save(user);
		// labelRepository.save(label);
		return ResponseSender.sendResponse(environment.getProperty("001"), 200);
	}

	@Override
	public ResponseEntity<Response> updateLabel(Long labelid, String labelTitle, String token) {
		// Label label = labelRepository.findBylabelid(labelid);
		// label.setLabelName(labelDto.getLabelName());
		// labelRepository.save(label);
		Long userid = TokenUtil.decodeToken(token);
		User user = userRepository.findById(userid)
				.orElseThrow(() -> new UserException(environment.getProperty("105")));
		Set<Label> label = user.getLabels();
		Label filteredlabel = label.stream().filter(data -> data.getLabelid().equals(labelid)).findFirst()
				.orElseThrow(() -> new UserException(404, environment.getProperty("105")));
		filteredlabel.setLabelName(labelTitle);
		label.add(filteredlabel);
		user.setLabels(label);
		userRepository.save(user);
		return ResponseSender.sendResponse(environment.getProperty("002"), 200);
	}

	@Override
	public List<Label> getAllLabels() {

		return labelRepository.findAll();
	}

	@Override
	public ResponseEntity<Response> deleteLabel(Long labelid,String token) {
		
//		Long userid = TokenUtil.decodeToken(token);
//		User user = userRepository.findById(userid).orElseThrow(()-> new UserException(404,"user not found"));
//		Label label = user.getLabels().stream().filter(data -> data.getLabelid().equals(labelid)).findFirst().get();
//		//Optional<Note> note = user.getNote();
//		//labelRepository.deleteById(labelid);
//		user.getLabels().remove(label);
//		userRepository.save(user);
		labelRepository.deleteById(labelid);
		return ResponseSender.sendResponse(environment.getProperty("003"), 200);
	}

	@Override
	public ResponseEntity<Response> addLabelToNote(String token, Long noteid, String labelTitle) {
		Long userId = TokenUtil.decodeToken(token);
		System.out.println("user id = " + userId);
		LabelDto labelDto = new LabelDto();
		labelDto.setLabelName(labelTitle);
		System.out.println("label " + labelDto);
		User user= userRepository.findById(userId).orElseThrow(() -> new UserException(400, environment.getProperty("105")));
		System.out.println(user);
		System.out.println(user.getLabels());
		Label label = user.getLabels().stream().filter(data -> data.getLabelName().equals(labelDto.getLabelName()))
				.findFirst().orElse(modelMapper.map(labelDto, Label.class));
		System.out.println("label object = " + label);
	//	 to check wheather label is in user object or nor,if it is not present add to user object
		if (user.getLabels().stream().filter(data -> data.getLabelName().equals(labelDto.getLabelName())).findFirst()
				.isPresent() == false) {
			System.out.println("false");
			user.getLabels().add(label);
			userRepository.save(user);
		}
		label = user.getLabels().stream().filter(data -> data.getLabelName().equals(labelDto.getLabelName()))
				.findFirst().get();
		Note note = user.getNote().stream().filter(data -> data.getNoteId().equals(noteid)).findFirst()
				.orElseThrow(() -> new NoteException(400, environment.getProperty("106")));
		System.out.println(note);
		if (note.getLabel().stream().filter(data -> data.getLabelName().equals(labelTitle)).findFirst()
				.isPresent() == false) {
			note.getLabel().add(label);
			noteRepository.save(note);
			esService.UpdateNote(noteid, note);
			System.out.println("sucess");
			return ResponseSender.sendResponse(environment.getProperty("001"), 200);
		}
		System.out.println("fail");
		return ResponseSender.sendResponse("label already added", 400);
		
	}

	@Override
	public Set<Label> getUserLabel(String token) {
		Long userId = TokenUtil.decodeToken(token);
		User user = userRepository.findById(userId).orElseThrow(()->new UserException(400,environment.getProperty("105")));
		
		return user.getLabels();
	}

	@Override
	public ResponseEntity<Response> deleteNoteLabel(String token, Long noteId, Long labelId) {
		Long userId = TokenUtil.decodeToken(token);
		User user= userRepository.findById(userId).orElseThrow(() -> new UserException(400, environment.getProperty("105")));
		Note note = user.getNote().stream().filter(data-> data.getNoteId().equals(noteId))
			    .findFirst().get();
		boolean status=note.getLabel().removeIf(data -> data.getLabelid().equals(labelId));
		 user.getNote().add(note);
		 esService.UpdateNote(noteId, note);
		 userRepository.save(user);
		return ResponseSender.sendResponse("label deleted successfully", 200);
	}

	@Override
	public List<Note> getLabelNote(String token, Long labelId) {
		
		Long userId = TokenUtil.decodeToken(token);
		User user= userRepository.findById(userId).
				orElseThrow(()-> new UserException(400,environment.getProperty("105")));
		Label label = labelRepository.findById(labelId).get();
		List<Note> note = label.getNote().stream().collect(Collectors.toList());

		return note;
	}
	
	
	

}
