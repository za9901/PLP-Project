package com.bridgelabz.fundooNotes.user.services;

import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;

import org.modelmapper.ModelMapper;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.bridgelabz.fundooNotes.rabbitmq.Producer;
import com.bridgelabz.fundooNotes.response.Response;
import com.bridgelabz.fundooNotes.response.ResponseToken;
import com.bridgelabz.fundooNotes.user.dto.LoginDto;
import com.bridgelabz.fundooNotes.user.dto.UserDto;
import com.bridgelabz.fundooNotes.user.exception.UserException;
import com.bridgelabz.fundooNotes.user.model.Mail;
import com.bridgelabz.fundooNotes.user.model.TokenInfo;
import com.bridgelabz.fundooNotes.user.model.User;
import com.bridgelabz.fundooNotes.user.repository.TokenRepository;
import com.bridgelabz.fundooNotes.user.repository.UserRepository;
import com.bridgelabz.fundooNotes.utility.EmailService;
import com.bridgelabz.fundooNotes.utility.MailHelper;
import com.bridgelabz.fundooNotes.utility.ResponseSender;
import com.bridgelabz.fundooNotes.utility.TokenUtil;

@PropertySource("classpath:message.properties")
@Service
public class UserServiceImplementation implements UserService {
	
	@Value("${sender.email}")
	 String fromEmail;
	
	@Value("${sender.password}")
	String password;
	


	@Autowired
	private	UserRepository userRepository;
	
	@Autowired
	private TokenRepository tokenRepository; 
	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private Environment environment;
	
	@Autowired
	private Producer producer;
	
	private TokenInfo tokenInfo = new TokenInfo();

	Date date = new Date();	

	String updateDate = date.toString();

	String registerDate = date.toString();

	public List<User> findAll() {
		return userRepository.findAll();
	}

	public ResponseEntity<ResponseToken> onLogin(LoginDto loginDto) throws UnsupportedEncodingException {

		User user = modelMapper.map(loginDto, User.class);
		// System.out.println(user.getEmailid());

		User validUser = userRepository.findByEmailid(user.getEmailid())
				.orElseThrow(() -> new UserException(401, environment.getProperty("100")));
			String token  = TokenUtil.createToken(validUser.getId());
		System.out.println(validUser);
		if (validUser.isVerified()==true) {

			// match the loginDto password && validUser password
			boolean passwordStatus = passwordEncoder.matches(loginDto.getPassword(), validUser.getPassword());

			if (passwordStatus == false) {
				throw new UserException(401, environment.getProperty("100"));
			} else {
				
				return ResponseSender.sendResponse(environment.getProperty("200"), 200, token);
			}
		}
		return ResponseSender.sendResponse(environment.getProperty("404"),404,token);
	}

	public ResponseEntity<Response> onRegister(UserDto userDto) throws UserException, UnsupportedEncodingException {

		User user = modelMapper.map(userDto, User.class);
		System.out.println(user.getFirstName());
		Optional<User> useralreadyPresent = userRepository.findByEmailid(user.getEmailid());

		if (useralreadyPresent.isPresent()) {
			System.out.println(useralreadyPresent.isPresent());
			throw new UserException(401, environment.getProperty("101"));
		}

		String password = passwordEncoder.encode(userDto.getPassword());

		user.setPassword(password);

		user.setUpdateDate(updateDate);

		user.setRegisterDate(registerDate);
		user.setImage("circle-512.png");
		
		//tokenInfo.setTokenId(user.getId());
		tokenInfo.setUserid(user.getId());
		tokenInfo.setToken(TokenUtil.createToken(user.getId()));
		tokenRepository.save(tokenInfo);
		System.out.println(user.getImage());
		user = userRepository.save(user);
		System.out.println(user.getId());
		 Mail mail = new Mail();
	        mail.setFrom("venky70662@gmail.com");
	        mail.setTo(user.getEmailid());
	        mail.setSubject("verify your mail");
	        mail.setContent("http://localhost:4200/user/validEmail/"+MailHelper.getUrl(user.getId()));
	        producer.sendMessage(mail);
		//sendmail(environment.getProperty("202"), user.getId(),user.getEmailid(),"http://localhost:4200/user/validEmail/");
		System.out.println(user.getImage());
		
		
		return ResponseSender.sendResponse(environment.getProperty("201"), 200);
	}

	
	 

	public ResponseEntity<Response> forgetPassword(String emailId) throws UserException, UnsupportedEncodingException {

		Optional<User> alreadyPresent = userRepository.findByEmailid(emailId);

		if (!alreadyPresent.isPresent()) {
			throw new UserException(401, environment.getProperty("102"));
		}

		Long id = alreadyPresent.get().getId();
		
		Mail mail = new Mail();
        mail.setFrom("venky70662@gmail.com");
        mail.setTo(emailId);
        mail.setSubject("link to reset your password");
        mail.setContent("http://localhost:4200/resetpassword/"+MailHelper.getUrl(id));
        producer.sendMessage(mail);
        

		//sendmail(environment.getProperty("204"), id,emailId,"http://localhost:4200/resetpassword/");

		return ResponseSender.sendResponse(environment.getProperty("203"), 200);
	}

	public  ResponseEntity<Response> resetPassword(String token, String password) throws UserException, UnsupportedEncodingException {
			if (tokenInfo.isReset()==false)
			{
				tokenInfo.setReset(true);
				tokenRepository.save(tokenInfo);
		Long userid = TokenUtil.decodeToken(token);

		Optional<User> alreadyPresent = userRepository.findById(userid);

		if (!alreadyPresent.isPresent()) {
			throw new UserException(401, environment.getProperty("103"));
		}

		String newpassword = passwordEncoder.encode(password);

		alreadyPresent.get().setPassword(newpassword);

		User user = alreadyPresent.get();

		user = userRepository.save(user);

		return ResponseSender.sendResponse(environment.getProperty("200"), 200);
			}
			else {
				return ResponseSender.sendResponse("token is valid only once ", 401);
			}
	}

	public  ResponseEntity<Response> validEmail(String token) throws UserException, UnsupportedEncodingException {
		
//		if(tokenInfo.isValid()==false)
//		{
//			tokenInfo.setValid(true);
//			tokenRepository.save(tokenInfo);
		Long userid = TokenUtil.decodeToken(token);

		Optional<User> alreadyPresent = userRepository.findById(userid);

		if (!alreadyPresent.isPresent()) {
			throw new UserException(401, environment.getProperty("104"));
		}
		alreadyPresent.get().setVerified(true);

		User user = alreadyPresent.get();

		user = userRepository.save(user);

		//sendmail("successfully register", userid);

		return ResponseSender.sendResponse(environment.getProperty("200"), 200);
		}
//		else
//		{
//			return ResponseSender.sendResponse("already verified", 404);
//		}
	//}

//	public void sendmail(String mailSubject, Long userId,String mail,String url) {
//
//		//fromEmail = environment.getProperty("sender.email");
//		//password = environment.getProperty("sender.password");
//		System.out.println(fromEmail);
//		System.out.println(password);
//		Properties props = new Properties();
//		props.put("mail.smtp.host", "smtp.gmail.com"); // SMTP Host
//		props.put("mail.smtp.socketFactory.port", "465"); // SSL Port
//		props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory"); // SSL Factory Class
//		props.put("mail.smtp.auth", "true"); // Enabling SMTP Authentication
//		props.put("mail.smtp.port", "465"); // SMTP Port
//System.out.println(userId);
//		Authenticator auth = new Authenticator() {
//
//			protected PasswordAuthentication getPasswordAuthentication() {
//				return new PasswordAuthentication(fromEmail, password);
//			}
//		};
//
//		Session session = Session.getDefaultInstance(props, auth);
//		System.out.println(url);
//		MailHelper.sendEmail(session, mail, mailSubject, url+MailHelper.getUrl(userId));
//	}
}
