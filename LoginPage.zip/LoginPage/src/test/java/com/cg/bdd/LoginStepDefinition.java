package com.cg.bdd;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition {
	
	LoginPage login;
	
	@Given("The user has Browser and Login page")
	public void the_user_has_Browser_and_Login_page() {
		System.setProperty("webdriver.chrome.driver", "C:\\AngularDemo\\LoginPage\\libs\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/AngularDemo/LoginPage/src/main/java/com/cg/LoginPage/login.html");
		login= new LoginPage(driver);
	}

	@When("User enters {string} and {string}")
	public void user_enters_and(String username, String password) {
		login.enterCredential(username, password);
	}

	@Then("User should get into the amazon page")
	public void user_should_get_into_the_amazon_page() {
		login.clickButton();
	}
}
