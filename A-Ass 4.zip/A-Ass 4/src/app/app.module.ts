import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Route,RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { BookComponent } from './book/book.component';
import {HttpClientModule} from '@angular/common/http';
import { BookformComponent } from './bookform/bookform.component';
const routes:Route[]=[
  {
    path:'book',
    component:BookComponent
  },
  {
    path:'bookform',
    component:BookformComponent
  }
];
@NgModule({
  declarations: [
    AppComponent,
    BookComponent,
    BookformComponent,
    
    
  ],
  imports: [
    BrowserModule,RouterModule,RouterModule.forRoot(routes)
    ,HttpClientModule, FormsModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
