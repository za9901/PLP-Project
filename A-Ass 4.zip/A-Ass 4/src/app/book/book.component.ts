import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { IBook } from './book';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {
  books:IBook[];
  id:number;
title:string;
year:number;
author:string;

  constructor(private service:BookService) { }

  ngOnInit() {
    return this.service.getBooks().subscribe(data=>this.books=data);

  }

 
  

}
